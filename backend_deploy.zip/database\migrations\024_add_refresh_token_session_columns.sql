-- Migration 024: Sessao revogavel para refresh token
-- Adiciona hash e expiracao do refresh token em tb_usuarios.

ALTER TABLE tb_usuarios
  ADD COLUMN IF NOT EXISTS refresh_token_hash VARCHAR(255),
  ADD COLUMN IF NOT EXISTS refresh_token_expires_at TIMESTAMP;