-- ============================================
-- MIGRATION: Ajustes Workflow de Precos (ERS 4.0)
-- Versao: 1.0.1
-- Data: 2026-02-10
-- ============================================

-- Margem minima configuravel por obra
ALTER TABLE tb_obras
  ADD COLUMN IF NOT EXISTS margem_minima_percentual DECIMAL(5,2) DEFAULT 20.00;

COMMENT ON COLUMN tb_obras.margem_minima_percentual IS 'Margem minima de lucro (%)';

-- Campos de workflow em precos
ALTER TABLE tb_tabela_precos
  ADD COLUMN IF NOT EXISTS data_submissao TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS id_usuario_submissor UUID REFERENCES tb_usuarios(id),
  ADD COLUMN IF NOT EXISTS data_rejeicao TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS id_usuario_rejeitador UUID REFERENCES tb_usuarios(id),
  ADD COLUMN IF NOT EXISTS justificativa_rejeicao TEXT;

-- Atualizar constraint para permitir RASCUNHO
ALTER TABLE tb_tabela_precos
  DROP CONSTRAINT IF EXISTS tb_tabela_precos_status_aprovacao_check;

ALTER TABLE tb_tabela_precos
  ADD CONSTRAINT tb_tabela_precos_status_aprovacao_check
  CHECK (status_aprovacao IN ('RASCUNHO', 'PENDENTE', 'APROVADO', 'REJEITADO'));

-- Default do status passa a ser RASCUNHO
ALTER TABLE tb_tabela_precos
  ALTER COLUMN status_aprovacao SET DEFAULT 'RASCUNHO';
