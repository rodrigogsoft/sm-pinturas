-- Corrige drift de schema: garante id_tabela_preco em tb_alocacoes_itens
ALTER TABLE tb_alocacoes_itens
ADD COLUMN IF NOT EXISTS id_tabela_preco UUID NULL;

-- FK (somente cria se ainda nao existir)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'tb_alocacoes_itens_id_tabela_preco_fkey'
  ) THEN
    ALTER TABLE tb_alocacoes_itens
    ADD CONSTRAINT tb_alocacoes_itens_id_tabela_preco_fkey
    FOREIGN KEY (id_tabela_preco)
    REFERENCES tb_tabela_precos(id);
  END IF;
END $$;

-- Indice para consultas por tabela de preco
CREATE INDEX IF NOT EXISTS idx_alocacoes_itens_tabela_preco
ON tb_alocacoes_itens(id_tabela_preco);
