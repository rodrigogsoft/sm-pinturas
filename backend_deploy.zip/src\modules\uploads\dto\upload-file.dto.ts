import { IsNotEmpty, IsString, IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class UploadFileDto {
  @ApiProperty({
    description: 'Tipo de upload (medicao, obra, cliente, etc)',
    example: 'medicao',
    enum: ['medicao', 'obra', 'cliente', 'outro'],
  })
  @IsString()
  @IsNotEmpty()
  tipo: string;

  @ApiPropertyOptional({
    description: 'Identificador relacionado (ID da medição, obra, etc)',
    example: 'uuid-da-medicao',
  })
  @IsString()
  @IsOptional()
  id_relacionado?: string;

  @ApiPropertyOptional({
    description: 'Descrição ou observações sobre o arquivo',
    example: 'Foto de evidência do excedente',
  })
  @IsString()
  @IsOptional()
  descricao?: string;
}
