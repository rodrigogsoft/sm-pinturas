-- Remove a coluna valor_base do catálogo de serviços
-- O campo não é mais utilizado no fluxo de precificação (preços são gerenciados via tb_tabela_precos)

ALTER TABLE tb_servicos_catalogo DROP COLUMN IF EXISTS valor_base;
