import {
  IsNumber,
  IsOptional,
  IsPositive,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateItemAmbienteDto {
  @ApiProperty({
    example: 30.0,
    description: 'Área planejada para este item de ambiente',
    required: false,
  })
  @IsNumber()
  @IsOptional()
  @IsPositive()
  area_planejada?: number;
}
