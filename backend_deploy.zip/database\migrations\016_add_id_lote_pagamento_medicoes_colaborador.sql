-- ERS 4.1: vinculo de medicao individual ao lote de pagamento
ALTER TABLE tb_medicoes_colaborador
ADD COLUMN IF NOT EXISTS id_lote_pagamento UUID REFERENCES tb_lotes_pagamento(id);

CREATE INDEX IF NOT EXISTS idx_medicoes_colaborador_lote
ON tb_medicoes_colaborador(id_lote_pagamento)
WHERE id_lote_pagamento IS NOT NULL;
