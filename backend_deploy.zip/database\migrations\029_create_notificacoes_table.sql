-- Migration 029: Criação da tabela tb_notificacoes
-- Data: 2026-03-21

DO $$ BEGIN
  CREATE TYPE tipo_notificacao_enum AS ENUM (
    'MEDICAO_PENDENTE',
    'CICLO_FATURAMENTO',
    'LOTE_APROVACAO',
    'PRECO_PENDENTE',
    'OBRA_ATRASO',
    'SISTEMA'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE prioridade_notificacao_enum AS ENUM (
    'BAIXA',
    'MEDIA',
    'ALTA',
    'CRITICA'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS tb_notificacoes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  id_usuario_destinatario UUID NOT NULL REFERENCES tb_usuarios(id),
  tipo tipo_notificacao_enum NOT NULL,
  titulo VARCHAR(200) NOT NULL,
  mensagem TEXT NOT NULL,
  prioridade prioridade_notificacao_enum NOT NULL DEFAULT 'MEDIA',
  lida BOOLEAN NOT NULL DEFAULT FALSE,
  lida_em TIMESTAMPTZ,
  dados_extras JSONB,
  id_entidade_relacionada UUID,
  tipo_entidade VARCHAR(100),
  deletado BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notificacoes_usuario ON tb_notificacoes(id_usuario_destinatario);
CREATE INDEX IF NOT EXISTS idx_notificacoes_lida ON tb_notificacoes(lida) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_notificacoes_tipo ON tb_notificacoes(tipo);
