-- ============================================
-- SEED DE DADOS REALISTAS - JB PINTURAS ERP
-- Descrição: Popular banco com dados para simulação de uso real
-- Data: 2026-03-03
-- ============================================

-- ============================================
-- 1. COLABORADORES ADICIONAIS
-- ============================================

INSERT INTO tb_colaboradores (id, nome, nome_completo, cpf, cpf_nif, email, telefone, data_nascimento, endereco, deletado)
VALUES 
('ffffffff-ffff-ffff-ffff-ffffffffffff', 'Pedro Pintor', 'Pedro Pintor Silva', '12345678901', '123.456.789-01', 'pedro.pintor@jbpinturas.com.br', '(11) 98000-1000', '1985-05-15', 'Rua A, 100 - São Paulo, SP', false),
('10101010-1010-1010-1010-101010101010', 'Carlos Preparador', 'Carlos Manuel Preparador', '12345678902', '123.456.789-02', 'carlos.prep@jbpinturas.com.br', '(11) 98000-2000', '1988-08-22', 'Rua B, 200 - São Paulo, SP', false),
('20202020-2020-2020-2020-202020202020', 'André Ajudante', 'André Costa Ajudante', '12345678903', '123.456.789-03', 'andre.ajudante@jbpinturas.com.br', '(11) 98000-3000', '1990-12-10', 'Rua C, 300 - São Paulo, SP', false),
('30303030-3030-3030-3030-303030303030', 'Roberto Mestre', 'Roberto Santos Mestre Pintor', '12345678904', '123.456.789-04', 'roberto.mestre@jbpinturas.com.br', '(11) 98000-4000', '1980-03-25', 'Rua D, 400 - São Paulo, SP', false),
('40404040-4040-4040-4040-404040404040', 'Marcelo Técnico', 'Marcelo José Técnico', '12345678905', '123.456.789-05', 'marcelo.tec@jbpinturas.com.br', '(11) 98000-5000', '1992-07-18', 'Rua E, 500 - São Paulo, SP', false)
ON CONFLICT (cpf) DO NOTHING;

-- ============================================
-- 2. OBRAS ADICIONAIS
-- ============================================

INSERT INTO tb_obras (id, nome, endereco_completo, status, data_inicio, data_previsao_fim, id_cliente, deletado)
VALUES 
('44444444-4444-4444-4444-444444444444', 'Edifício Corporate Blue', 'Av. Paulista, 1000 - São Paulo, SP', 'ATIVA', '2026-01-10'::date, '2026-06-30'::date, '22222222-2222-2222-2222-222222222222', false),
('55555555-5555-5555-5555-555555555555', 'Residencial Green Valley', 'Rua das Acácias, 500 - São Paulo, SP', 'ATIVA', '2025-12-01'::date, '2026-08-31'::date, '11111111-1111-1111-1111-111111111111', false)
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 4. PAVIMENTOS
-- ============================================

INSERT INTO tb_pavimentos (id, id_obra, nome, ordem, deletado)
VALUES 
('50101010-0101-0101-0101-010101010101', '44444444-4444-4444-4444-444444444444', 'Térreo', 0, false),
('50101010-0101-0101-0101-010101010102', '44444444-4444-4444-4444-444444444444', '1º Andar', 1, false),
('50101010-0101-0101-0101-010101010201', '55555555-5555-5555-5555-555555555555', 'Pavimento Tipo', 1, false),
('50101010-0101-0101-0101-010101010202', '55555555-5555-5555-5555-555555555555', 'Cobertura', 20, false)
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 5. AMBIENTES
-- ============================================

INSERT INTO tb_ambientes (id, id_pavimento, nome, area_m2, descricao, deletado)
VALUES 
('60101010-0101-0101-0101-010101010101', '50101010-0101-0101-0101-010101010101', 'Recepção', 120.50, 'Hall de entrada premium', false),
('60101010-0101-0101-0101-010101010102', '50101010-0101-0101-0101-010101010101', 'Sala de Espera', 85.75, 'Sala com sofás executivos', false),
('60101010-0101-0101-0101-010101010103', '50101010-0101-0101-0101-010101010101', 'Restaurante', 200.00, 'Restaurante corporativo com cozinha', false),
('60101010-0101-0101-0101-010101010201', '50101010-0101-0101-0101-010101010102', 'Sala de Reunião A', 65.00, 'Sala para 20 pessoas', false),
('60101010-0101-0101-0101-010101010202', '50101010-0101-0101-0101-010101010102', 'Sala de Reunião B', 55.00, 'Sala para 15 pessoas', false),
('60202020-0202-0202-0202-010101010101', '50101010-0101-0101-0101-010101010201', 'Apto 1501', 95.00, 'Apartamento tipo', false),
('60202020-0202-0202-0202-010101010102', '50101010-0101-0101-0101-010101010201', 'Apto 1502', 95.00, 'Apartamento tipo', false)
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- 6. SESSÕES DIÁRIAS (RDO)
-- ============================================

INSERT INTO tb_sessoes_diarias (id, id_encarregado, id_obra, data_sessao, hora_inicio, geo_lat, geo_long, status, observacoes, deletado)
VALUES 
('90101010-0101-0101-0101-010101010101', 'dddddddd-dddd-dddd-dddd-dddddddddddd', '44444444-4444-4444-4444-444444444444', '2026-03-03', '2026-03-03 08:00:00+00:00', -23.5505, -46.6333, 'ABERTA', 'Dia de pintura no térreo', false),
('90101010-0101-0101-0101-010101010102', 'eeeeeeee-eeee-eeee-eeee-eeeeeeeeeeee', '55555555-5555-5555-5555-555555555555', '2026-03-03', '2026-03-03 07:30:00+00:00', -23.5505, -46.6333, 'ABERTA', 'Início da pintura residencial', false)
ON CONFLICT (id) DO NOTHING;

-- ============================================
-- RELATÓRIO FINAL
-- ============================================

SELECT 
  '✅ SEED COMPLETADO COM SUCESSO!' AS status,
  (SELECT COUNT(*) FROM tb_clientes WHERE deletado = false) AS "Total Clientes",
  (SELECT COUNT(*) FROM tb_colaboradores WHERE deletado = false) AS "Total Colaboradores",
  (SELECT COUNT(*) FROM tb_obras WHERE deletado = false) AS "Total Obras",
  (SELECT COUNT(*) FROM tb_pavimentos WHERE deletado = false) AS "Total Pavimentos",
  (SELECT COUNT(*) FROM tb_ambientes WHERE deletado = false) AS "Total Ambientes",
  (SELECT COUNT(*) FROM tb_sessoes_diarias WHERE deletado = false) AS "Total Sessões";
