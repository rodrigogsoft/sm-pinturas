-- Garante existência dos perfis padrão do sistema sem sobrescrever customizações existentes.
INSERT INTO tb_perfis (id, nome, descricao, permissoes_modulos)
VALUES
  (1, 'ADMIN', 'Administrador do sistema', NULL),
  (2, 'GESTOR', 'Gestor com poder de aprovação', NULL),
  (3, 'FINANCEIRO', 'Responsável pelo setor financeiro', NULL),
  (4, 'ENCARREGADO', 'Encarregado de obra (cego financeiramente)', NULL)
ON CONFLICT (id) DO NOTHING;
