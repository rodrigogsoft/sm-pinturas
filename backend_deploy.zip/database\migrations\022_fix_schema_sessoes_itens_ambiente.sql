-- Migration 022: Alinhamento de schema para sessões e elementos de serviço
-- Contexto: corrige incompatibilidades entre entidades TypeORM e banco legado.

-- Sessões: campo usado pela entidade e consultas de encerramento
ALTER TABLE tb_sessoes_diarias
  ADD COLUMN IF NOT EXISTS justificativa TEXT;

-- Elementos de serviço: campos usados na listagem, dashboard e cadastro em lote
ALTER TABLE tb_itens_ambiente
  ADD COLUMN IF NOT EXISTS nome_elemento VARCHAR(200),
  ADD COLUMN IF NOT EXISTS area_medida_total NUMERIC(10,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS progresso NUMERIC(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'ABERTO';

-- Backfill mínimo para evitar registros sem identificação visual
UPDATE tb_itens_ambiente
SET nome_elemento = COALESCE(nome_elemento, 'Elemento')
WHERE nome_elemento IS NULL;
