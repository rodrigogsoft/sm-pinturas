-- Migration 030: Núcleo reutilizável de notificações (eventos, regras, templates, entregas e preferências)
-- Data: 2026-04-06

DO $$ BEGIN
  CREATE TYPE notification_event_status_enum AS ENUM (
    'RECEBIDO',
    'PROCESSADO',
    'IGNORADO',
    'ERRO'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE notification_channel_enum AS ENUM (
    'IN_APP',
    'PUSH',
    'EMAIL'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  CREATE TYPE notification_delivery_status_enum AS ENUM (
    'PENDING',
    'SENT',
    'FAILED',
    'RETRYING'
  );
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS tb_notification_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_type VARCHAR(120) NOT NULL,
  source_module VARCHAR(80) NOT NULL,
  entity_type VARCHAR(80),
  entity_id VARCHAR(80),
  payload JSONB NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  idempotency_key VARCHAR(180) NOT NULL UNIQUE,
  status notification_event_status_enum NOT NULL DEFAULT 'RECEBIDO',
  erro TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notification_events_event_type ON tb_notification_events(event_type);
CREATE INDEX IF NOT EXISTS idx_notification_events_status ON tb_notification_events(status);

CREATE TABLE IF NOT EXISTS tb_notification_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  codigo VARCHAR(120) NOT NULL UNIQUE,
  canal notification_channel_enum NOT NULL,
  titulo_template VARCHAR(200) NOT NULL,
  mensagem_template TEXT NOT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  versao INT NOT NULL DEFAULT 1,
  variaveis JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notification_templates_ativo ON tb_notification_templates(ativo);

CREATE TABLE IF NOT EXISTS tb_notification_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome VARCHAR(120) NOT NULL,
  event_type VARCHAR(120) NOT NULL,
  perfis_destino TEXT,
  ids_usuarios_destino TEXT,
  canais TEXT NOT NULL,
  prioridade VARCHAR(20) NOT NULL DEFAULT 'MEDIA',
  template_codigo VARCHAR(120),
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  dedupe_window_seconds INT NOT NULL DEFAULT 300,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notification_rules_event_type ON tb_notification_rules(event_type);
CREATE INDEX IF NOT EXISTS idx_notification_rules_ativo ON tb_notification_rules(ativo);

CREATE TABLE IF NOT EXISTS tb_notification_deliveries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  id_notificacao UUID NOT NULL REFERENCES tb_notificacoes(id),
  canal notification_channel_enum NOT NULL,
  status notification_delivery_status_enum NOT NULL DEFAULT 'PENDING',
  tentativas INT NOT NULL DEFAULT 0,
  max_tentativas INT NOT NULL DEFAULT 4,
  proxima_tentativa_em TIMESTAMPTZ,
  erro_ultima_tentativa TEXT,
  provedor_resposta JSONB,
  enviado_em TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notification_deliveries_status ON tb_notification_deliveries(status);
CREATE INDEX IF NOT EXISTS idx_notification_deliveries_notificacao ON tb_notification_deliveries(id_notificacao);

CREATE TABLE IF NOT EXISTS tb_user_notification_preferences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  id_usuario UUID NOT NULL REFERENCES tb_usuarios(id),
  event_type VARCHAR(120),
  canal notification_channel_enum NOT NULL,
  habilitado BOOLEAN NOT NULL DEFAULT TRUE,
  quiet_hours_inicio VARCHAR(5),
  quiet_hours_fim VARCHAR(5),
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_user_notification_preferences
  ON tb_user_notification_preferences(id_usuario, canal, event_type);

ALTER TABLE tb_notificacoes
  ADD COLUMN IF NOT EXISTS clicada BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS clicada_em TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS id_evento UUID;

INSERT INTO tb_notification_templates (codigo, canal, titulo_template, mensagem_template, variaveis)
VALUES
  ('tpl.conta_pagar_aberta.in_app', 'IN_APP', 'Conta a pagar aberta', 'Lote {{id_lote}} no valor de R$ {{valor_total}} foi aberto.', '["id_lote", "valor_total"]'::jsonb),
  ('tpl.conta_receber_aberta.in_app', 'IN_APP', 'Conta a receber em aberto', 'Cliente {{cliente_nome}} possui corte em {{dias_ate_corte}} dia(s).', '["cliente_nome", "dias_ate_corte"]'::jsonb),
  ('tpl.os_aberta.in_app', 'IN_APP', 'O.S. aberta', 'A sessão {{id_sessao}} foi iniciada na obra {{id_obra}}.', '["id_sessao", "id_obra"]'::jsonb),
  ('tpl.preco_pendente.in_app', 'IN_APP', 'Preço pendente de aprovação', 'Preço {{id_preco}} aguarda aprovação.', '["id_preco"]'::jsonb)
ON CONFLICT (codigo) DO NOTHING;

INSERT INTO tb_notification_rules (nome, event_type, perfis_destino, canais, prioridade, template_codigo)
VALUES
  ('Conta a pagar aberta para financeiro/gestor', 'CONTA_PAGAR_ABERTA', '2,3', 'IN_APP,PUSH', 'ALTA', 'tpl.conta_pagar_aberta.in_app'),
  ('Conta a receber aberta para financeiro/gestor', 'CONTA_RECEBER_ABERTA', '2,3', 'IN_APP,PUSH', 'ALTA', 'tpl.conta_receber_aberta.in_app'),
  ('OS aberta para gestor/admin', 'OS_ABERTA', '1,2', 'IN_APP', 'MEDIA', 'tpl.os_aberta.in_app'),
  ('Preço pendente para gestor', 'PRECO_APROVACAO_PENDENTE', '2', 'IN_APP,PUSH', 'ALTA', 'tpl.preco_pendente.in_app')
ON CONFLICT DO NOTHING;