-- ================================================================
-- SEED DE DEMONSTRAÇÃO COMPLETO - JB PINTURAS ERP
-- Versão: 1.0.0 | Data de referência: 2026-04-07
-- ================================================================
-- Senha de todos os usuários demo: Admin@2026
-- Hash: $2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG
--
-- Como executar:
--   psql -U postgres -d jbpinturas -f 005_seed_demo_completo.sql
--
-- Usuários criados (email / senha):
--   admin.demo@jbpinturas.com.br    / Admin@2026  (ADMIN)
--   gestor.demo@jbpinturas.com.br   / Admin@2026  (GESTOR)
--   financ.demo@jbpinturas.com.br   / Admin@2026  (FINANCEIRO)
--   enc1.demo@jbpinturas.com.br     / Admin@2026  (ENCARREGADO)
--   enc2.demo@jbpinturas.com.br     / Admin@2026  (ENCARREGADO)
-- ================================================================

BEGIN;

-- ================================================================
-- SEÇÃO 0: PERFIS (garantir existência)
-- ================================================================
INSERT INTO tb_perfis (id, nome, descricao) VALUES
  (1, 'ADMIN',       'Administrador do sistema'),
  (2, 'GESTOR',      'Gestor com poder de aprovação'),
  (3, 'FINANCEIRO',  'Responsável pelo setor financeiro'),
  (4, 'ENCARREGADO', 'Encarregado de obra (cego financeiramente)')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 1: USUÁRIOS DE DEMONSTRAÇÃO
-- ================================================================
INSERT INTO tb_usuarios (id, nome_completo, email, senha_hash, id_perfil, ativo, deletado, created_at) VALUES
  ('aa000001-0000-0000-0000-000000000001', 'Administrador Demo',        'admin.demo@jbpinturas.com.br',  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 1, true, false, '2025-10-01 08:00:00+00'),
  ('aa000001-0000-0000-0000-000000000002', 'Carlos Gestor Demo',        'gestor.demo@jbpinturas.com.br', '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 2, true, false, '2025-10-01 08:00:00+00'),
  ('aa000001-0000-0000-0000-000000000003', 'Fernanda Financeiro Demo',  'financ.demo@jbpinturas.com.br', '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 3, true, false, '2025-10-01 08:00:00+00'),
  ('aa000001-0000-0000-0000-000000000004', 'Ricardo Encarregado Demo',  'enc1.demo@jbpinturas.com.br',  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 4, true, false, '2025-10-15 08:00:00+00'),
  ('aa000001-0000-0000-0000-000000000005', 'Sílvio Encarregado Demo',   'enc2.demo@jbpinturas.com.br',  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 4, true, false, '2025-10-15 08:00:00+00')
ON CONFLICT (email) DO NOTHING;

-- ================================================================
-- SEÇÃO 2: CLIENTES
-- ================================================================
INSERT INTO tb_clientes (id, razao_social, cnpj_nif, email, telefone, endereco, dia_corte, ativo, deletado, created_at) VALUES
  ('bb000002-0000-0000-0000-000000000001', 'Construtora Horizonte Ltda',    '11.222.333/0001-44', 'obras@horizonte.com.br',    '(11) 3200-1000', 'Av. Paulista, 1500, São Paulo/SP',          15, true, false, '2025-08-10 09:00:00+00'),
  ('bb000002-0000-0000-0000-000000000002', 'Incorporadora Verde Vale S.A.',  '22.333.444/0001-55', 'projetos@verdevale.com.br', '(21) 3300-2000', 'Av. das Américas, 700, Rio de Janeiro/RJ',  20, true, false, '2025-09-05 09:00:00+00'),
  ('bb000002-0000-0000-0000-000000000003', 'Shopping Metacentro SPE Ltda',   '33.444.555/0001-66', 'adm@metacentro.com.br',     '(31) 3100-3000', 'Av. do Contorno, 200, Belo Horizonte/MG',   10, true, false, '2025-09-20 09:00:00+00'),
  ('bb000002-0000-0000-0000-000000000004', 'BHG Empreendimentos S.A.',       '44.555.666/0001-77', 'negocios@bhg.com.br',       '(51) 3400-4000', 'Av. Ipiranga, 1000, Porto Alegre/RS',        5, true, false, '2025-10-12 09:00:00+00'),
  ('bb000002-0000-0000-0000-000000000005', 'Real Estate Capital Ltda',       '55.666.777/0001-88', 'contratos@recapital.com.br','(11) 3500-5000', 'Rua Funchal, 400, São Paulo/SP',            25, true, false, '2025-11-03 09:00:00+00'),
  ('bb000002-0000-0000-0000-000000000006', 'Rio Verde Incorporações Ltda',   '66.777.888/0001-99', 'obra@rioverde.com.br',      '(62) 3600-6000', 'Av. T-63, 800, Goiânia/GO',                 28, true, false, '2025-11-28 09:00:00+00')
ON CONFLICT (cnpj_nif) DO NOTHING;

-- ================================================================
-- SEÇÃO 3: COLABORADORES
-- ================================================================
INSERT INTO tb_colaboradores (id, nome, nome_completo, cpf, cpf_nif, email, telefone, data_nascimento, endereco, ativo, deletado, created_at) VALUES
  ('cc000003-0000-0000-0000-000000000001', 'João Silva',     'João Carlos Silva',         '10000000101', '100.000.001-01', 'joao.silva@email.com',     '(11) 97001-0101', '1985-03-15', 'Rua das Flores, 10, São Paulo/SP',    true, false, '2025-10-01 09:00:00+00'),
  ('cc000003-0000-0000-0000-000000000002', 'Maria Santos',   'Maria Aparecida Santos',    '10000000202', '100.000.002-02', 'maria.santos@email.com',   '(11) 97002-0202', '1990-07-22', 'Av. Brasil, 200, São Paulo/SP',       true, false, '2025-10-01 09:00:00+00'),
  ('cc000003-0000-0000-0000-000000000003', 'Carlos Oliveira','Carlos Eduardo Oliveira',   '10000000303', '100.000.003-03', 'carlos.oliv@email.com',    '(11) 97003-0303', '1982-11-08', 'Rua Ipê, 300, São Paulo/SP',          true, false, '2025-10-15 09:00:00+00'),
  ('cc000003-0000-0000-0000-000000000004', 'Ana Lima',       'Ana Paula Lima',            '10000000404', '100.000.004-04', 'ana.lima@email.com',       '(11) 97004-0404', '1995-05-30', 'Rua Cedro, 400, São Paulo/SP',        true, false, '2025-10-15 09:00:00+00'),
  ('cc000003-0000-0000-0000-000000000005', 'Roberto Ferreira','Roberto Luiz Ferreira',   '10000000505', '100.000.005-05', 'roberto.ferr@email.com',   '(11) 97005-0505', '1978-09-12', 'Av. Paulista, 500, São Paulo/SP',     true, false, '2025-11-01 09:00:00+00'),
  ('cc000003-0000-0000-0000-000000000006', 'Patricia Costa', 'Patricia Moura Costa',      '10000000606', '100.000.006-06', 'patricia.c@email.com',     '(11) 97006-0606', '1988-02-17', 'Rua Amendoim, 600, São Paulo/SP',     true, false, '2025-11-01 09:00:00+00'),
  ('cc000003-0000-0000-0000-000000000007', 'Marcos Souza',   'Marcos Antônio Souza',      '10000000707', '100.000.007-07', 'marcos.souza@email.com',   '(11) 97007-0707', '1993-06-25', 'Rua Carvalho, 700, São Paulo/SP',     true, false, '2025-11-15 09:00:00+00')
ON CONFLICT (cpf) DO NOTHING;

-- ================================================================
-- SEÇÃO 4: CATÁLOGO DE SERVIÇOS
-- ================================================================
INSERT INTO tb_servicos_catalogo (nome, unidade_medida, categoria, permite_decimal, descricao, ativo) VALUES
  ('Pintura Látex 2 Demãos (Interno)',   'M2', 'PINTURA',    true,  'Látex econômico ou standard em paredes internas, 2 demãos',      true),
  ('Pintura Acrílica Externa',           'M2', 'PINTURA',    true,  'Tinta acrílica premium para fachadas e áreas externas',          true),
  ('Textura Grafiato',                   'M2', 'ACABAMENTO', true,  'Textura grafiato em paredes internas ou externas',               true),
  ('Massa Corrida + Selador',            'M2', 'ACABAMENTO', true,  'Massa corrida PVA com selador acrílico',                         true),
  ('Gesso Liso (Teto/Parede)',           'M2', 'GESSO',      true,  'Revestimento de gesso liso em teto ou paredes',                  true),
  ('Pintura Epóxi (Piso/Parede)',        'M2', 'PINTURA',    true,  'Tinta epóxi bicomponente para pisos industriais ou cozinhas',    true),
  ('Reboco Fino (Argamassa)',            'M2', 'ALVENARIA',  true,  'Reboco de regularização para pintura posterior',                 true),
  ('Verniz Madeira (Esquadria)',         'M2', 'ACABAMENTO', true,  'Verniz transparente ou pigmentado em esquadrias de madeira',     true)
ON CONFLICT DO NOTHING;

-- ================================================================
-- SEÇÃO 5: OBRAS
-- ================================================================
INSERT INTO tb_obras (id, nome, endereco_completo, status, data_inicio, data_previsao_fim, observacoes, id_cliente, id_usuario_criador, margem_minima_percentual, progresso, deletado, created_at) VALUES
  ('dd000004-0000-0000-0000-000000000001',
   'Edifício Horizonte Tower',
   'Av. Brigadeiro Faria Lima, 3900 — Itaim Bibi, São Paulo/SP',
   'ATIVA', '2026-01-10', '2026-09-30',
   'Reforma completa de 18 andares. Cliente exige relatório semanal.',
   'bb000002-0000-0000-0000-000000000001',
   'aa000001-0000-0000-0000-000000000001',
   20.00, 47.32, false, '2026-01-05 09:00:00+00'),

  ('dd000004-0000-0000-0000-000000000002',
   'Condomínio Verde Vale — Blocos A e B',
   'Rua das Acácias, 500 — Barra da Tijuca, Rio de Janeiro/RJ',
   'ATIVA', '2025-12-01', '2026-08-31',
   'Acabamento dos blocos residenciais A e B. 120 unidades.',
   'bb000002-0000-0000-0000-000000000002',
   'aa000001-0000-0000-0000-000000000001',
   22.00, 58.33, false, '2025-11-25 09:00:00+00'),

  ('dd000004-0000-0000-0000-000000000003',
   'Shopping Metacentro — Expansão L1',
   'Av. do Contorno, 200 — Centro, Belo Horizonte/MG',
   'ATIVA', '2026-02-15', '2026-07-15',
   'Pintura geral do piso L1 da expansão leste. 40 lojas.',
   'bb000002-0000-0000-0000-000000000003',
   'aa000001-0000-0000-0000-000000000001',
   18.00, 33.33, false, '2026-02-10 09:00:00+00'),

  ('dd000004-0000-0000-0000-000000000004',
   'Residencial Alameda Jardins',
   'Rua Alameda Santos, 200 — Jardins, São Paulo/SP',
   'PLANEJAMENTO', '2026-05-01', '2026-12-31',
   'Projeto em fase de planejamento. Aguarda aprovação de preços.',
   'bb000002-0000-0000-0000-000000000004',
   'aa000001-0000-0000-0000-000000000001',
   25.00, 0.00, false, '2026-03-20 09:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 6: PAVIMENTOS
-- ================================================================
INSERT INTO tb_pavimentos (id, id_obra, nome, ordem, nivel, is_cobertura, progresso, status_progresso, deletado, created_at) VALUES
  -- Obra 1 - Horizonte Tower
  ('ee000005-0000-0000-0000-000000000001', 'dd000004-0000-0000-0000-000000000001', 'Térreo',        0, 0,  false, 70.32, 'EM_ANDAMENTO', false, '2026-01-10 10:00:00+00'),
  ('ee000005-0000-0000-0000-000000000002', 'dd000004-0000-0000-0000-000000000001', '1º Andar',      1, 1,  false, 25.00, 'EM_ANDAMENTO', false, '2026-01-10 10:00:00+00'),
  ('ee000005-0000-0000-0000-000000000003', 'dd000004-0000-0000-0000-000000000001', 'Cobertura',     2, 18, true,   0.00, 'ABERTO',       false, '2026-01-10 10:00:00+00'),
  -- Obra 2 - Verde Vale
  ('ee000005-0000-0000-0000-000000000004', 'dd000004-0000-0000-0000-000000000002', 'Bloco A',       0, 0,  false, 87.50, 'EM_ANDAMENTO', false, '2025-12-01 10:00:00+00'),
  ('ee000005-0000-0000-0000-000000000005', 'dd000004-0000-0000-0000-000000000002', 'Bloco B',       1, 0,  false,  0.00, 'ABERTO',       false, '2025-12-01 10:00:00+00'),
  -- Obra 3 - Shopping
  ('ee000005-0000-0000-0000-000000000006', 'dd000004-0000-0000-0000-000000000003', 'Piso L1',       0, 0,  false, 33.33, 'EM_ANDAMENTO', false, '2026-02-15 10:00:00+00'),
  -- Obra 4 - Alameda
  ('ee000005-0000-0000-0000-000000000007', 'dd000004-0000-0000-0000-000000000004', 'Bloco 1',       0, 0,  false,  0.00, 'ABERTO',       false, '2026-03-20 10:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 7: AMBIENTES
-- ================================================================
INSERT INTO tb_ambientes (id, id_pavimento, nome, area_m2, descricao, progresso, status_progresso, deletado, created_at) VALUES
  -- Obra 1 - Térreo
  ('ff000006-0000-0000-0000-000000000001', 'ee000005-0000-0000-0000-000000000001', 'Hall de Entrada',  80.00, 'Área de circulação principal com pé-direito duplo',   65.63, 'EM_ANDAMENTO', false, '2026-01-10 11:00:00+00'),
  ('ff000006-0000-0000-0000-000000000002', 'ee000005-0000-0000-0000-000000000001', 'Recepção',         60.00, 'Recepção administrativa com balcão e espera',          75.00, 'EM_ANDAMENTO', false, '2026-01-10 11:00:00+00'),
  -- Obra 1 - 1º Andar
  ('ff000006-0000-0000-0000-000000000003', 'ee000005-0000-0000-0000-000000000002', 'Apartamento 101',  50.00, 'Unidade tipo — sala, quarto e banheiro',               50.00, 'EM_ANDAMENTO', false, '2026-01-10 11:00:00+00'),
  ('ff000006-0000-0000-0000-000000000004', 'ee000005-0000-0000-0000-000000000002', 'Apartamento 102',  50.00, 'Unidade tipo — sala, quarto e banheiro',                0.00, 'ABERTO',       false, '2026-01-10 11:00:00+00'),
  -- Obra 1 - Cobertura
  ('ff000006-0000-0000-0000-000000000005', 'ee000005-0000-0000-0000-000000000003', 'Área de Lazer',   120.00, 'Piscina + churrasqueira + salão de festas',             0.00, 'ABERTO',       false, '2026-01-10 11:00:00+00'),
  -- Obra 2 - Bloco A
  ('ff000006-0000-0000-0000-000000000006', 'ee000005-0000-0000-0000-000000000004', 'Corredor Bloco A',200.00, 'Corredor de acesso às unidades do Bloco A',            75.00, 'EM_ANDAMENTO', false, '2025-12-01 11:00:00+00'),
  ('ff000006-0000-0000-0000-000000000007', 'ee000005-0000-0000-0000-000000000004', 'Salão de Festas', 100.00, 'Salão de festas compartilhado dos dois blocos',        100.00, 'CONCLUIDO',    false, '2025-12-01 11:00:00+00'),
  -- Obra 2 - Bloco B
  ('ff000006-0000-0000-0000-000000000008', 'ee000005-0000-0000-0000-000000000005', 'Corredor Bloco B',200.00, 'Corredor de acesso às unidades do Bloco B',             0.00, 'ABERTO',       false, '2025-12-01 11:00:00+00'),
  -- Obra 3 - L1
  ('ff000006-0000-0000-0000-000000000009', 'ee000005-0000-0000-0000-000000000006', 'Loja 101',        150.00, 'Loja âncora — 150m² com mezanino',                    66.67, 'EM_ANDAMENTO', false, '2026-02-15 11:00:00+00'),
  ('ff000006-0000-0000-0000-000000000010', 'ee000005-0000-0000-0000-000000000006', 'Loja 102',        120.00, 'Loja satélite — 120m² em frente à praça de alimentação', 0.00, 'ABERTO',      false, '2026-02-15 11:00:00+00'),
  -- Obra 4 - Bloco 1
  ('ff000006-0000-0000-0000-000000000011', 'ee000005-0000-0000-0000-000000000007', 'Tipo A Piloto',    70.00, 'Unidade tipo para aprovação de acabamento',             0.00, 'ABERTO',       false, '2026-03-20 11:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 8: TABELA DE PREÇOS
-- ================================================================
-- Usamos subqueries para obter o id do serviço pelo nome
-- Status variados: APROVADO, PENDENTE, REJEITADO, RASCUNHO

DO $$
DECLARE
  v_admin   UUID := 'aa000001-0000-0000-0000-000000000001';
  v_gestor  UUID := 'aa000001-0000-0000-0000-000000000002';
  v_obra1   UUID := 'dd000004-0000-0000-0000-000000000001';
  v_obra2   UUID := 'dd000004-0000-0000-0000-000000000002';
  v_obra3   UUID := 'dd000004-0000-0000-0000-000000000003';
  v_obra4   UUID := 'dd000004-0000-0000-0000-000000000004';
  v_now     TIMESTAMPTZ := NOW();
  v_svc1    INT; v_svc2 INT; v_svc3 INT; v_svc4 INT;
  v_svc5    INT; v_svc6 INT; v_svc7 INT; v_svc8 INT;
BEGIN
  SELECT id INTO v_svc1 FROM tb_servicos_catalogo WHERE nome = 'Pintura Látex 2 Demãos (Interno)'  LIMIT 1;
  SELECT id INTO v_svc2 FROM tb_servicos_catalogo WHERE nome = 'Pintura Acrílica Externa'           LIMIT 1;
  SELECT id INTO v_svc3 FROM tb_servicos_catalogo WHERE nome = 'Textura Grafiato'                   LIMIT 1;
  SELECT id INTO v_svc4 FROM tb_servicos_catalogo WHERE nome = 'Massa Corrida + Selador'            LIMIT 1;
  SELECT id INTO v_svc5 FROM tb_servicos_catalogo WHERE nome = 'Gesso Liso (Teto/Parede)'          LIMIT 1;
  SELECT id INTO v_svc6 FROM tb_servicos_catalogo WHERE nome = 'Pintura Epóxi (Piso/Parede)'       LIMIT 1;
  SELECT id INTO v_svc7 FROM tb_servicos_catalogo WHERE nome = 'Reboco Fino (Argamassa)'            LIMIT 1;
  SELECT id INTO v_svc8 FROM tb_servicos_catalogo WHERE nome = 'Verniz Madeira (Esquadria)'         LIMIT 1;

  -- ----- OBRA 1: Horizonte Tower -----
  -- Pintura Interna — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0001-0001-0001-000000000001', v_obra1, v_svc1, 8.00, 15.00, 87.50, 'APROVADO', v_admin, v_gestor, '2026-01-12 10:00:00+00', '2026-01-13 14:00:00+00', false, '2026-01-12 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Pintura Externa — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0001-0001-0001-000000000002', v_obra1, v_svc2, 9.00, 17.00, 88.89, 'APROVADO', v_admin, v_gestor, '2026-01-12 10:00:00+00', '2026-01-13 14:00:00+00', false, '2026-01-12 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Grafiato — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0001-0001-0001-000000000003', v_obra1, v_svc3, 12.00, 22.00, 83.33, 'APROVADO', v_admin, v_gestor, '2026-01-12 10:00:00+00', '2026-01-13 14:00:00+00', false, '2026-01-12 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Gesso Liso — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0001-0001-0001-000000000004', v_obra1, v_svc5, 14.00, 25.00, 78.57, 'APROVADO', v_admin, v_gestor, '2026-01-12 10:00:00+00', '2026-01-13 14:00:00+00', false, '2026-01-12 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Massa Corrida — PENDENTE (aguardando aprovação)
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, data_submissao, deletado, created_at)
  VALUES ('pp000008-0001-0001-0001-000000000005', v_obra1, v_svc4, 6.00, 11.00, 83.33, 'PENDENTE', v_admin, '2026-04-01 10:00:00+00', false, '2026-04-01 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- ----- OBRA 2: Verde Vale -----
  -- Pintura Interna — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0002-0002-0002-000000000001', v_obra2, v_svc1, 7.50, 14.00, 86.67, 'APROVADO', v_admin, v_gestor, '2025-11-28 10:00:00+00', '2025-11-29 14:00:00+00', false, '2025-11-28 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Pintura Externa — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0002-0002-0002-000000000002', v_obra2, v_svc2, 9.50, 18.00, 89.47, 'APROVADO', v_admin, v_gestor, '2025-11-28 10:00:00+00', '2025-11-29 14:00:00+00', false, '2025-11-28 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Epóxi — PENDENTE
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, data_submissao, deletado, created_at)
  VALUES ('pp000008-0002-0002-0002-000000000003', v_obra2, v_svc6, 18.00, 32.00, 77.78, 'PENDENTE', v_admin, '2026-04-03 10:00:00+00', false, '2026-04-03 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- ----- OBRA 3: Shopping Metacentro -----
  -- Pintura Externa — APROVADO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_aprovado_por, data_submissao, data_aprovacao, deletado, created_at)
  VALUES ('pp000008-0003-0003-0003-000000000001', v_obra3, v_svc2, 10.00, 19.00, 90.00, 'APROVADO', v_admin, v_gestor, '2026-02-12 10:00:00+00', '2026-02-13 14:00:00+00', false, '2026-02-12 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Pintura Interna — REJEITADO (margem abaixo do mínimo)
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, margem_percentual, status_aprovacao, id_usuario_submissor, id_usuario_rejeitador, data_submissao, data_rejeicao, justificativa_rejeicao, deletado, created_at)
  VALUES ('pp000008-0003-0003-0003-000000000002', v_obra3, v_svc1, 8.50, 10.00, 17.65, 'REJEITADO', v_admin, v_gestor, '2026-02-12 10:00:00+00', '2026-02-13 14:00:00+00', 'Margem de 17,65% é inferior ao mínimo de 18% exigido para esta obra.', false, '2026-02-12 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- Reboco Fino — RASCUNHO
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, status_aprovacao, deletado, created_at)
  VALUES ('pp000008-0003-0003-0003-000000000003', v_obra3, v_svc7, 11.00, 20.00, 'RASCUNHO', false, '2026-03-01 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;

  -- ----- OBRA 4: Residencial Alameda -----
  -- Pintura Interna — RASCUNHO (obra em planejamento)
  INSERT INTO tb_tabela_precos (id, id_obra, id_servico_catalogo, preco_custo, preco_venda, status_aprovacao, deletado, created_at)
  VALUES ('pp000008-0004-0004-0004-000000000001', v_obra4, v_svc1, 9.00, 17.00, 'RASCUNHO', false, '2026-03-25 10:00:00+00')
  ON CONFLICT (id) DO NOTHING;
END $$;

-- ================================================================
-- SEÇÃO 9: ITENS DE AMBIENTE (Elementos de Serviço)
-- ================================================================
-- area_medida_total e progresso refletem as medições acumuladas

INSERT INTO tb_itens_ambiente (id, id_ambiente, id_tabela_preco, nome_elemento, area_planejada, area_medida_total, progresso, status, deletado, created_at) VALUES
  -- Hall de Entrada (amb01): Pintura Interna + Grafiato
  ('ii000009-0000-0000-0000-000000000001', 'ff000006-0000-0000-0000-000000000001', 'pp000008-0001-0001-0001-000000000001', 'Paredes — Pintura Interna',  80.00, 65.00, 81.25, 'EM_ANDAMENTO', false, '2026-01-15 10:00:00+00'),
  ('ii000009-0000-0000-0000-000000000002', 'ff000006-0000-0000-0000-000000000001', 'pp000008-0001-0001-0001-000000000003', 'Faixa de Grafiato Decorat.', 40.00, 20.00, 50.00, 'EM_ANDAMENTO', false, '2026-01-15 10:00:00+00'),
  -- Recepção (amb02): Pintura Interna + Gesso
  ('ii000009-0000-0000-0000-000000000003', 'ff000006-0000-0000-0000-000000000002', 'pp000008-0001-0001-0001-000000000001', 'Paredes — Pintura Interna',  60.00, 60.00, 100.00, 'CONCLUIDO',   false, '2026-01-15 10:00:00+00'),
  ('ii000009-0000-0000-0000-000000000004', 'ff000006-0000-0000-0000-000000000002', 'pp000008-0001-0001-0001-000000000004', 'Teto — Gesso Liso',          60.00, 30.00,  50.00, 'EM_ANDAMENTO', false, '2026-01-15 10:00:00+00'),
  -- Apto 101 (amb03): Pintura Interna
  ('ii000009-0000-0000-0000-000000000005', 'ff000006-0000-0000-0000-000000000003', 'pp000008-0001-0001-0001-000000000001', 'Paredes — Pintura Interna',  50.00, 25.00,  50.00, 'EM_ANDAMENTO', false, '2026-01-15 10:00:00+00'),
  -- Apto 102 (amb04): Pintura Interna (não iniciado)
  ('ii000009-0000-0000-0000-000000000006', 'ff000006-0000-0000-0000-000000000004', 'pp000008-0001-0001-0001-000000000001', 'Paredes — Pintura Interna',  50.00,  0.00,   0.00, 'ABERTO',       false, '2026-01-15 10:00:00+00'),
  -- Área de Lazer/Cobertura (amb05): Pintura Externa
  ('ii000009-0000-0000-0000-000000000007', 'ff000006-0000-0000-0000-000000000005', 'pp000008-0001-0001-0001-000000000002', 'Paredes Externas — Pintura', 120.00,  0.00,   0.00, 'ABERTO',       false, '2026-01-15 10:00:00+00'),
  -- Corredor Bloco A (amb06): Pintura Interna
  ('ii000009-0000-0000-0000-000000000008', 'ff000006-0000-0000-0000-000000000006', 'pp000008-0002-0002-0002-000000000001', 'Paredes — Pintura Interna', 200.00, 150.00,  75.00, 'EM_ANDAMENTO', false, '2025-12-05 10:00:00+00'),
  -- Salão de Festas (amb07): Pintura Interna (concluído)
  ('ii000009-0000-0000-0000-000000000009', 'ff000006-0000-0000-0000-000000000007', 'pp000008-0002-0002-0002-000000000001', 'Paredes — Pintura Interna', 100.00, 100.00, 100.00, 'CONCLUIDO',   false, '2025-12-05 10:00:00+00'),
  -- Corredor Bloco B (amb08): Pintura Externa (não iniciado)
  ('ii000009-0000-0000-0000-000000000010', 'ff000006-0000-0000-0000-000000000008', 'pp000008-0002-0002-0002-000000000002', 'Paredes — Pintura Externa', 200.00,  0.00,   0.00, 'ABERTO',       false, '2025-12-05 10:00:00+00'),
  -- Loja 101 (amb09): Pintura Externa
  ('ii000009-0000-0000-0000-000000000011', 'ff000006-0000-0000-0000-000000000009', 'pp000008-0003-0003-0003-000000000001', 'Paredes Externas — Pintura', 150.00, 100.00,  66.67, 'EM_ANDAMENTO', false, '2026-02-20 10:00:00+00'),
  -- Loja 102 (amb10): Pintura Externa (não iniciado)
  ('ii000009-0000-0000-0000-000000000012', 'ff000006-0000-0000-0000-000000000010', 'pp000008-0003-0003-0003-000000000001', 'Paredes Externas — Pintura', 120.00,  0.00,   0.00, 'ABERTO',       false, '2026-02-20 10:00:00+00'),
  -- Tipo A Piloto (amb11): Pintura Interna
  ('ii000009-0000-0000-0000-000000000013', 'ff000006-0000-0000-0000-000000000011', 'pp000008-0004-0004-0004-000000000001', 'Paredes — Pintura Interna',  70.00,  0.00,   0.00, 'ABERTO',       false, '2026-03-25 10:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 10: SESSÕES DIÁRIAS (RDO)
-- ================================================================
INSERT INTO tb_sessoes_diarias (id, id_encarregado, id_obra, data_sessao, hora_inicio, hora_fim, geo_lat, geo_long, status, observacoes, deletado, created_at) VALUES
  -- Enc1 / Obra1 — sessões encerradas
  ('ss000010-0000-0000-0000-000000000001', 'aa000001-0000-0000-0000-000000000004', 'dd000004-0000-0000-0000-000000000001', '2026-03-08', '2026-03-08 07:30:00+00', '2026-03-08 17:00:00+00', -23.5660, -46.6511, 'ENCERRADA', 'Início dos trabalhos no térreo.',                      false, '2026-03-08 07:30:00+00'),
  ('ss000010-0000-0000-0000-000000000002', 'aa000001-0000-0000-0000-000000000004', 'dd000004-0000-0000-0000-000000000001', '2026-03-13', '2026-03-13 07:30:00+00', '2026-03-13 17:00:00+00', -23.5660, -46.6511, 'ENCERRADA', 'Continuação pintura recepção e início do gesso.',       false, '2026-03-13 07:30:00+00'),
  ('ss000010-0000-0000-0000-000000000003', 'aa000001-0000-0000-0000-000000000004', 'dd000004-0000-0000-0000-000000000001', '2026-03-18', '2026-03-18 07:30:00+00', '2026-03-18 17:00:00+00', -23.5660, -46.6511, 'ENCERRADA', 'Segunda passagem no hall de entrada — demão de acabamento.', false, '2026-03-18 07:30:00+00'),
  ('ss000010-0000-0000-0000-000000000004', 'aa000001-0000-0000-0000-000000000004', 'dd000004-0000-0000-0000-000000000001', '2026-03-23', '2026-03-23 07:30:00+00', '2026-03-23 17:00:00+00', -23.5660, -46.6511, 'ENCERRADA', 'Início do 1º andar — Apto 101.',                        false, '2026-03-23 07:30:00+00'),
  -- Enc2 / Obra2 — sessões encerradas
  ('ss000010-0000-0000-0000-000000000005', 'aa000001-0000-0000-0000-000000000005', 'dd000004-0000-0000-0000-000000000002', '2026-03-10', '2026-03-10 07:00:00+00', '2026-03-10 16:30:00+00', -22.9068, -43.1729, 'ENCERRADA', 'Início Bloco A — corredor pavimento térreo.',           false, '2026-03-10 07:00:00+00'),
  ('ss000010-0000-0000-0000-000000000006', 'aa000001-0000-0000-0000-000000000005', 'dd000004-0000-0000-0000-000000000002', '2026-03-18', '2026-03-18 07:00:00+00', '2026-03-18 16:30:00+00', -22.9068, -43.1729, 'ENCERRADA', 'Continuação corredor e pintura do salão de festas.',    false, '2026-03-18 07:00:00+00'),
  -- Enc2 / Obra3
  ('ss000010-0000-0000-0000-000000000007', 'aa000001-0000-0000-0000-000000000005', 'dd000004-0000-0000-0000-000000000003', '2026-03-28', '2026-03-28 07:00:00+00', '2026-03-28 16:30:00+00', -19.9167, -43.9345, 'ENCERRADA', 'Shopping Metacentro — pintura fachada Loja 101.',       false, '2026-03-28 07:00:00+00'),
  -- Enc1 / Obra1 — sessão ABERTA (em andamento)
  ('ss000010-0000-0000-0000-000000000008', 'aa000001-0000-0000-0000-000000000004', 'dd000004-0000-0000-0000-000000000001', '2026-04-02', '2026-04-02 07:30:00+00', NULL,                     -23.5660, -46.6511, 'ABERTA',    'Início da cobertura — área de lazer.',                  false, '2026-04-02 07:30:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 11: ALOCAÇÕES DE ITENS (ERS 4.1)
-- ================================================================
INSERT INTO tb_alocacoes_itens (id, id_sessao, id_ambiente, id_item_ambiente, id_colaborador, id_tabela_preco, status, hora_inicio, hora_fim, deletado, created_at) VALUES
  -- Sessão 1 (2026-03-08 / Obra1 Térreo)
  ('kk000011-0000-0000-0000-000000000001', 'ss000010-0000-0000-0000-000000000001', 'ff000006-0000-0000-0000-000000000001', 'ii000009-0000-0000-0000-000000000001', 'cc000003-0000-0000-0000-000000000001', 'pp000008-0001-0001-0001-000000000001', 'CONCLUIDO', '2026-03-08 08:00:00+00', '2026-03-08 17:00:00+00', false, '2026-03-08 08:00:00+00'),
  ('kk000011-0000-0000-0000-000000000002', 'ss000010-0000-0000-0000-000000000001', 'ff000006-0000-0000-0000-000000000001', 'ii000009-0000-0000-0000-000000000002', 'cc000003-0000-0000-0000-000000000002', 'pp000008-0001-0001-0001-000000000003', 'CONCLUIDO', '2026-03-08 08:00:00+00', '2026-03-08 17:00:00+00', false, '2026-03-08 08:00:00+00'),
  -- Sessão 2 (2026-03-13 / Obra1 Térreo)
  ('kk000011-0000-0000-0000-000000000003', 'ss000010-0000-0000-0000-000000000002', 'ff000006-0000-0000-0000-000000000002', 'ii000009-0000-0000-0000-000000000003', 'cc000003-0000-0000-0000-000000000001', 'pp000008-0001-0001-0001-000000000001', 'CONCLUIDO', '2026-03-13 08:00:00+00', '2026-03-13 17:00:00+00', false, '2026-03-13 08:00:00+00'),
  ('kk000011-0000-0000-0000-000000000004', 'ss000010-0000-0000-0000-000000000002', 'ff000006-0000-0000-0000-000000000002', 'ii000009-0000-0000-0000-000000000004', 'cc000003-0000-0000-0000-000000000003', 'pp000008-0001-0001-0001-000000000004', 'CONCLUIDO', '2026-03-13 08:00:00+00', '2026-03-13 17:00:00+00', false, '2026-03-13 08:00:00+00'),
  -- Sessão 3 (2026-03-18 / Obra1 Térreo — segunda passagem hall)
  ('kk000011-0000-0000-0000-000000000005', 'ss000010-0000-0000-0000-000000000003', 'ff000006-0000-0000-0000-000000000001', 'ii000009-0000-0000-0000-000000000001', 'cc000003-0000-0000-0000-000000000002', 'pp000008-0001-0001-0001-000000000001', 'CONCLUIDO', '2026-03-18 08:00:00+00', '2026-03-18 17:00:00+00', false, '2026-03-18 08:00:00+00'),
  -- Sessão 4 (2026-03-23 / Obra1 1º Andar)
  ('kk000011-0000-0000-0000-000000000006', 'ss000010-0000-0000-0000-000000000004', 'ff000006-0000-0000-0000-000000000003', 'ii000009-0000-0000-0000-000000000005', 'cc000003-0000-0000-0000-000000000004', 'pp000008-0001-0001-0001-000000000001', 'CONCLUIDO', '2026-03-23 08:00:00+00', '2026-03-23 17:00:00+00', false, '2026-03-23 08:00:00+00'),
  -- Sessão 5 (2026-03-10 / Obra2 Corredor A)
  ('kk000011-0000-0000-0000-000000000007', 'ss000010-0000-0000-0000-000000000005', 'ff000006-0000-0000-0000-000000000006', 'ii000009-0000-0000-0000-000000000008', 'cc000003-0000-0000-0000-000000000005', 'pp000008-0002-0002-0002-000000000001', 'CONCLUIDO', '2026-03-10 08:00:00+00', '2026-03-10 16:30:00+00', false, '2026-03-10 08:00:00+00'),
  -- Sessão 6 (2026-03-18 / Obra2 Corredor A continuação + Salão)
  ('kk000011-0000-0000-0000-000000000008', 'ss000010-0000-0000-0000-000000000006', 'ff000006-0000-0000-0000-000000000006', 'ii000009-0000-0000-0000-000000000008', 'cc000003-0000-0000-0000-000000000006', 'pp000008-0002-0002-0002-000000000001', 'CONCLUIDO', '2026-03-18 08:00:00+00', '2026-03-18 16:30:00+00', false, '2026-03-18 08:00:00+00'),
  ('kk000011-0000-0000-0000-000000000009', 'ss000010-0000-0000-0000-000000000006', 'ff000006-0000-0000-0000-000000000007', 'ii000009-0000-0000-0000-000000000009', 'cc000003-0000-0000-0000-000000000007', 'pp000008-0002-0002-0002-000000000001', 'CONCLUIDO', '2026-03-18 08:00:00+00', '2026-03-18 16:30:00+00', false, '2026-03-18 08:00:00+00'),
  -- Sessão 7 (2026-03-28 / Obra3 Loja 101)
  ('kk000011-0000-0000-0000-000000000010', 'ss000010-0000-0000-0000-000000000007', 'ff000006-0000-0000-0000-000000000009', 'ii000009-0000-0000-0000-000000000011', 'cc000003-0000-0000-0000-000000000005', 'pp000008-0003-0003-0003-000000000001', 'CONCLUIDO', '2026-03-28 08:00:00+00', '2026-03-28 16:30:00+00', false, '2026-03-28 08:00:00+00'),
  -- Sessão 8 (2026-04-02 / Obra1 Cobertura — EM ANDAMENTO)
  ('kk000011-0000-0000-0000-000000000011', 'ss000010-0000-0000-0000-000000000008', 'ff000006-0000-0000-0000-000000000005', 'ii000009-0000-0000-0000-000000000007', 'cc000003-0000-0000-0000-000000000001', 'pp000008-0001-0001-0001-000000000002', 'EM_ANDAMENTO', '2026-04-02 08:00:00+00', NULL, false, '2026-04-02 08:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 12: MEDIÇÕES DE COLABORADOR (ERS 4.1)
-- ================================================================
-- valor_calculado = qtd_executada * preco_custo
-- Lotes serão vinculados na seção 13

INSERT INTO tb_medicoes_colaborador (id, id_alocacao_item, id_colaborador, id_item_ambiente, qtd_executada, area_planejada, percentual_conclusao_item, flag_excedente, status_pagamento, data_medicao, deletado, created_at) VALUES
  -- med01: aloc1 — João, itm1 (Pintura Hall), 40m² (50% do planejado)
  ('mm000012-0000-0000-0000-000000000001', 'kk000011-0000-0000-0000-000000000001', 'cc000003-0000-0000-0000-000000000001', 'ii000009-0000-0000-0000-000000000001', 40.00,  80.00, 50.00, false, 'PAGO',         '2026-03-08', false, '2026-03-08 17:30:00+00'),
  -- med02: aloc2 — Maria, itm2 (Grafiato Hall), 20m²
  ('mm000012-0000-0000-0000-000000000002', 'kk000011-0000-0000-0000-000000000002', 'cc000003-0000-0000-0000-000000000002', 'ii000009-0000-0000-0000-000000000002', 20.00,  40.00, 50.00, false, 'PAGO',         '2026-03-08', false, '2026-03-08 17:30:00+00'),
  -- med03: aloc3 — João, itm3 (Pintura Recepção), 60m² (100% — concluído)
  ('mm000012-0000-0000-0000-000000000003', 'kk000011-0000-0000-0000-000000000003', 'cc000003-0000-0000-0000-000000000001', 'ii000009-0000-0000-0000-000000000003', 60.00,  60.00,100.00, false, 'PAGO',         '2026-03-13', false, '2026-03-13 17:30:00+00'),
  -- med04: aloc4 — Carlos, itm4 (Gesso Recepção), 30m²
  ('mm000012-0000-0000-0000-000000000004', 'kk000011-0000-0000-0000-000000000004', 'cc000003-0000-0000-0000-000000000003', 'ii000009-0000-0000-0000-000000000004', 30.00,  60.00, 50.00, false, 'PAGO',         '2026-03-13', false, '2026-03-13 17:30:00+00'),
  -- med05: aloc5 — Maria, itm1 (Pintura Hall 2ª demão), 25m² (total 65m²=81%)
  ('mm000012-0000-0000-0000-000000000005', 'kk000011-0000-0000-0000-000000000005', 'cc000003-0000-0000-0000-000000000002', 'ii000009-0000-0000-0000-000000000001', 25.00,  80.00, 81.25, false, 'PAGO',         '2026-03-18', false, '2026-03-18 17:30:00+00'),
  -- med06: aloc6 — Ana, itm5 (Pintura Apto101), 25m²
  ('mm000012-0000-0000-0000-000000000006', 'kk000011-0000-0000-0000-000000000006', 'cc000003-0000-0000-0000-000000000004', 'ii000009-0000-0000-0000-000000000005', 25.00,  50.00, 50.00, false, 'LOTE_CRIADO',  '2026-03-23', false, '2026-03-23 17:30:00+00'),
  -- med07: aloc7 — Roberto, itm8 (Corredor A 1ª parte), 80m²
  ('mm000012-0000-0000-0000-000000000007', 'kk000011-0000-0000-0000-000000000007', 'cc000003-0000-0000-0000-000000000005', 'ii000009-0000-0000-0000-000000000008', 80.00, 200.00, 40.00, false, 'PAGO',         '2026-03-10', false, '2026-03-10 17:00:00+00'),
  -- med08: aloc8 — Patricia, itm8 (Corredor A 2ª parte), 70m² (total 150m²=75%)
  ('mm000012-0000-0000-0000-000000000008', 'kk000011-0000-0000-0000-000000000008', 'cc000003-0000-0000-0000-000000000006', 'ii000009-0000-0000-0000-000000000008', 70.00, 200.00, 75.00, false, 'PAGO',         '2026-03-18', false, '2026-03-18 17:00:00+00'),
  -- med09: aloc9 — Marcos, itm9 (Salão Festas), 100m² (100% concluído)
  ('mm000012-0000-0000-0000-000000000009', 'kk000011-0000-0000-0000-000000000009', 'cc000003-0000-0000-0000-000000000007', 'ii000009-0000-0000-0000-000000000009',100.00, 100.00,100.00, false, 'PAGO',         '2026-03-18', false, '2026-03-18 17:00:00+00'),
  -- med10: aloc10 — Roberto, itm11 (Loja 101), 100m² — ainda sem lote
  ('mm000012-0000-0000-0000-000000000010', 'kk000011-0000-0000-0000-000000000010', 'cc000003-0000-0000-0000-000000000005', 'ii000009-0000-0000-0000-000000000011',100.00, 150.00, 66.67, false, 'ABERTO',       '2026-03-28', false, '2026-03-28 17:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 13: LOTES DE PAGAMENTO
-- ================================================================
-- Valores calculados:
--   Lote1 (PAGO):  med1(40×R$8)+med2(20×R$12)+med3(60×R$8)+med7(80×R$7.50) = R$1.640,00
--   Lote2 (PAGO):  med4(30×R$14)+med5(25×R$8)+med8(70×R$7.50)+med9(100×R$7.50) = R$1.895,00
--   Lote3 (ABERTO): med6(25×R$8)+med10(100×R$10) = R$1.200,00

INSERT INTO tb_lotes_pagamento (id, descricao, data_competencia, data_pagamento, valor_total, qtd_medicoes, status, tipo_pagamento, id_criado_por, id_aprovado_por, observacoes, deletado, created_at) VALUES
  ('ll000013-0000-0000-0000-000000000001',
   'Folha de Pagamento — Semana 1 Março/2026',
   '2026-03-01', '2026-03-15',
   1640.00, 4, 'PAGO', 'PIX',
   'aa000001-0000-0000-0000-000000000003',
   'aa000001-0000-0000-0000-000000000002',
   'med01 (João R$320) + med02 (Maria R$240) + med03 (João R$480) + med07 (Roberto R$600)',
   false, '2026-03-14 10:00:00+00'),

  ('ll000013-0000-0000-0000-000000000002',
   'Folha de Pagamento — Semana 2 Março/2026',
   '2026-03-15', '2026-03-28',
   1895.00, 4, 'PAGO', 'PIX',
   'aa000001-0000-0000-0000-000000000003',
   'aa000001-0000-0000-0000-000000000002',
   'med04 (Carlos R$420) + med05 (Maria R$200) + med08 (Patricia R$525) + med09 (Marcos R$750)',
   false, '2026-03-27 10:00:00+00'),

  ('ll000013-0000-0000-0000-000000000003',
   'Folha de Pagamento — Abril/2026',
   '2026-04-01', NULL,
   1200.00, 2, 'AGUARDANDO_APROVACAO', 'PIX',
   'aa000001-0000-0000-0000-000000000003',
   NULL,
   'med06 (Ana R$200) + med10 (Roberto R$1.000). Aguarda aprovação do gestor.',
   false, '2026-04-05 10:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- Vincular medições aos lotes
UPDATE tb_medicoes_colaborador SET id_lote_pagamento = 'll000013-0000-0000-0000-000000000001', status_pagamento = 'PAGO'
  WHERE id IN (
    'mm000012-0000-0000-0000-000000000001',
    'mm000012-0000-0000-0000-000000000002',
    'mm000012-0000-0000-0000-000000000003',
    'mm000012-0000-0000-0000-000000000007'
  ) AND deletado = false;

UPDATE tb_medicoes_colaborador SET id_lote_pagamento = 'll000013-0000-0000-0000-000000000002', status_pagamento = 'PAGO'
  WHERE id IN (
    'mm000012-0000-0000-0000-000000000004',
    'mm000012-0000-0000-0000-000000000005',
    'mm000012-0000-0000-0000-000000000008',
    'mm000012-0000-0000-0000-000000000009'
  ) AND deletado = false;

UPDATE tb_medicoes_colaborador SET id_lote_pagamento = 'll000013-0000-0000-0000-000000000003', status_pagamento = 'LOTE_CRIADO'
  WHERE id IN (
    'mm000012-0000-0000-0000-000000000006',
    'mm000012-0000-0000-0000-000000000010'
  ) AND deletado = false;

-- ================================================================
-- SEÇÃO 14: VALES DE ADIANTAMENTO
-- ================================================================
INSERT INTO tb_vales_adiantamento (id, id_colaborador, id_obra, data_solicitacao, data_aprovacao, valor_solicitado, valor_aprovado, status, motivo, observacoes, id_aprovado_por, deletado, created_at) VALUES
  -- Vale 1: João Silva / Obra1 — PAGO (quitado via desconto em lotes)
  ('vv000014-0000-0000-0000-000000000001',
   'cc000003-0000-0000-0000-000000000001',
   'dd000004-0000-0000-0000-000000000001',
   '2026-02-20', '2026-02-21', 500.00, 500.00,
   'COMPENSADO',
   'Pagamento de aluguel — emergência familiar',
   'Valor descontado em 2 parcelas de R$250 nos lotes de março.',
   'aa000001-0000-0000-0000-000000000002',
   false, '2026-02-20 14:00:00+00'),

  -- Vale 2: Roberto Ferreira / Obra2 — APROVADO (pagamento pendente)
  ('vv000014-0000-0000-0000-000000000002',
   'cc000003-0000-0000-0000-000000000005',
   'dd000004-0000-0000-0000-000000000002',
   '2026-03-25', '2026-03-26', 400.00, 300.00,
   'APROVADO',
   'Medicação urgente — aprovado parcialmente R$300',
   'Desconto será aplicado no próximo lote.',
   'aa000001-0000-0000-0000-000000000002',
   false, '2026-03-25 10:00:00+00'),

  -- Vale 3: Carlos Oliveira / Obra1 — SOLICITADO (aguardando aprovação)
  ('vv000014-0000-0000-0000-000000000003',
   'cc000003-0000-0000-0000-000000000003',
   'dd000004-0000-0000-0000-000000000001',
   '2026-04-05', NULL, 250.00, NULL,
   'SOLICITADO',
   'Transporte para obra em feriado prolongado',
   NULL,
   NULL,
   false, '2026-04-05 09:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- Parcelas do vale 1 (compensado: 2 × R$250)
INSERT INTO tb_vales_adiantamento_parcelas (id, id_vale_adiantamento, numero_parcela, valor_parcela, data_prevista_desconto, data_desconto_realizado, status, id_lote_pagamento, deletado, created_at) VALUES
  ('vv000014-0000-0000-0001-000000000001', 'vv000014-0000-0000-0000-000000000001', 1, 250.00, '2026-03-15', '2026-03-15', 'DESCONTADO', 'll000013-0000-0000-0000-000000000001', false, '2026-02-21 09:00:00+00'),
  ('vv000014-0000-0000-0001-000000000002', 'vv000014-0000-0000-0000-000000000001', 2, 250.00, '2026-03-28', '2026-03-28', 'DESCONTADO', 'll000013-0000-0000-0000-000000000002', false, '2026-02-21 09:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- Parcela do vale 2 (pendente de desconto)
INSERT INTO tb_vales_adiantamento_parcelas (id, id_vale_adiantamento, numero_parcela, valor_parcela, data_prevista_desconto, status, deletado, created_at) VALUES
  ('vv000014-0000-0000-0002-000000000001', 'vv000014-0000-0000-0000-000000000002', 1, 300.00, '2026-04-15', 'PENDENTE', false, '2026-03-26 09:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- Parcela do vale 3 (ainda sem aprovação — inserida como PENDENTE)
INSERT INTO tb_vales_adiantamento_parcelas (id, id_vale_adiantamento, numero_parcela, valor_parcela, data_prevista_desconto, status, deletado, created_at) VALUES
  ('vv000014-0000-0000-0003-000000000001', 'vv000014-0000-0000-0000-000000000003', 1, 250.00, '2026-04-30', 'PENDENTE', false, '2026-04-05 09:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- SEÇÃO 15: NOTIFICAÇÕES
-- ================================================================
INSERT INTO tb_notificacoes (id, id_usuario_destinatario, tipo, titulo, mensagem, prioridade, lida, lida_em, id_entidade_relacionada, tipo_entidade, deletado, created_at) VALUES

  -- ---- ADMIN ----
  ('nn000015-0001-0001-0001-000000000001',
   'aa000001-0000-0000-0000-000000000001',
   'PRECO_PENDENTE', 'Preços aguardando aprovação',
   '2 novos preços foram submetidos para aprovação: Massa Corrida (Horizonte Tower) e Pintura Epóxi (Verde Vale). Margens dentro do mínimo exigido.',
   'ALTA', false, NULL,
   'pp000008-0001-0001-0001-000000000005', 'tb_tabela_precos',
   false, '2026-04-03 10:05:00+00'),

  ('nn000015-0001-0001-0001-000000000002',
   'aa000001-0000-0000-0000-000000000001',
   'LOTE_APROVACAO', 'Lote de abril aguarda aprovação',
   'Folha de Pagamento — Abril/2026 (R$ 1.200,00 para 2 medições) foi enviada para aprovação pelo financeiro. Aguarda validação do gestor.',
   'MEDIA', false, NULL,
   'll000013-0000-0000-0000-000000000003', 'tb_lotes_pagamento',
   false, '2026-04-05 10:10:00+00'),

  ('nn000015-0001-0001-0001-000000000003',
   'aa000001-0000-0000-0000-000000000001',
   'OBRA_ATRASO', 'Shopping Metacentro com progresso abaixo do esperado',
   'A obra Shopping Metacentro — Expansão L1 está com 33% de progresso, enquanto o esperado para esta data é 45%. Verifique o plano de trabalho.',
   'ALTA', true, '2026-04-06 08:30:00+00',
   'dd000004-0000-0000-0000-000000000003', 'tb_obras',
   false, '2026-04-04 08:00:00+00'),

  -- ---- GESTOR ----
  ('nn000015-0001-0001-0001-000000000004',
   'aa000001-0000-0000-0000-000000000002',
   'PRECO_PENDENTE', 'Massa Corrida — Horizonte Tower aguarda aprovação',
   'Ricardo Encarregado submeteu o preço de Massa Corrida + Selador para a obra Edifício Horizonte Tower: Custo R$6,00/m² | Venda R$11,00/m² | Margem 83,33%.',
   'ALTA', false, NULL,
   'pp000008-0001-0001-0001-000000000005', 'tb_tabela_precos',
   false, '2026-04-01 10:05:00+00'),

  ('nn000015-0001-0001-0001-000000000005',
   'aa000001-0000-0000-0000-000000000002',
   'PRECO_PENDENTE', 'Pintura Epóxi — Verde Vale aguarda aprovação',
   'Ricardo Encarregado submeteu o preço de Pintura Epóxi para Verde Vale: Custo R$18,00/m² | Venda R$32,00/m² | Margem 77,78% (acima dos 22% mínimos).',
   'ALTA', false, NULL,
   'pp000008-0002-0002-0002-000000000003', 'tb_tabela_precos',
   false, '2026-04-03 10:05:00+00'),

  ('nn000015-0001-0001-0001-000000000006',
   'aa000001-0000-0000-0000-000000000002',
   'LOTE_APROVACAO', 'Folha Abril/2026 — R$ 1.200,00 aguarda aprovação',
   'A Folha de Pagamento de Abril/2026 foi gerada com 2 medições, totalizando R$ 1.200,00. Ana Lima: R$ 200,00 | Roberto Ferreira: R$ 1.000,00. Approve para liberar PIX.',
   'ALTA', false, NULL,
   'll000013-0000-0000-0000-000000000003', 'tb_lotes_pagamento',
   false, '2026-04-05 10:10:00+00'),

  ('nn000015-0001-0001-0001-000000000007',
   'aa000001-0000-0000-0000-000000000002',
   'MEDICAO_PENDENTE', 'Medições do Lote 2 de março foram validadas',
   '4 medições totalizando R$ 1.895,00 foram incluídas no Lote 2 de março e aprovadas para pagamento. Pagamento realizado em 28/03/2026.',
   'MEDIA', true, '2026-03-28 16:00:00+00',
   'll000013-0000-0000-0000-000000000002', 'tb_lotes_pagamento',
   false, '2026-03-27 11:00:00+00'),

  -- ---- FINANCEIRO ----
  ('nn000015-0001-0001-0001-000000000008',
   'aa000001-0000-0000-0000-000000000003',
   'CICLO_FATURAMENTO', 'Ciclo de faturamento Construtora Horizonte vence em 5 dias',
   'O dia de corte da Construtora Horizonte Ltda é 15/04. Existem medições em aberto (R$ 1.200,00) que precisam ser faturadas antes desta data.',
   'ALTA', false, NULL,
   'bb000002-0000-0000-0000-000000000001', 'tb_clientes',
   false, '2026-04-07 07:00:00+00'),

  ('nn000015-0001-0001-0001-000000000009',
   'aa000001-0000-0000-0000-000000000003',
   'LOTE_APROVACAO', 'Folha Abril aprovada — realizar pagamento via PIX',
   'O gestor Carlos Rodrigues aprovou a Folha de Pagamento Abril/2026 (R$ 1.200,00). Realize o pagamento via PIX até 15/04/2026.',
   'ALTA', false, NULL,
   'll000013-0000-0000-0000-000000000003', 'tb_lotes_pagamento',
   false, '2026-04-06 14:00:00+00'),

  ('nn000015-0001-0001-0001-000000000010',
   'aa000001-0000-0000-0000-000000000003',
   'SISTEMA', 'Relatório de produção de março disponível',
   'O relatório consolidado de produção de março/2026 está disponível: 9 medições | R$ 3.535,00 em folhas pagas | 4 colaboradores remunerados.',
   'BAIXA', true, '2026-04-01 09:15:00+00',
   NULL, NULL,
   false, '2026-04-01 08:00:00+00'),

  -- ---- ENCARREGADO 1 ----
  ('nn000015-0001-0001-0001-000000000011',
   'aa000001-0000-0000-0000-000000000004',
   'SISTEMA', 'Sessão de 02/04/2026 — Cobertura ativa',
   'Sua sessão de hoje na obra Edifício Horizonte Tower (Cobertura — Área de Lazer) está em aberto. Encerre ao final do dia com assinatura do responsável.',
   'BAIXA', true, '2026-04-02 08:35:00+00',
   'ss000010-0000-0000-0000-000000000008', 'tb_sessoes_diarias',
   false, '2026-04-02 08:00:00+00'),

  -- ---- ENCARREGADO 2 ----
  ('nn000015-0001-0001-0001-000000000012',
   'aa000001-0000-0000-0000-000000000005',
   'SISTEMA', 'Nova obra disponível — Shopping Metacentro L1',
   'Você foi designado como encarregado da obra Shopping Metacentro — Expansão L1. Acesse o painel para ver os ambientes e itens pendentes.',
   'MEDIA', false, NULL,
   'dd000004-0000-0000-0000-000000000003', 'tb_obras',
   false, '2026-02-15 09:00:00+00')
ON CONFLICT (id) DO NOTHING;

-- ================================================================
-- VERIFICAÇÃO FINAL
-- ================================================================
SELECT
  'SEED 005 EXECUTADO COM SUCESSO' AS status,
  (SELECT COUNT(*) FROM tb_usuarios      WHERE email LIKE '%.demo@jbpinturas.com.br')  AS usuarios_demo,
  (SELECT COUNT(*) FROM tb_clientes      WHERE id LIKE 'bb000002%')                     AS clientes,
  (SELECT COUNT(*) FROM tb_colaboradores WHERE id LIKE 'cc000003%')                     AS colaboradores,
  (SELECT COUNT(*) FROM tb_servicos_catalogo WHERE deletado = false)                    AS servicos_catalogo,
  (SELECT COUNT(*) FROM tb_obras         WHERE id LIKE 'dd000004%')                     AS obras,
  (SELECT COUNT(*) FROM tb_pavimentos    WHERE id LIKE 'ee000005%')                     AS pavimentos,
  (SELECT COUNT(*) FROM tb_ambientes     WHERE id LIKE 'ff000006%')                     AS ambientes,
  (SELECT COUNT(*) FROM tb_tabela_precos WHERE id LIKE 'pp000008%')                     AS precos,
  (SELECT COUNT(*) FROM tb_itens_ambiente WHERE id LIKE 'ii000009%')                    AS itens_ambiente,
  (SELECT COUNT(*) FROM tb_sessoes_diarias WHERE id LIKE 'ss000010%')                   AS sessoes,
  (SELECT COUNT(*) FROM tb_alocacoes_itens WHERE id LIKE 'kk000011%')                   AS alocacoes,
  (SELECT COUNT(*) FROM tb_medicoes_colaborador WHERE id LIKE 'mm000012%')              AS medicoes,
  (SELECT COUNT(*) FROM tb_lotes_pagamento WHERE id LIKE 'll000013%')                   AS lotes,
  (SELECT COUNT(*) FROM tb_vales_adiantamento WHERE id LIKE 'vv000014%')               AS vales,
  (SELECT COUNT(*) FROM tb_notificacoes  WHERE id LIKE 'nn000015%')                     AS notificacoes;

COMMIT;
