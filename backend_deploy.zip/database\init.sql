-- =============================================
-- JB PINTURAS - ERP de Gestão de Obras
-- Schema: PostgreSQL 15+
-- Versão ERS: 4.0
-- =============================================

-- Configurar encoding UTF-8 para banco de dados
CREATE DATABASE jb_pinturas_db_utf8_check ENCODING 'UTF8' LOCALE 'pt_BR.UTF-8' LC_COLLATE 'pt_BR.UTF-8' LC_CTYPE 'pt_BR.UTF-8';
DROP DATABASE IF EXISTS jb_pinturas_db_utf8_check;

-- Verificar encoding atual e ajustar se necessário
-- Se por algum motivo não está em UTF-8, esta query vai demonstrar o problema
SELECT datname, pg_encoding_to_char(encoding), datcollate FROM pg_database WHERE datname = 'jb_pinturas_db';

-- Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- Para busca full-text

-- =============================================
-- DOMÍNIO: IDENTIDADE E SEGURANÇA (IAM)
-- =============================================

-- Tabela de Perfis (Estática)
CREATE TABLE IF NOT EXISTS tb_perfis (
    id INT PRIMARY KEY CHECK (id IN (1, 2, 3, 4)),
    nome VARCHAR(50) UNIQUE NOT NULL,
    permissoes_json JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed inicial de perfis
INSERT INTO tb_perfis (id, nome, permissoes_json) VALUES
(1, 'ADMINISTRADOR', '{"can_manage_users": true, "can_view_audit": true, "can_force_billing": true}'),
(2, 'GESTOR', '{"can_approve_prices": true, "can_view_margins": true, "can_view_sensitive_data": true}'),
(3, 'FINANCEIRO', '{"can_create_prices": true, "can_manage_payments": true, "can_view_sensitive_data": true}'),
(4, 'ENCARREGADO', '{"can_create_obras": true, "can_allocate_tasks": true, "can_register_production": true}')
ON CONFLICT (id) DO NOTHING;

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS tb_usuarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome_completo VARCHAR(150) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    id_perfil INT NOT NULL REFERENCES tb_perfis(id),
    fcm_token VARCHAR(255),
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    mfa_secret VARCHAR(255), -- TOTP secret para MFA
    mfa_habilitado BOOLEAN DEFAULT FALSE,
    mfa_configurado_em TIMESTAMPTZ,
    mfa_backup_codes TEXT,
    ultimo_acesso TIMESTAMPTZ,
    id_criado_por UUID REFERENCES tb_usuarios(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deletado BOOLEAN NOT NULL DEFAULT FALSE
);

-- Índices para tb_usuarios
CREATE INDEX idx_usuarios_email ON tb_usuarios(email);
CREATE INDEX idx_usuarios_perfil ON tb_usuarios(id_perfil);
CREATE INDEX idx_usuarios_ativo ON tb_usuarios(ativo);
CREATE INDEX idx_usuarios_deletado ON tb_usuarios(deletado);

-- =============================================
-- DOMÍNIO: ESTRUTURA DE OBRA (ENGENHARIA)
-- =============================================

-- Tabela de Clientes
CREATE TABLE IF NOT EXISTS tb_clientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    razao_social VARCHAR(150) NOT NULL,
    cnpj_nif VARCHAR(20) UNIQUE NOT NULL,
    dia_corte INT CHECK (dia_corte BETWEEN 1 AND 31),
    email VARCHAR(100),
    telefone VARCHAR(20),
    endereco TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_clientes
CREATE INDEX idx_clientes_cnpj ON tb_clientes(cnpj_nif);
CREATE INDEX idx_clientes_deleted ON tb_clientes(deleted_at);

-- Tabela de Obras
CREATE TABLE IF NOT EXISTS tb_obras (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(100) NOT NULL,
    endereco_completo TEXT,
    data_inicio DATE,
    data_previsao_fim DATE,
    id_cliente UUID REFERENCES tb_clientes(id) ON DELETE SET NULL,
    id_usuario_criador UUID REFERENCES tb_usuarios(id) ON DELETE SET NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PLANEJAMENTO' CHECK (status IN ('PLANEJAMENTO', 'ATIVA', 'SUSPENSA', 'CONCLUIDA')),
    margem_minima_percentual DECIMAL(5,2) NOT NULL DEFAULT 20.00,
    geo_lat DOUBLE PRECISION,
    geo_long DOUBLE PRECISION,
    observacoes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_obras
CREATE INDEX idx_obras_nome ON tb_obras USING gin(nome gin_trgm_ops);
CREATE INDEX idx_obras_cliente ON tb_obras(id_cliente);
CREATE INDEX idx_obras_criador ON tb_obras(id_usuario_criador);
CREATE INDEX idx_obras_status ON tb_obras(status);
CREATE INDEX idx_obras_deleted ON tb_obras(deleted_at);
CREATE INDEX idx_obras_geolocalizacao ON tb_obras(geo_lat, geo_long) WHERE geo_lat IS NOT NULL AND geo_long IS NOT NULL;

-- Tabela de Pavimentos (Setorização)
CREATE TABLE IF NOT EXISTS tb_pavimentos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_obra UUID NOT NULL REFERENCES tb_obras(id) ON DELETE CASCADE,
    nome VARCHAR(50) NOT NULL,
    ordem INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    UNIQUE(id_obra, nome)
);

-- Índices para tb_pavimentos
CREATE INDEX idx_pavimentos_obra ON tb_pavimentos(id_obra);
CREATE INDEX idx_pavimentos_ordem ON tb_pavimentos(id_obra, ordem);
CREATE INDEX idx_pavimentos_deleted ON tb_pavimentos(deleted_at);

-- Tabela de Ambientes (Unidades de Trabalho)
CREATE TABLE IF NOT EXISTS tb_ambientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_pavimento UUID NOT NULL REFERENCES tb_pavimentos(id) ON DELETE CASCADE,
    nome VARCHAR(50) NOT NULL,
    status_bloqueio BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_ambientes
CREATE INDEX idx_ambientes_pavimento ON tb_ambientes(id_pavimento);
CREATE INDEX idx_ambientes_bloqueio ON tb_ambientes(status_bloqueio);
CREATE INDEX idx_ambientes_deleted ON tb_ambientes(deleted_at);

-- =============================================
-- DOMÍNIO: FINANCEIRO E PRECIFICAÇÃO (CORE)
-- =============================================

-- Catálogo Global de Serviços
CREATE TABLE IF NOT EXISTS tb_servicos_catalogo (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    unidade_medida VARCHAR(5) NOT NULL CHECK (unidade_medida IN ('M2', 'ML', 'UN', 'VB')),
    categoria VARCHAR(50) NOT NULL DEFAULT 'OUTROS',
    permite_decimal BOOLEAN DEFAULT TRUE,
    valor_base DECIMAL(10,2) DEFAULT 0.00,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_servicos_catalogo
CREATE INDEX idx_servicos_catalogo_nome ON tb_servicos_catalogo USING gin(nome gin_trgm_ops);
CREATE INDEX idx_servicos_catalogo_ativo ON tb_servicos_catalogo(ativo);
CREATE INDEX idx_servicos_catalogo_deleted ON tb_servicos_catalogo(deleted_at);

-- Tabela de Preços por Obra
CREATE TABLE IF NOT EXISTS tb_tabela_precos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_obra UUID NOT NULL REFERENCES tb_obras(id) ON DELETE CASCADE,
    id_servico_catalogo INT NOT NULL REFERENCES tb_servicos_catalogo(id),
    preco_custo DECIMAL(10,2) NOT NULL CHECK (preco_custo >= 0),
    preco_venda DECIMAL(10,2) NOT NULL CHECK (preco_venda >= 0),
    status_aprovacao VARCHAR(20) NOT NULL DEFAULT 'RASCUNHO' CHECK (status_aprovacao IN ('RASCUNHO', 'PENDENTE', 'APROVADO', 'REJEITADO')),
    margem_percentual DECIMAL(5,2) GENERATED ALWAYS AS (
        CASE 
            WHEN preco_custo > 0 THEN ((preco_venda - preco_custo) / preco_custo * 100)
            ELSE 0
        END
    ) STORED,
    id_usuario_criador UUID REFERENCES tb_usuarios(id),
    id_usuario_submissor UUID REFERENCES tb_usuarios(id),
    id_usuario_aprovador UUID REFERENCES tb_usuarios(id),
    data_aprovacao TIMESTAMPTZ,
    data_submissao TIMESTAMPTZ,
    data_rejeicao TIMESTAMPTZ,
    id_usuario_rejeitador UUID REFERENCES tb_usuarios(id),
    justificativa_rejeicao TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ,
    UNIQUE(id_obra, id_servico_catalogo, deleted_at)
);

-- Índices para tb_tabela_precos
CREATE INDEX idx_tabela_precos_obra ON tb_tabela_precos(id_obra);
CREATE INDEX idx_tabela_precos_servico ON tb_tabela_precos(id_servico_catalogo);
CREATE INDEX idx_tabela_precos_status ON tb_tabela_precos(status_aprovacao);
CREATE INDEX idx_tabela_precos_deleted ON tb_tabela_precos(deleted_at);

-- Itens de Ambiente (Escopo Planejado)
CREATE TABLE IF NOT EXISTS tb_itens_ambiente (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_ambiente UUID NOT NULL REFERENCES tb_ambientes(id) ON DELETE CASCADE,
    id_tabela_preco UUID REFERENCES tb_tabela_precos(id),
    area_planejada DECIMAL(10,2) NOT NULL CHECK (area_planejada >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_itens_ambiente
CREATE INDEX idx_itens_ambiente ON tb_itens_ambiente(id_ambiente);
CREATE INDEX idx_itens_preco ON tb_itens_ambiente(id_tabela_preco);
CREATE INDEX idx_itens_deleted ON tb_itens_ambiente(deleted_at);

-- =============================================
-- DOMÍNIO: OPERAÇÃO DE CAMPO (OFFLINE SYNC)
-- =============================================

-- Tabela de Colaboradores (Recursos)
CREATE TABLE IF NOT EXISTS tb_colaboradores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) UNIQUE NOT NULL,
    dados_bancarios_enc TEXT, -- Criptografado AES-256 no nível da aplicação
    url_termo_aceite TEXT,
    telefone VARCHAR(20),
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_colaboradores
CREATE INDEX idx_colaboradores_cpf ON tb_colaboradores(cpf);
CREATE INDEX idx_colaboradores_ativo ON tb_colaboradores(ativo);
CREATE INDEX idx_colaboradores_deleted ON tb_colaboradores(deleted_at);

-- Sessões Diárias (RDO)
CREATE TABLE IF NOT EXISTS tb_sessoes_diarias (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_encarregado UUID NOT NULL REFERENCES tb_usuarios(id),
    data_sessao DATE NOT NULL,
    hora_inicio TIMESTAMPTZ NOT NULL,
    hora_fim TIMESTAMPTZ,
    geo_lat FLOAT,
    geo_long FLOAT,
    assinatura_url TEXT,
    observacoes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_sessoes_diarias
CREATE INDEX idx_sessoes_encarregado ON tb_sessoes_diarias(id_encarregado);
CREATE INDEX idx_sessoes_data ON tb_sessoes_diarias(data_sessao);
CREATE INDEX idx_sessoes_deleted ON tb_sessoes_diarias(deleted_at);

-- Alocações de Tarefa (Quem faz o quê agora)
CREATE TABLE IF NOT EXISTS tb_alocacoes_tarefa (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_sessao UUID NOT NULL REFERENCES tb_sessoes_diarias(id) ON DELETE CASCADE,
    id_item_ambiente UUID NOT NULL REFERENCES tb_itens_ambiente(id),
    id_colaborador UUID NOT NULL REFERENCES tb_colaboradores(id),
    status VARCHAR(20) NOT NULL DEFAULT 'EM_ANDAMENTO' CHECK (status IN ('EM_ANDAMENTO', 'CONCLUIDO', 'PAUSADO')),
    hora_inicio TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    hora_fim TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Constraint de Unicidade (Regra 1:1 - Um ambiente = Um colaborador ativo)
CREATE UNIQUE INDEX idx_alocacoes_unicidade_ambiente 
ON tb_alocacoes_tarefa(id_item_ambiente) 
WHERE status = 'EM_ANDAMENTO' AND deleted_at IS NULL;

-- Índices para tb_alocacoes_tarefa
CREATE INDEX idx_alocacoes_sessao ON tb_alocacoes_tarefa(id_sessao);
CREATE INDEX idx_alocacoes_colaborador ON tb_alocacoes_tarefa(id_colaborador);
CREATE INDEX idx_alocacoes_status ON tb_alocacoes_tarefa(status);
CREATE INDEX idx_alocacoes_deleted ON tb_alocacoes_tarefa(deleted_at);

-- Medições (O Resultado)
CREATE TABLE IF NOT EXISTS tb_medicoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_alocacao UUID NOT NULL REFERENCES tb_alocacoes_tarefa(id) ON DELETE CASCADE,
    qtd_executada DECIMAL(10,2) NOT NULL CHECK (qtd_executada >= 0),
    flag_excedente BOOLEAN DEFAULT FALSE,
    justificativa TEXT,
    foto_evidencia_url TEXT,
    status_pagamento VARCHAR(20) NOT NULL DEFAULT 'ABERTO' CHECK (status_pagamento IN ('ABERTO', 'LOTE_CRIADO', 'PAGO')),
    id_lote_pagamento UUID,
    valor_pago DECIMAL(10,2),
    data_pagamento TIMESTAMPTZ,
    data_prevista_faturamento DATE,
    data_faturamento_realizado DATE,
    id_obra UUID REFERENCES tb_obras(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- Índices para tb_medicoes
CREATE INDEX idx_medicoes_alocacao ON tb_medicoes(id_alocacao);
CREATE INDEX idx_medicoes_status_pagamento ON tb_medicoes(status_pagamento);
CREATE INDEX idx_medicoes_lote ON tb_medicoes(id_lote_pagamento);
CREATE INDEX idx_medicoes_deleted ON tb_medicoes(deleted_at);
CREATE INDEX idx_medicoes_data_prevista_faturamento ON tb_medicoes(data_prevista_faturamento) WHERE data_faturamento_realizado IS NULL;

-- =============================================
-- DOMÍNIO: FINANCEIRO
-- =============================================

CREATE TABLE IF NOT EXISTS tb_lotes_pagamento (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    descricao VARCHAR(100) NOT NULL,
    data_competencia DATE NOT NULL,
    data_pagamento DATE,
    valor_total DECIMAL(12,2) NOT NULL,
    qtd_medicoes INT NOT NULL,
    status VARCHAR(30) DEFAULT 'RASCUNHO' CHECK (status IN ('RASCUNHO', 'AGUARDANDO_APROVACAO', 'APROVADO', 'PROCESSANDO', 'PAGO', 'CANCELADO')),
    tipo_pagamento VARCHAR(20) CHECK (tipo_pagamento IN ('PIX', 'TED', 'DINHEIRO', 'CHEQUE')),
    id_criado_por UUID NOT NULL REFERENCES tb_usuarios(id),
    id_aprovado_por UUID REFERENCES tb_usuarios(id),
    observacoes TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_lotes_status ON tb_lotes_pagamento(status);
CREATE INDEX idx_lotes_data_competencia ON tb_lotes_pagamento(data_competencia);

ALTER TABLE tb_medicoes
ADD CONSTRAINT fk_medicoes_lote
FOREIGN KEY (id_lote_pagamento)
REFERENCES tb_lotes_pagamento(id);

-- =============================================
-- DOMÍNIO: AUDITORIA E LOGS
-- =============================================

-- Logs de Auditoria (Imutável)
CREATE TABLE IF NOT EXISTS tb_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    momento TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    id_usuario UUID REFERENCES tb_usuarios(id),
    tabela_afetada VARCHAR(100),
    id_registro UUID,
    acao VARCHAR(20) NOT NULL CHECK (acao IN ('INSERT', 'UPDATE', 'DELETE', 'APPROVE', 'REJECT', 'LOGIN', 'LOGOUT', 'EXPORT')),
    dados_antes JSONB,
    dados_depois JSONB,
    ip_origem INET,
    user_agent VARCHAR(500),
    justificativa TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Índices para tb_audit_logs
CREATE INDEX idx_audit_usuario ON tb_audit_logs(id_usuario);
CREATE INDEX idx_audit_tabela ON tb_audit_logs(tabela_afetada);
CREATE INDEX idx_audit_momento ON tb_audit_logs(momento DESC);
CREATE INDEX idx_audit_acao ON tb_audit_logs(acao);
CREATE INDEX idx_audit_registro ON tb_audit_logs(tabela_afetada, id_registro);

-- =============================================
-- TRIGGERS PARA AUDITORIA AUTOMÁTICA
-- =============================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar trigger em todas as tabelas
DO $$
DECLARE
    t text;
BEGIN
    FOR t IN 
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name LIKE 'tb_%'
        AND table_name != 'tb_audit_logs'
    LOOP
        EXECUTE format('
            CREATE TRIGGER trigger_update_timestamp
            BEFORE UPDATE ON %I
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
        ', t);
    END LOOP;
END;
$$;

-- =============================================
-- VIEWS ÚTEIS
-- =============================================

-- View: Obras com informações completas
CREATE OR REPLACE VIEW vw_obras_completas AS
SELECT 
    o.id,
    o.nome,
    o.endereco_completo,
    o.status,
    o.data_inicio,
    o.data_previsao_fim,
    c.razao_social as cliente_nome,
    c.cnpj_nif as cliente_cnpj,
    u.nome_completo as encarregado_nome,
    COUNT(DISTINCT p.id) as total_pavimentos,
    COUNT(DISTINCT a.id) as total_ambientes
FROM tb_obras o
LEFT JOIN tb_clientes c ON o.id_cliente = c.id
LEFT JOIN tb_usuarios u ON o.id_usuario_criador = u.id
LEFT JOIN tb_pavimentos p ON o.id = p.id_obra AND p.deleted_at IS NULL
LEFT JOIN tb_ambientes a ON p.id = a.id_pavimento AND a.deleted_at IS NULL
WHERE o.deleted_at IS NULL
GROUP BY o.id, c.id, u.id;

-- View: Dashboard Financeiro por Obra
CREATE OR REPLACE VIEW vw_dashboard_financeiro AS
SELECT 
    o.id as obra_id,
    o.nome as obra_nome,
    COUNT(DISTINCT m.id) as total_medicoes,
    SUM(m.qtd_executada * tp.preco_custo) as custo_total,
    SUM(m.qtd_executada * tp.preco_venda) as receita_total,
    SUM(m.qtd_executada * (tp.preco_venda - tp.preco_custo)) as lucro_bruto,
    CASE 
        WHEN SUM(m.qtd_executada * tp.preco_venda) > 0 
        THEN (SUM(m.qtd_executada * (tp.preco_venda - tp.preco_custo)) / SUM(m.qtd_executada * tp.preco_venda) * 100)
        ELSE 0 
    END as margem_percentual
FROM tb_obras o
LEFT JOIN tb_pavimentos pav ON o.id = pav.id_obra
LEFT JOIN tb_ambientes amb ON pav.id = amb.id_pavimento
LEFT JOIN tb_itens_ambiente ia ON amb.id = ia.id_ambiente
LEFT JOIN tb_tabela_precos tp ON ia.id_tabela_preco = tp.id
LEFT JOIN tb_alocacoes_tarefa at ON ia.id = at.id_item_ambiente
LEFT JOIN tb_medicoes m ON at.id = m.id_alocacao
WHERE o.deleted_at IS NULL
AND m.deleted_at IS NULL
GROUP BY o.id;

-- =============================================
-- SEED DATA BÁSICO (Catálogo de Serviços)
-- =============================================

INSERT INTO tb_servicos_catalogo (nome, descricao, unidade_medida, permite_decimal) VALUES
('Pintura Látex 2 Demãos', 'Pintura em látex acrílico com 2 demãos', 'M2', TRUE),
('Pintura Látex 3 Demãos', 'Pintura em látex acrílico com 3 demãos', 'M2', TRUE),
('Textura Projetada', 'Aplicação de textura projetada', 'M2', TRUE),
('Grafiato', 'Aplicação de grafiato', 'M2', TRUE),
('Mass Corrida', 'Aplicação de massa corrida PVA', 'M2', TRUE),
('Rodapé Linear', 'Instalação de rodapé', 'ML', TRUE),
('Porta Completa', 'Pintura de porta com batente', 'UN', FALSE),
('Verba Fechada', 'Serviço com verba fechada', 'VB', FALSE)
ON CONFLICT DO NOTHING;

-- =============================================
-- COMENTÁRIOS NAS TABELAS
-- =============================================

COMMENT ON TABLE tb_perfis IS 'Perfis de usuário (RBAC) - Estática';
COMMENT ON TABLE tb_usuarios IS 'Usuários do sistema com autenticação';
COMMENT ON TABLE tb_clientes IS 'Clientes contratantes das obras';
COMMENT ON TABLE tb_obras IS 'Obras em execução ou planejamento';
COMMENT ON TABLE tb_pavimentos IS 'Setorização das obras em pavimentos';
COMMENT ON TABLE tb_ambientes IS 'Ambientes/Locais específicos de trabalho';
COMMENT ON TABLE tb_servicos_catalogo IS 'Catálogo global de serviços';
COMMENT ON TABLE tb_tabela_precos IS 'Precificação dual (custo/venda) por obra';
COMMENT ON TABLE tb_itens_ambiente IS 'Escopo planejado de serviços por ambiente';
COMMENT ON TABLE tb_colaboradores IS 'Recursos humanos (executores)';
COMMENT ON TABLE tb_sessoes_diarias IS 'Relatórios Diários de Obra (RDO)';
COMMENT ON TABLE tb_alocacoes_tarefa IS 'Alocação de colaboradores em tarefas';
COMMENT ON TABLE tb_medicoes IS 'Medições de produção executada';
COMMENT ON TABLE tb_audit_logs IS 'Logs imutáveis de auditoria';

-- =============================================
-- FIM DO SCRIPT
-- =============================================
