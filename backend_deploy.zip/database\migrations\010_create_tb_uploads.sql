-- ============================================
-- MIGRATION: Criar tabela tb_uploads
-- Versão: 010
-- Data: 2026-03-03
-- Descrição: Tabela para armazenar informações de arquivos enviados (uploads)
-- ============================================

CREATE TABLE IF NOT EXISTS tb_uploads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome_original VARCHAR(255) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    mimetype VARCHAR(100) NOT NULL,
    tamanho BIGINT NOT NULL,
    caminho VARCHAR(500) NOT NULL,
    url VARCHAR(500) NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    id_relacionado UUID,
    descricao TEXT,
    id_usuario_upload UUID NOT NULL REFERENCES tb_usuarios(id),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Índices para otimização de consultas
CREATE INDEX IF NOT EXISTS idx_uploads_tipo ON tb_uploads(tipo) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_uploads_relacionado ON tb_uploads(id_relacionado) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_uploads_usuario ON tb_uploads(id_usuario_upload) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_uploads_created_at ON tb_uploads(created_at);

-- Comentários nas colunas
COMMENT ON TABLE tb_uploads IS 'Tabela de uploads de arquivos do sistema';
COMMENT ON COLUMN tb_uploads.nome_original IS 'Nome original do arquivo enviado';
COMMENT ON COLUMN tb_uploads.nome_arquivo IS 'Nome único do arquivo no sistema de arquivos';
COMMENT ON COLUMN tb_uploads.mimetype IS 'Tipo MIME do arquivo (e.g., image/png)';
COMMENT ON COLUMN tb_uploads.tamanho IS 'Tamanho do arquivo em bytes';
COMMENT ON COLUMN tb_uploads.caminho IS 'Caminho completo do arquivo no sistema de arquivos';
COMMENT ON COLUMN tb_uploads.url IS 'URL para acesso HTTP ao arquivo';
COMMENT ON COLUMN tb_uploads.tipo IS 'Tipo/categoria do upload (e.g., assinatura, documento, foto)';
COMMENT ON COLUMN tb_uploads.id_relacionado IS 'ID da entidade relacionada (e.g., ID da sessão, medição)';
COMMENT ON COLUMN tb_uploads.descricao IS 'Descrição opcional do arquivo';
COMMENT ON COLUMN tb_uploads.id_usuario_upload IS 'ID do usuário que fez o upload';
