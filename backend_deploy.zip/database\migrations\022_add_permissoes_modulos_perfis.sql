-- ERS 4.2: Adiciona coluna permissoes_modulos a tb_perfis
-- Armazena permissões granulares por módulo para cada perfil (JSONB)

ALTER TABLE tb_perfis ADD COLUMN IF NOT EXISTS permissoes_modulos JSONB;

-- ───────────────────────────────────────────────
-- ADMIN (id=1): acesso total a tudo
-- ───────────────────────────────────────────────
UPDATE tb_perfis SET permissoes_modulos = '{
  "dashboard":    { "ativo": true, "acoes": { "visualizar": true } },
  "clientes":     { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
  "colaboradores":{ "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
  "servicos":     { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
  "precos":       { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true, "aprovar": true } },
  "obras": {
    "ativo": true,
    "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true },
    "submodulos": {
      "pavimentos":    { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
      "ambientes":     { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
      "itens_ambiente":{ "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
      "os":            { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } }
    }
  },
  "financeiro":   { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
  "usuarios":     { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": true } },
  "auditoria":    { "ativo": true, "acoes": { "visualizar": true } },
  "permissoes":   { "ativo": true, "acoes": { "visualizar": true, "editar": true } }
}'::jsonb WHERE id = 1;

-- ───────────────────────────────────────────────
-- GESTOR (id=2): aprova preços, não vê usuários nem permissões
-- ───────────────────────────────────────────────
UPDATE tb_perfis SET permissoes_modulos = '{
  "dashboard":    { "ativo": true, "acoes": { "visualizar": true } },
  "clientes":     { "ativo": true, "acoes": { "visualizar": true, "criar": false, "editar": false, "apagar": false } },
  "colaboradores":{ "ativo": true, "acoes": { "visualizar": true, "criar": true,  "editar": true,  "apagar": false } },
  "servicos":     { "ativo": true, "acoes": { "visualizar": true, "criar": false, "editar": false, "apagar": false } },
  "precos":       { "ativo": true, "acoes": { "visualizar": true, "criar": false, "editar": false, "apagar": false, "aprovar": true } },
  "obras": {
    "ativo": true,
    "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false },
    "submodulos": {
      "pavimentos":    { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
      "ambientes":     { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
      "itens_ambiente":{ "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
      "os":            { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } }
    }
  },
  "financeiro":   { "ativo": true,  "acoes": { "visualizar": true,  "criar": false, "editar": false, "apagar": false } },
  "usuarios":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "auditoria":    { "ativo": true,  "acoes": { "visualizar": true } },
  "permissoes":   { "ativo": false, "acoes": { "visualizar": false, "editar": false } }
}'::jsonb WHERE id = 2;

-- ───────────────────────────────────────────────
-- FINANCEIRO (id=3): foco em clientes, preços e financeiro
-- ───────────────────────────────────────────────
UPDATE tb_perfis SET permissoes_modulos = '{
  "dashboard":    { "ativo": true,  "acoes": { "visualizar": true } },
  "clientes":     { "ativo": true,  "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
  "colaboradores":{ "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "servicos":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "precos":       { "ativo": true,  "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false, "aprovar": false } },
  "obras": {
    "ativo": true,
    "acoes": { "visualizar": true, "criar": false, "editar": false, "apagar": false },
    "submodulos": {
      "pavimentos":    { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
      "ambientes":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
      "itens_ambiente":{ "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
      "os":            { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } }
    }
  },
  "financeiro":   { "ativo": true,  "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
  "usuarios":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "auditoria":    { "ativo": false, "acoes": { "visualizar": false } },
  "permissoes":   { "ativo": false, "acoes": { "visualizar": false, "editar": false } }
}'::jsonb WHERE id = 3;

-- ───────────────────────────────────────────────
-- ENCARREGADO (id=4): operação de campo
-- ───────────────────────────────────────────────
UPDATE tb_perfis SET permissoes_modulos = '{
  "dashboard":    { "ativo": true,  "acoes": { "visualizar": true } },
  "clientes":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "colaboradores":{ "ativo": true,  "acoes": { "visualizar": true,  "criar": false, "editar": false, "apagar": false } },
  "servicos":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "precos":       { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false, "aprovar": false } },
  "obras": {
    "ativo": true,
    "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false },
    "submodulos": {
      "pavimentos":    { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
      "ambientes":     { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
      "itens_ambiente":{ "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } },
      "os":            { "ativo": true, "acoes": { "visualizar": true, "criar": true, "editar": true, "apagar": false } }
    }
  },
  "financeiro":   { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "usuarios":     { "ativo": false, "acoes": { "visualizar": false, "criar": false, "editar": false, "apagar": false } },
  "auditoria":    { "ativo": false, "acoes": { "visualizar": false } },
  "permissoes":   { "ativo": false, "acoes": { "visualizar": false, "editar": false } }
}'::jsonb WHERE id = 4;
