-- =============================================
-- Migration: Add deletado boolean columns to all tables
-- Purpose: Support entity-level soft delete flags
-- Version: 007
-- =============================================

-- Add deletado column to tb_clientes
ALTER TABLE tb_clientes ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_clientes_deletado ON tb_clientes(deletado);

-- Add deletado column to tb_colaboradores
ALTER TABLE tb_colaboradores ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_colaboradores_deletado ON tb_colaboradores(deletado);

-- Add deletado column to tb_servicos_catalogo
ALTER TABLE tb_servicos_catalogo ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_servicos_catalogo_deletado ON tb_servicos_catalogo(deletado);

-- Add deletado column to tb_itens_ambiente
ALTER TABLE tb_itens_ambiente ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_itens_ambiente_deletado ON tb_itens_ambiente(deletado);

-- Add deletado column to tb_pavimentos
ALTER TABLE tb_pavimentos ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_pavimentos_deletado ON tb_pavimentos(deletado);

-- Add deletado column to tb_ambientes
ALTER TABLE tb_ambientes ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_ambientes_deletado ON tb_ambientes(deletado);

-- Add deletado column to tb_tabela_precos
ALTER TABLE tb_tabela_precos ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_tabela_precos_deletado ON tb_tabela_precos(deletado);

-- Add deletado column to tb_medicoes
ALTER TABLE tb_medicoes ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_medicoes_deletado ON tb_medicoes(deletado);

-- Add deletado column to tb_alocacoes_tarefa
ALTER TABLE tb_alocacoes_tarefa ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_alocacoes_deletado ON tb_alocacoes_tarefa(deletado);

-- Add deletado column to tb_sessoes_diarias
ALTER TABLE tb_sessoes_diarias ADD COLUMN IF NOT EXISTS deletado BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS idx_sessoes_deletado ON tb_sessoes_diarias(deletado);

-- Fix tb_colaboradores: Add missing columns if they don't exist
-- Add email column if missing
ALTER TABLE tb_colaboradores ADD COLUMN IF NOT EXISTS email VARCHAR(200);

-- Add data_nascimento if missing  
ALTER TABLE tb_colaboradores ADD COLUMN IF NOT EXISTS data_nascimento DATE;

-- Add endereco if missing
ALTER TABLE tb_colaboradores ADD COLUMN IF NOT EXISTS endereco TEXT;

-- Add cpf_nif column if it doesn't exist (entity expects cpf_nif, not cpf)
ALTER TABLE tb_colaboradores ADD COLUMN IF NOT EXISTS cpf_nif VARCHAR(20) UNIQUE;

-- Rename cpf to cpf_old for tracking, then populate cpf_nif
-- Only if cpf_nif is empty
UPDATE tb_colaboradores SET cpf_nif = cpf WHERE cpf_nif IS NULL AND cpf IS NOT NULL;

-- Add nome_completo column if it doesn't exist
ALTER TABLE tb_colaboradores ADD COLUMN IF NOT EXISTS nome_completo VARCHAR(200);

-- Populate nome_completo from nome column if needed
UPDATE tb_colaboradores SET nome_completo = nome WHERE nome_completo IS NULL AND nome IS NOT NULL;

-- Make nome_completo NOT NULL after data migration
ALTER TABLE tb_colaboradores ALTER COLUMN nome_completo SET NOT NULL;

-- =============================================
-- Migration complete
-- =============================================
