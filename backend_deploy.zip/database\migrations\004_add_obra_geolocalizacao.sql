-- Migration 004: Add campos de geolocalização to tb_obras
-- RF06: RDO Digital com Geolocalização
-- Data: 2026-02-10

-- Adiciona campos de geolocalização em tb_obras
ALTER TABLE tb_obras 
ADD COLUMN IF NOT EXISTS geo_lat DOUBLE PRECISION,
ADD COLUMN IF NOT EXISTS geo_long DOUBLE PRECISION;

-- Índice para consultas de localização
CREATE INDEX IF NOT EXISTS idx_obras_geolocalizacao 
ON tb_obras(geo_lat, geo_long) 
WHERE geo_lat IS NOT NULL AND geo_long IS NOT NULL;

-- Comentários
COMMENT ON COLUMN tb_obras.geo_lat IS 'Latitude da obra para validação de proximidade';
COMMENT ON COLUMN tb_obras.geo_long IS 'Longitude da obra para validação de proximidade';
