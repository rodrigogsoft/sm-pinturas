-- =====================================================================
-- Migration: 012_add_nome_assinante_sessao.sql
-- Objetivo: Adicionar nome de quem assinou na sessao diaria
-- Data: 2026-03-10
-- =====================================================================

ALTER TABLE tb_sessoes_diarias
ADD COLUMN IF NOT EXISTS nome_assinante VARCHAR(200);

CREATE INDEX IF NOT EXISTS idx_sessoes_nome_assinante ON tb_sessoes_diarias(nome_assinante);
