-- =====================================================================
-- Migration: 008_fix_utf8_encoding.sql
-- Objetivo: Corrigir caracteres acentuados que foram inseridos incorretamente
-- Data: 2026-02-25
-- =====================================================================

-- Fix Catálogo de Serviços - Serviços com acentos
UPDATE tb_servicos_catalogo SET nome = 'Pintura Látex 2 Demãos (Parede)' 
WHERE nome LIKE '%L__tex%' AND nome LIKE '%2%';

UPDATE tb_servicos_catalogo SET nome = 'Pintura Látex 3 Demãos (Parede)' 
WHERE nome LIKE '%L__tex%' AND nome LIKE '%3%';

UPDATE tb_servicos_catalogo SET descricao = 'Aplicação de tinta látex econômica ou standard em paredes internas'
WHERE nome = 'Pintura Látex 2 Demãos (Parede)';

UPDATE tb_servicos_catalogo SET descricao = 'Aplicação de tinta látex premium com 3 demãos em paredes'
WHERE nome = 'Pintura Látex 3 Demãos (Parede)';

-- Fix Teto Látex
UPDATE tb_servicos_catalogo SET nome = 'Pintura Teto (Látex)', 
                                descricao = 'Pintura de forro/laje com tinta látex branca'
WHERE nome LIKE 'Pintura Teto%' AND descricao LIKE '%teto%';

-- Fix Acrílica
UPDATE tb_servicos_catalogo SET nome = 'Pintura Acrílica Externa',
                                descricao = 'Aplicação de tinta acrílica para fachadas e áreas externas'
WHERE nome LIKE '%Acr__lica%';

-- Fix Esmalte
UPDATE tb_servicos_catalogo SET nome = 'Pintura Esmalte (Ferro/Madeira)',
                                descricao = 'Pintura de superfícies metálicas ou madeira com esmalte sintético'
WHERE nome LIKE '%Esmalte%';

-- Fix Massa
UPDATE tb_servicos_catalogo SET nome = 'Massa Corrida + Selador',
                                descricao = 'Aplicação de massa corrida PVA e selador acrílico'
WHERE nome LIKE '%Massa%';

-- Fix Grafiato
UPDATE tb_servicos_catalogo SET nome = 'Textura Grafiato',
                                descricao = 'Aplicação de textura grafiato em paredes internas'
WHERE nome LIKE '%Textura%';

-- Fix Impermeabilização
UPDATE tb_servicos_catalogo SET nome = 'Impermeabilização',
                                descricao = 'Aplicação de manta asfáltica ou impermeabilizante'
WHERE nome LIKE '%Imperme%';

-- Fix Rodapé
UPDATE tb_servicos_catalogo SET nome = 'Rodapé/Barra (Pintura)',
                                descricao = 'Pintura linear de rodapé ou barra decorativa'
WHERE nome LIKE '%Rodap%' OR descricao LIKE '%rodap%';

-- Fix Porta/Janela
UPDATE tb_servicos_catalogo SET nome = 'Porta/Janela (Pintura)',
                                descricao = 'Pintura completa de porta ou janela (esquadria)'
WHERE nome LIKE '%Porta%' OR nome LIKE '%Janela%';

-- Fix Grade/Portão
UPDATE tb_servicos_catalogo SET nome = 'Grade/Portão (Pintura)',
                                descricao = 'Pintura de grade ou portão metálico'
WHERE nome LIKE '%Grade%' OR nome LIKE '%Port%o%';

-- =====================================================================
-- Verificação de dados corrigidos
-- =====================================================================

-- Para verificar, execute:
-- SELECT nome FROM tb_catalogo_servicos ORDER BY id;
