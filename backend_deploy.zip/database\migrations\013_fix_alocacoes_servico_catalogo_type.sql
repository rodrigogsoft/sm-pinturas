-- Alinhar tipo da coluna id_servico_catalogo com o catalogo de servicos (INT)
-- Historico: a coluna foi criada como UUID em alguns ambientes, mas tb_servicos_catalogo.id e INT.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'tb_alocacoes_tarefa'
      AND column_name = 'id_servico_catalogo'
      AND udt_name = 'uuid'
  ) THEN
    ALTER TABLE tb_alocacoes_tarefa
      ADD COLUMN id_servico_catalogo_tmp INTEGER;

    -- UUIDs antigos nao sao mapeaveis para catalogo numerico; mantemos apenas valores numericos validos.
    UPDATE tb_alocacoes_tarefa
    SET id_servico_catalogo_tmp = CASE
      WHEN id_servico_catalogo::text ~ '^[0-9]+$' THEN (id_servico_catalogo::text)::INTEGER
      ELSE NULL
    END;

    ALTER TABLE tb_alocacoes_tarefa DROP COLUMN id_servico_catalogo;
    ALTER TABLE tb_alocacoes_tarefa RENAME COLUMN id_servico_catalogo_tmp TO id_servico_catalogo;
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'tb_alocacoes_tarefa'
      AND column_name = 'id_servico_catalogo'
      AND data_type = 'integer'
  ) THEN
    ALTER TABLE tb_alocacoes_tarefa
      ADD CONSTRAINT fk_alocacao_servico_catalogo
      FOREIGN KEY (id_servico_catalogo)
      REFERENCES tb_servicos_catalogo(id)
      ON DELETE SET NULL;
  END IF;
EXCEPTION
  WHEN duplicate_object THEN
    NULL;
END $$;

CREATE INDEX IF NOT EXISTS idx_alocacoes_servico_catalogo
  ON tb_alocacoes_tarefa(id_servico_catalogo);
