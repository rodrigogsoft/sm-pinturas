-- Alinha tb_perfis com a entidade Perfil usada no login/auth
ALTER TABLE tb_perfis
ADD COLUMN IF NOT EXISTS descricao TEXT;
