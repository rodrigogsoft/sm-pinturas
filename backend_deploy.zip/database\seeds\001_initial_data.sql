-- ============================================
-- SEEDS: Dados Iniciais - JB Pinturas ERP
-- Versão: 1.0.0
-- ============================================

-- ============================================
-- 1. CATÁLOGO DE SERVIÇOS (Padrão da ERS)
-- ============================================

INSERT INTO tb_catalogo_servicos (nome, unidade_medida, permite_decimal, descricao) VALUES
('Pintura Látex 2 Demãos (Parede)', 'M2', TRUE, 'Aplicação de tinta látex econômica ou standard em paredes internas'),
('Pintura Látex 3 Demãos (Parede)', 'M2', TRUE, 'Aplicação de tinta látex premium com 3 demãos em paredes'),
('Pintura Acrílica Externa', 'M2', TRUE, 'Aplicação de tinta acrílica para fachadas e áreas externas'),
('Pintura Esmalte (Ferro/Madeira)', 'M2', TRUE, 'Pintura de superfícies metálicas ou madeira com esmalte sintético'),
('Massa Corrida + Selador', 'M2', TRUE, 'Aplicação de massa corrida PVA e selador acrílico'),
('Textura Grafiato', 'M2', TRUE, 'Aplicação de textura grafiato em paredes internas'),
('Pintura Teto (Látex)', 'M2', TRUE, 'Pintura de forro/laje com tinta látex branca'),
('Impermeabilização', 'M2', TRUE, 'Aplicação de manta asfáltica ou impermeabilizante'),
('Rodapé/Barra (Pintura)', 'ML', TRUE, 'Pintura linear de rodapé ou barra decorativa'),
('Porta/Janela (Pintura)', 'UN', FALSE, 'Pintura completa de porta ou janela (esquadria)'),
('Grade/Portão (Pintura)', 'UN', FALSE, 'Pintura de grade ou portão metálico'),
('Serviço Avulso', 'VB', FALSE, 'Serviço não catalogado - valor fixo negociado')
ON CONFLICT DO NOTHING;

-- ============================================
-- 2. USUÁRIO ADMINISTRADOR INICIAL
-- ============================================

-- Senha: Admin@2026 (hash bcrypt com salt 10)
-- Na prática, gerar com: bcrypt.hash('Admin@2026', 10)
INSERT INTO tb_usuarios (
    id,
    nome_completo,
    email,
    senha_hash,
    id_perfil,
    ativo,
    mfa_habilitado
) VALUES (
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'Administrador do Sistema',
    'admin@jbpinturas.com.br',
    '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', -- Admin@2026
    1, -- ADMIN
    TRUE,
    FALSE
) ON CONFLICT (email) DO NOTHING;

-- ============================================
-- 3. CLIENTE DE TESTE
-- ============================================

INSERT INTO tb_clientes (
    id,
    razao_social,
    cnpj_nif,
    email,
    telefone,
    dia_corte,
    ativo
) VALUES (
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb',
    'Construtora Exemplo LTDA',
    '12.345.678/0001-99',
    'contato@construtorexemplo.com.br',
    '(11) 98765-4321',
    15, -- Dia 15 de cada mês
    TRUE
) ON CONFLICT (cnpj_nif) DO NOTHING;

-- ============================================
-- 4. COLABORADORES DE TESTE
-- ============================================

INSERT INTO tb_colaboradores (nome_completo, cpf_nif, telefone, ativo) VALUES
('João Silva Pintor', '111.111.111-11', '(11) 91111-1111', TRUE),
('Maria Santos Pintora', '222.222.222-22', '(11) 92222-2222', TRUE),
('Pedro Alves Pintor', '333.333.333-33', '(11) 93333-3333', TRUE),
('Ana Costa Pintora', '444.444.444-44', '(11) 94444-4444', TRUE)
ON CONFLICT (cpf_nif) DO NOTHING;

-- ============================================
-- 5. OBRA DE DEMONSTRAÇÃO
-- ============================================

INSERT INTO tb_obras (
    id,
    nome,
    endereco_completo,
    status,
    data_inicio,
    data_previsao_fim,
    id_cliente
) VALUES (
    'cccccccc-cccc-cccc-cccc-cccccccccccc',
    'Edifício Residencial Primavera - Torre 1',
    'Av. Paulista, 1000 - Bela Vista, São Paulo - SP, 01310-100',
    'ATIVA',
    '2026-01-15',
    '2026-06-30',
    'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb'
) ON CONFLICT DO NOTHING;

-- Pavimentos da obra de demonstração
INSERT INTO tb_pavimentos (id_obra, nome, ordem) VALUES
((SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera - Torre 1'), 'Térreo', 0),
((SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera - Torre 1'), '1º Pavimento', 1),
((SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera - Torre 1'), '2º Pavimento', 2),
((SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera - Torre 1'), '3º Pavimento', 3);

-- Ambientes do 1º Pavimento (exemplo)
DO $$
DECLARE
    id_pav UUID;
BEGIN
    SELECT id INTO id_pav 
    FROM tb_pavimentos 
    WHERE nome = '1º Pavimento' 
    AND id_obra = 'cccccccc-cccc-cccc-cccc-cccccccccccc';

    INSERT INTO tb_ambientes (id_pavimento, nome, area_m2) VALUES
    (id_pav, 'Apto 101 - Sala', 25.50),
    (id_pav, 'Apto 101 - Quarto 1', 12.00),
    (id_pav, 'Apto 101 - Quarto 2', 10.50),
    (id_pav, 'Apto 101 - Cozinha', 8.00),
    (id_pav, 'Apto 102 - Sala', 25.50),
    (id_pav, 'Apto 102 - Quarto 1', 12.00),
    (id_pav, 'Corredor Central', 15.00);
END $$;

-- ============================================
-- 6. TABELA DE PREÇOS (Obra Demonstração)
-- ============================================

-- Preços de custo (visíveis ao encarregado) e venda (ocultos)
DO $$
DECLARE
    id_obra_demo UUID := 'cccccccc-cccc-cccc-cccc-cccccccccccc';
    id_admin UUID := 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa';
BEGIN
    INSERT INTO tb_tabela_precos (
        id_obra, 
        id_servico_catalogo, 
        preco_custo, 
        preco_venda, 
        status_aprovacao,
        id_aprovado_por,
        data_aprovacao,
        margem_percentual
    ) VALUES
    -- Pinturas básicas
    (id_obra_demo, 1, 18.00, 25.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 38.89), -- Látex 2 demãos
    (id_obra_demo, 2, 25.00, 35.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 40.00), -- Látex 3 demãos
    (id_obra_demo, 3, 30.00, 42.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 40.00), -- Acrílica externa
    (id_obra_demo, 5, 15.00, 22.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 46.67), -- Massa corrida
    (id_obra_demo, 7, 20.00, 28.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 40.00), -- Teto
    
    -- Serviços lineares e unitários
    (id_obra_demo, 9, 5.00, 8.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 60.00),   -- Rodapé
    (id_obra_demo, 10, 80.00, 120.00, 'APROVADO', id_admin, CURRENT_TIMESTAMP, 50.00); -- Porta/Janela
END $$;

-- ============================================
-- 7. NOTIFICAÇÕES DE BOAS-VINDAS
-- ============================================

INSERT INTO tb_notificacoes (
    id_usuario_destinatario,
    tipo,
    titulo,
    mensagem,
    prioridade
) VALUES (
    'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
    'SISTEMA',
    'Bem-vindo ao JB Pinturas ERP',
    'Sistema inicializado com sucesso! Você pode começar cadastrando usuários, obras e colaboradores.',
    'MEDIA'
);

-- ============================================
-- FIM DOS SEEDS
-- ============================================

SELECT 'Seeds aplicados com sucesso!' AS status;
