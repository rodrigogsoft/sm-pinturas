import {
  Injectable,
  BadRequestException,
  NotFoundException,
  Logger,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Upload } from './entities/upload.entity';
import { UploadFileDto } from './dto/upload-file.dto';
import * as path from 'path';
import * as fs from 'fs';

@Injectable()
export class UploadsService {
  private readonly uploadPath = path.join(process.cwd(), 'uploads');
  private readonly logger = new Logger(UploadsService.name);
  private readonly maxUploadSizeInBytes = 5 * 1024 * 1024; // 5MB

  private readonly allowedImageMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
  ];

  constructor(
    @InjectRepository(Upload)
    private uploadRepository: Repository<Upload>,
  ) {
    // Criar diretório de uploads se não existir
    if (!fs.existsSync(this.uploadPath)) {
      fs.mkdirSync(this.uploadPath, { recursive: true });
    }
  }

  /**
   * Salvar informações do arquivo no banco de dados
   */
  async saveFileInfo(
    file: Express.Multer.File,
    uploadDto: UploadFileDto,
    userId: string,
  ): Promise<Upload> {
    if (!file?.buffer || file.buffer.length === 0) {
      throw new BadRequestException('Arquivo inválido ou vazio');
    }

    const detectedMimeType = this.detectMimeTypeFromBuffer(file.buffer);
    const mimeTypeNormalizado = this.normalizeMimeType(file.mimetype);

    if (!detectedMimeType || !this.allowedImageMimeTypes.includes(detectedMimeType)) {
      throw new BadRequestException({
        message: 'Tipo de arquivo não permitido. Apenas imagens válidas são aceitas',
        tipos_aceitos: this.allowedImageMimeTypes,
      });
    }

    if (mimeTypeNormalizado && mimeTypeNormalizado !== detectedMimeType) {
      this.logger.warn(
        `Upload rejeitado por divergência de tipo. Informado=${mimeTypeNormalizado}, detectado=${detectedMimeType}, arquivo=${file.originalname}`,
      );
      throw new BadRequestException({
        message: 'Tipo do arquivo informado não corresponde ao conteúdo real',
      });
    }

    if (file.buffer.length > this.maxUploadSizeInBytes) {
      throw new BadRequestException({
        message: 'Arquivo muito grande. Tamanho máximo: 5MB',
        tamanho_enviado: `${(file.buffer.length / 1024 / 1024).toFixed(2)}MB`,
        tamanho_maximo: '5MB',
      });
    }

    // Gerar nome único para o arquivo
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const ext = this.getExtensionByMimeType(detectedMimeType);
    const nomeArquivo = `${uploadDto.tipo}_${timestamp}_${randomString}${ext}`;

    // Caminho completo do arquivo
    const caminhoCompleto = path.join(this.uploadPath, nomeArquivo);

    // Salvar arquivo no disco
    fs.writeFileSync(caminhoCompleto, file.buffer);

    // URL pública do arquivo (relativa)
    const url = `/uploads/${nomeArquivo}`;

    // Criar registro no banco
    const upload = this.uploadRepository.create({
      nome_original: file.originalname,
      nome_arquivo: nomeArquivo,
      mimetype: detectedMimeType,
      tamanho: file.buffer.length,
      caminho: caminhoCompleto,
      url: url,
      tipo: uploadDto.tipo,
      id_relacionado: uploadDto.id_relacionado || null,
      descricao: uploadDto.descricao || null,
      id_usuario_upload: userId,
    });

    return await this.uploadRepository.save(upload);
  }

  /**
   * Listar uploads por tipo
   */
  async findByTipo(tipo: string): Promise<Upload[]> {
    return await this.uploadRepository.find({
      where: { tipo, deletado: false },
      order: { created_at: 'DESC' },
    });
  }

  /**
   * Listar uploads por ID relacionado
   */
  async findByRelacionado(idRelacionado: string): Promise<Upload[]> {
    return await this.uploadRepository.find({
      where: { id_relacionado: idRelacionado, deletado: false },
      order: { created_at: 'DESC' },
    });
  }

  /**
   * Buscar upload por ID
   */
  async findOne(id: string): Promise<Upload> {
    const upload = await this.uploadRepository.findOne({
      where: { id, deletado: false },
    });

    if (!upload) {
      throw new NotFoundException(`Upload com ID ${id} não encontrado`);
    }

    return upload;
  }

  /**
   * Deletar upload (soft delete)
   */
  async remove(id: string): Promise<{ message: string }> {
    const upload = await this.findOne(id);

    // Deletar arquivo físico
    if (fs.existsSync(upload.caminho)) {
      fs.unlinkSync(upload.caminho);
    }

    // Soft delete no banco
    upload.deletado = true;
    await this.uploadRepository.save(upload);

    return { message: `Upload ${id} deletado com sucesso` };
  }

  /**
   * Salvar arquivo a partir de base64
   */
  async saveBase64(
    fileBase64: string,
    nomeArquivo: string,
    tipo: string,
    idRelacionado?: string,
    descricao?: string,
    userId?: string,
  ): Promise<Upload> {
    try {
      // Remove o prefixo de data URL se existir (data:image/png;base64,...)
      const base64Data = fileBase64.replace(/^data:[^;]+;base64,/, '').trim();

      // Converter base64 para buffer
      const buffer = Buffer.from(base64Data, 'base64');
      if (!buffer.length) {
        throw new BadRequestException('Arquivo base64 inválido ou vazio');
      }

      if (buffer.length > this.maxUploadSizeInBytes) {
        throw new BadRequestException({
          message: 'Arquivo muito grande. Tamanho máximo: 5MB',
          tamanho_enviado: `${(buffer.length / 1024 / 1024).toFixed(2)}MB`,
          tamanho_maximo: '5MB',
        });
      }

      const mimetypeDetectado = this.detectMimeTypeFromBuffer(buffer);
      if (!mimetypeDetectado || !this.allowedImageMimeTypes.includes(mimetypeDetectado)) {
        throw new BadRequestException({
          message: 'Tipo de arquivo não permitido. Apenas imagens válidas são aceitas',
          tipos_aceitos: this.allowedImageMimeTypes,
        });
      }

      // Gerar nome único
      const timestamp = Date.now();
      const randomString = Math.random().toString(36).substring(2, 15);
      const ext = this.getExtensionByMimeType(mimetypeDetectado);
      const nomeArquivoSalvo = `${tipo}_${timestamp}_${randomString}${ext}`;
      
      const caminhoCompleto = path.join(this.uploadPath, nomeArquivoSalvo);

      // Salvar arquivo no disco
      fs.writeFileSync(caminhoCompleto, buffer);

      // Salvar no banco de dados
      const upload = this.uploadRepository.create({
        nome_original: nomeArquivo,
        nome_arquivo: nomeArquivoSalvo,
        mimetype: mimetypeDetectado,
        tamanho: buffer.length,
        caminho: caminhoCompleto,
        url: `/uploads/${nomeArquivoSalvo}`,
        tipo,
        id_relacionado: idRelacionado,
        descricao,
        id_usuario_upload: userId,
        deletado: false,
      });

      return await this.uploadRepository.save(upload);
    } catch (error) {
      if (error instanceof BadRequestException) {
        throw error;
      }

      throw new BadRequestException({
        message: 'Erro ao processar arquivo base64',
      });
    }
  }

  /**
   * Obter caminho do arquivo
   */
  getFilePath(filename: string): string {
    const fileNameSeguro = path.basename(filename);
    if (fileNameSeguro !== filename) {
      throw new BadRequestException('Nome de arquivo inválido');
    }

    return path.join(this.uploadPath, fileNameSeguro);
  }

  private normalizeMimeType(mimeType?: string): string {
    if (!mimeType) {
      return '';
    }

    return mimeType === 'image/jpg' ? 'image/jpeg' : mimeType;
  }

  private detectMimeTypeFromBuffer(buffer: Buffer): string | null {
    if (buffer.length < 12) {
      return null;
    }

    // JPEG: FF D8 FF
    if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
      return 'image/jpeg';
    }

    // PNG: 89 50 4E 47 0D 0A 1A 0A
    if (
      buffer[0] === 0x89 &&
      buffer[1] === 0x50 &&
      buffer[2] === 0x4e &&
      buffer[3] === 0x47 &&
      buffer[4] === 0x0d &&
      buffer[5] === 0x0a &&
      buffer[6] === 0x1a &&
      buffer[7] === 0x0a
    ) {
      return 'image/png';
    }

    // GIF87a / GIF89a
    if (
      buffer[0] === 0x47 &&
      buffer[1] === 0x49 &&
      buffer[2] === 0x46 &&
      buffer[3] === 0x38 &&
      (buffer[4] === 0x37 || buffer[4] === 0x39) &&
      buffer[5] === 0x61
    ) {
      return 'image/gif';
    }

    // WEBP: RIFF....WEBP
    if (
      buffer[0] === 0x52 &&
      buffer[1] === 0x49 &&
      buffer[2] === 0x46 &&
      buffer[3] === 0x46 &&
      buffer[8] === 0x57 &&
      buffer[9] === 0x45 &&
      buffer[10] === 0x42 &&
      buffer[11] === 0x50
    ) {
      return 'image/webp';
    }

    return null;
  }

  private getExtensionByMimeType(mimeType: string): string {
    switch (mimeType) {
      case 'image/jpeg':
        return '.jpg';
      case 'image/png':
        return '.png';
      case 'image/gif':
        return '.gif';
      case 'image/webp':
        return '.webp';
      default:
        return '.bin';
    }
  }
}
