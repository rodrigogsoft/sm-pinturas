-- Migration 018: ERS 4.1 – nome_elemento em tb_itens_ambiente,
-- id_tabela_preco torna-se nullable (tipo de serviço definido na alocação)
-- e id_tabela_preco adicionado em tb_alocacoes_itens (RF11)

-- 1. Adiciona nome_elemento ao elemento de serviço (cadastro sem tipo de serviço)
ALTER TABLE tb_itens_ambiente
  ADD COLUMN IF NOT EXISTS nome_elemento VARCHAR(200);

-- 2. Torna id_tabela_preco opcional no cadastro do elemento
--    (o tipo de serviço agora é vinculado apenas na alocação)
ALTER TABLE tb_itens_ambiente
  ALTER COLUMN id_tabela_preco DROP NOT NULL;

-- 3. Popula nome_elemento para registros existentes usando o nome do serviço da tabela de preço
UPDATE tb_itens_ambiente ia
SET nome_elemento = COALESCE(
  (
    SELECT s.nome
    FROM tb_tabela_precos tp
    JOIN tb_servicos s ON s.id = tp.id_servico
    WHERE tp.id = ia.id_tabela_preco
    LIMIT 1
  ),
  'Elemento sem nome'
)
WHERE nome_elemento IS NULL;

-- 4. Adiciona id_tabela_preco em tb_alocacoes_itens
--    (define qual serviço/preço o colaborador executará neste elemento)
ALTER TABLE tb_alocacoes_itens
  ADD COLUMN IF NOT EXISTS id_tabela_preco UUID REFERENCES tb_tabela_precos(id);

-- 5. Popula id_tabela_preco nas alocações existentes a partir do item de ambiente
UPDATE tb_alocacoes_itens ai
SET id_tabela_preco = (
  SELECT id_tabela_preco
  FROM tb_itens_ambiente ia
  WHERE ia.id = ai.id_item_ambiente
  LIMIT 1
)
WHERE id_tabela_preco IS NULL;

-- Índice para busca por tabela de preço nas alocações
CREATE INDEX IF NOT EXISTS idx_alocacoes_itens_tabela_preco
  ON tb_alocacoes_itens(id_tabela_preco);
