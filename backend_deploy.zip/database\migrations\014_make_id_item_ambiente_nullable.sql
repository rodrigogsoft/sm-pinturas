-- Permitir alocacao sem item de ambiente (item opcional no fluxo RF07)
ALTER TABLE tb_alocacoes_tarefa
  ALTER COLUMN id_item_ambiente DROP NOT NULL;
