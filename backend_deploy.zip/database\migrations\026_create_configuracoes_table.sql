-- Criação da tabela tb_configuracoes
CREATE TABLE IF NOT EXISTS tb_configuracoes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  chave VARCHAR(100) NOT NULL UNIQUE,
  valor TEXT NOT NULL,
  tipo VARCHAR(20) NOT NULL DEFAULT 'string',
  descricao VARCHAR(255) NOT NULL,
  ativo BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Índice para busca por chave
CREATE INDEX IF NOT EXISTS idx_configuracoes_chave ON tb_configuracoes(chave);

-- Inserir configurações padrão
INSERT INTO tb_configuracoes (chave, valor, tipo, descricao, ativo)
VALUES (
  'max_alocacoes_simultaneas_colaborador',
  '2',
  'integer',
  'Número máximo de alocações simultâneas permitidas por colaborador. Use 0 para ilimitado.',
  TRUE
)
ON CONFLICT (chave) DO NOTHING;
