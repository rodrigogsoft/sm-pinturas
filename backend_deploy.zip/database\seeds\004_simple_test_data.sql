-- =============================================
-- SEEDS SIMPLES: Dados de Teste - JB Pinturas ERP v4.0
-- =============================================

-- 1. USUÁRIOS
INSERT INTO tb_usuarios (nome_completo, email, senha_hash, id_perfil, status)
VALUES 
  ('Admin Sistema', 'admin@jbpinturas.com', '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 1, 'ATIVO'),
  ('Gestor', 'gestor@jbpinturas.com', '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 2, 'ATIVO'),
  ('Financeiro', 'financeiro@jbpinturas.com', '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 3, 'ATIVO'),
  ('Encarregado', 'encarregado@jbpinturas.com', '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', 4, 'ATIVO')
ON CONFLICT (email) DO NOTHING;

-- 2. CLIENTES
INSERT INTO tb_clientes (razao_social, cnpj_nif, email, telefone, dia_corte)
VALUES 
  ('Construtora Exemplo', '12.345.678/0001-99', 'contato@construtora.com.br', '(11) 98765-4321', 15),
  ('Incorporadora ABC', '98.765.432/0001-11', 'vendas@incorporadora.com.br', '(21) 99876-5432', 25),
  ('Engenharia XYZ', '11.111.111/0001-22', 'vendas@engenharia.com.br', '(31) 97777-8888', 10)
ON CONFLICT (cnpj_nif) DO NOTHING;

-- 3. COLABORADORES
INSERT INTO tb_colaboradores (nome, cpf, telefone, ativo)
VALUES 
  ('Carlos Pintor', '11111111111', '(11) 99111-1111', TRUE),
  ('Ana Pintora', '22222222222', '(11) 99222-2222', TRUE),
  ('Pedro Pintor', '33333333333', '(11) 99333-3333', TRUE),
  ('Marcos Pintor', '44444444444', '(11) 99444-4444', TRUE),
  ('Lucia Pintora', '55555555555', '(11) 99555-5555', TRUE),
  ('Roberto Pintor', '66666666666', '(11) 99666-6666', TRUE)
ON CONFLICT (cpf) DO NOTHING;

-- 4. OBRAS
INSERT INTO tb_obras (nome, endereco_completo, data_inicio, data_previsao_fim, status, id_cliente, id_usuario_criador, margem_minima_percentual)
SELECT 
  'Edifício Resid Primavera',
  'Av. Paulista, 1000',
  '2026-01-15'::DATE,
  '2026-06-30'::DATE,
  'ATIVA',
  (SELECT id FROM tb_clientes WHERE razao_social = 'Construtora Exemplo' LIMIT 1),
  (SELECT id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com' LIMIT 1),
  20.00
WHERE NOT EXISTS (SELECT 1 FROM tb_obras WHERE nome = 'Edifício Resid Primavera');

-- 5. PAVIMENTOS
DO $$
DECLARE
  v_obra_id UUID;
BEGIN
  SELECT id INTO v_obra_id FROM tb_obras WHERE nome = 'Edifício Resid Primavera' LIMIT 1;
  
  IF v_obra_id IS NOT NULL THEN
    INSERT INTO tb_pavimentos (id_obra, nome, ordem)
    VALUES 
      (v_obra_id, 'Térreo', 0),
      (v_obra_id, '1º Pavimento', 1),
      (v_obra_id, '2º Pavimento', 2),
      (v_obra_id, '3º Pavimento', 3)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- 6. AMBIENTES
DO $$
DECLARE
  v_pav_id UUID;
BEGIN
  SELECT id INTO v_pav_id FROM tb_pavimentos 
  WHERE id_obra = (SELECT id FROM tb_obras WHERE nome = 'Edifício Resid Primavera' LIMIT 1)
  AND nome = '1º Pavimento' LIMIT 1;
  
  IF v_pav_id IS NOT NULL THEN
    INSERT INTO tb_ambientes (id_pavimento, nome, status_bloqueio)
    VALUES 
      (v_pav_id, 'Apto 101 Sala', FALSE),
      (v_pav_id, 'Apto 101 Quarto', FALSE),
      (v_pav_id, 'Apto 101 Cozinha', FALSE),
      (v_pav_id, 'Apto 102 Sala', FALSE),
      (v_pav_id, 'Apto 102 Quarto', FALSE),
      (v_pav_id, 'Corredor', FALSE)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- 7. TABELA DE PRECOS
DO $$
DECLARE
  v_obra_id UUID;
  v_admin_id UUID;
BEGIN
  SELECT id INTO v_obra_id FROM tb_obras WHERE nome = 'Edifício Resid Primavera' LIMIT 1;
  SELECT id INTO v_admin_id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com' LIMIT 1;
  
  IF v_obra_id IS NOT NULL AND v_admin_id IS NOT NULL THEN
    INSERT INTO tb_tabela_precos (id_obra, id_servico_catalogo, preco_custo, preco_venda, status_aprovacao, id_usuario_criador, id_usuario_aprovador, data_aprovacao)
    SELECT 
      v_obra_id,
      id,
      CASE WHEN id = 1 THEN 18.00 WHEN id = 2 THEN 25.00 ELSE 20.00 END,
      CASE WHEN id = 1 THEN 25.00 WHEN id = 2 THEN 35.00 ELSE 28.00 END,
      'APROVADO',
      v_admin_id,
      v_admin_id,
      NOW()
    FROM tb_servicos_catalogo 
    WHERE id <= 5
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- 8. ITENS DE AMBIENTE
DO $$
DECLARE
  v_preco_id UUID;
  v_amb_id UUID;
BEGIN
  SELECT id INTO v_preco_id FROM tb_tabela_precos LIMIT 1;
  SELECT id INTO v_amb_id FROM tb_ambientes LIMIT 1;
  
  IF v_preco_id IS NOT NULL AND v_amb_id IS NOT NULL THEN
    INSERT INTO tb_itens_ambiente (id_ambiente, id_tabela_preco, area_planejada)
    VALUES (v_amb_id, v_preco_id, 25.00)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- 9. SESSÕES DIÁRIAS
DO $$
DECLARE
  v_encar_id UUID;
BEGIN
  SELECT id INTO v_encar_id FROM tb_usuarios WHERE email = 'encarregado@jbpinturas.com' LIMIT 1;
  
  IF v_encar_id IS NOT NULL THEN
    INSERT INTO tb_sessoes_diarias (id_encarregado, data_sessao, hora_inicio, hora_fim, geo_lat, geo_long)
    VALUES 
      (v_encar_id, NOW()::DATE, NOW(), NOW() + INTERVAL '9 hours', -23.5505, -46.6333)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- 10. ALOCAÇÕES
DO $$
DECLARE
  v_sessao_id UUID;
  v_item_id UUID;
  v_colab_id UUID;
BEGIN
  SELECT id INTO v_sessao_id FROM tb_sessoes_diarias LIMIT 1;
  SELECT id INTO v_item_id FROM tb_itens_ambiente LIMIT 1;
  SELECT id INTO v_colab_id FROM tb_colaboradores LIMIT 1;
  
  IF v_sessao_id IS NOT NULL AND v_item_id IS NOT NULL AND v_colab_id IS NOT NULL THEN
    INSERT INTO tb_alocacoes_tarefa (id_sessao, id_item_ambiente, id_colaborador, status, hora_inicio)
    VALUES (v_sessao_id, v_item_id, v_colab_id, 'EM_ANDAMENTO', NOW())
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- 11. MEDIÇÕES
DO $$
DECLARE
  v_alocacao_id UUID;
  v_obra_id UUID;
BEGIN
  SELECT id INTO v_alocacao_id FROM tb_alocacoes_tarefa LIMIT 1;
  SELECT id INTO v_obra_id FROM tb_obras LIMIT 1;
  
  IF v_alocacao_id IS NOT NULL AND v_obra_id IS NOT NULL THEN
    INSERT INTO tb_medicoes (id_alocacao, qtd_executada, flag_excedente, status_pagamento, id_obra)
    VALUES (v_alocacao_id, 20.50, FALSE, 'ABERTO', v_obra_id)
    ON CONFLICT DO NOTHING;
  END IF;
END $$;

-- Confirmação
SELECT 'Dados de teste criados com sucesso!' AS status;
SELECT COUNT(*) as total_usuarios FROM tb_usuarios;
SELECT COUNT(*) as total_clientes FROM tb_clientes;
SELECT COUNT(*) as total_colaboradores FROM tb_colaboradores;
SELECT COUNT(*) as total_obras FROM tb_obras;
SELECT COUNT(*) as total_ambientes FROM tb_ambientes;
