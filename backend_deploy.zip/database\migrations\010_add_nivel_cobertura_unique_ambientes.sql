-- Migration 010: Adiciona nivel e is_cobertura em tb_pavimentos,
--               e unique partial index em tb_ambientes(id_pavimento, nome)

-- 1. Campo nivel: numérico que representa a posição vertical do pavimento.
--    Convençao: subsolos < 0, térreo = 0, andares >= 1, cobertura = middleCount+1
ALTER TABLE tb_pavimentos
  ADD COLUMN IF NOT EXISTS nivel INT;

-- 2. Flag is_cobertura: distingue cobertura de andares normais
ALTER TABLE tb_pavimentos
  ADD COLUMN IF NOT EXISTS is_cobertura BOOLEAN NOT NULL DEFAULT FALSE;

-- 3. Índice único parcial: previne dois ambientes com mesmo nome no mesmo pavimento
--    (ignora linhas com deletado = TRUE para permitir re-criação após deleção lógica)
CREATE UNIQUE INDEX IF NOT EXISTS uq_ambientes_pavimento_nome
  ON tb_ambientes(id_pavimento, nome)
  WHERE deletado = FALSE;
