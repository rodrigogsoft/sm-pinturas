-- ============================================
-- MIGRATION: Criação de Tabelas - JB Pinturas ERP
-- Versão: 1.0.0
-- Data: 2026-02-07
-- ============================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================
-- 1. DOMÍNIO: IDENTIDADE E SEGURANÇA
-- ============================================

-- Tabela de Perfis (estática)
CREATE TABLE IF NOT EXISTS tb_perfis (
    id SMALLINT PRIMARY KEY,
    nome VARCHAR(50) UNIQUE NOT NULL,
    descricao TEXT,
    permissoes_json JSONB
);

-- Inserir perfis base
INSERT INTO tb_perfis (id, nome, descricao) VALUES
(1, 'ADMIN', 'Administrador do sistema'),
(2, 'GESTOR', 'Gestor com poder de aprovação'),
(3, 'FINANCEIRO', 'Responsável pelo setor financeiro'),
(4, 'ENCARREGADO', 'Encarregado de obra (cego financeiramente)')
ON CONFLICT (id) DO NOTHING;

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS tb_usuarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome_completo VARCHAR(200) NOT NULL,
    email VARCHAR(200) UNIQUE NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    id_perfil SMALLINT NOT NULL REFERENCES tb_perfis(id),
    ativo BOOLEAN DEFAULT TRUE,
    mfa_secret VARCHAR(32),
    mfa_habilitado BOOLEAN DEFAULT FALSE,
    ultimo_acesso TIMESTAMPTZ,
    id_criado_por UUID REFERENCES tb_usuarios(id),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_usuarios_email ON tb_usuarios(email) WHERE deletado = FALSE;
CREATE INDEX idx_usuarios_perfil ON tb_usuarios(id_perfil);

-- ============================================
-- 2. DOMÍNIO: CADASTROS BASE
-- ============================================

-- Clientes
CREATE TABLE IF NOT EXISTS tb_clientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    razao_social VARCHAR(200) NOT NULL,
    cnpj_nif VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(200),
    telefone VARCHAR(20),
    endereco TEXT,
    dia_corte SMALLINT CHECK (dia_corte BETWEEN 1 AND 31),
    dados_bancarios_enc TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_clientes_cnpj ON tb_clientes(cnpj_nif) WHERE deletado = FALSE;

-- Colaboradores
CREATE TABLE IF NOT EXISTS tb_colaboradores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome_completo VARCHAR(200) NOT NULL,
    cpf_nif VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(200),
    telefone VARCHAR(20),
    data_nascimento DATE,
    endereco TEXT,
    ativo BOOLEAN DEFAULT TRUE,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_colaboradores_cpf ON tb_colaboradores(cpf_nif) WHERE deletado = FALSE;

-- ============================================
-- 3. DOMÍNIO: ENGENHARIA E OBRAS
-- ============================================

-- Obras
CREATE TABLE IF NOT EXISTS tb_obras (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome VARCHAR(200) NOT NULL,
    endereco_completo TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'PLANEJAMENTO' CHECK (status IN ('PLANEJAMENTO', 'ATIVA', 'SUSPENSA', 'CONCLUIDA')),
    data_inicio DATE NOT NULL,
    data_previsao_fim DATE,
    data_conclusao DATE,
    observacoes TEXT,
    id_cliente UUID NOT NULL REFERENCES tb_clientes(id),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_obras_cliente ON tb_obras(id_cliente);
CREATE INDEX idx_obras_status ON tb_obras(status) WHERE deletado = FALSE;

-- Pavimentos
CREATE TABLE IF NOT EXISTS tb_pavimentos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_obra UUID NOT NULL REFERENCES tb_obras(id) ON DELETE CASCADE,
    nome VARCHAR(100) NOT NULL,
    ordem INT NOT NULL,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pavimentos_obra ON tb_pavimentos(id_obra);

-- Ambientes
CREATE TABLE IF NOT EXISTS tb_ambientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_pavimento UUID NOT NULL REFERENCES tb_pavimentos(id) ON DELETE CASCADE,
    nome VARCHAR(100) NOT NULL,
    area_m2 DECIMAL(10,2),
    descricao TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ambientes_pavimento ON tb_ambientes(id_pavimento);

-- ============================================
-- 4. DOMÍNIO: SERVIÇOS E PRECIFICAÇÃO
-- ============================================

-- Catálogo de Serviços (global)
CREATE TABLE IF NOT EXISTS tb_catalogo_servicos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    unidade_medida VARCHAR(10) CHECK (unidade_medida IN ('M2', 'ML', 'UN', 'VB')),
    permite_decimal BOOLEAN DEFAULT TRUE,
    descricao TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Preços (dual: custo e venda)
CREATE TABLE IF NOT EXISTS tb_tabela_precos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_obra UUID NOT NULL REFERENCES tb_obras(id),
    id_servico_catalogo INT NOT NULL REFERENCES tb_catalogo_servicos(id),
    preco_custo DECIMAL(10,2) NOT NULL,
    preco_venda DECIMAL(10,2),
    status_aprovacao VARCHAR(20) DEFAULT 'PENDENTE' CHECK (status_aprovacao IN ('PENDENTE', 'APROVADO', 'REJEITADO')),
    id_aprovado_por UUID REFERENCES tb_usuarios(id),
    data_aprovacao TIMESTAMPTZ,
    margem_percentual DECIMAL(5,2),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_precos_obra ON tb_tabela_precos(id_obra);
CREATE INDEX idx_precos_status ON tb_tabela_precos(status_aprovacao);

-- ============================================
-- 5. DOMÍNIO: OPERAÇÃO DE CAMPO
-- ============================================

-- Sessões Diárias (RDO)
CREATE TABLE IF NOT EXISTS tb_sessoes_diarias (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_encarregado UUID NOT NULL REFERENCES tb_usuarios(id),
    id_obra UUID REFERENCES tb_obras(id),
    data_sessao DATE NOT NULL,
    hora_inicio TIMESTAMPTZ NOT NULL,
    hora_fim TIMESTAMPTZ,
    geo_lat FLOAT,
    geo_long FLOAT,
    assinatura_url TEXT,
    observacoes TEXT,
    status VARCHAR(20) DEFAULT 'ABERTA' CHECK (status IN ('ABERTA', 'ENCERRADA')),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sessoes_encarregado ON tb_sessoes_diarias(id_encarregado);
CREATE INDEX idx_sessoes_data ON tb_sessoes_diarias(data_sessao);
CREATE INDEX idx_sessoes_status ON tb_sessoes_diarias(status) WHERE deletado = FALSE;

-- Alocações de Tarefa (1:1)
CREATE TABLE IF NOT EXISTS tb_alocacoes_tarefa (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_sessao UUID NOT NULL REFERENCES tb_sessoes_diarias(id),
    id_ambiente UUID NOT NULL REFERENCES tb_ambientes(id),
    id_colaborador UUID NOT NULL REFERENCES tb_colaboradores(id),
    id_servico_catalogo INT REFERENCES tb_catalogo_servicos(id),
    status VARCHAR(20) DEFAULT 'EM_ANDAMENTO' CHECK (status IN ('EM_ANDAMENTO', 'CONCLUIDO', 'PAUSADO')),
    hora_inicio TIMESTAMPTZ NOT NULL,
    hora_fim TIMESTAMPTZ,
    observacoes TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Regra 1:1: só um colaborador ativo por ambiente
CREATE UNIQUE INDEX unique_ambiente_ativo
ON tb_alocacoes_tarefa (id_ambiente, status)
WHERE status = 'EM_ANDAMENTO' AND deletado = FALSE;

CREATE INDEX idx_alocacoes_sessao ON tb_alocacoes_tarefa(id_sessao);
CREATE INDEX idx_alocacoes_colaborador ON tb_alocacoes_tarefa(id_colaborador);
CREATE INDEX idx_alocacoes_status ON tb_alocacoes_tarefa(status) WHERE deletado = FALSE;

-- Medições
CREATE TABLE IF NOT EXISTS tb_medicoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_alocacao UUID NOT NULL REFERENCES tb_alocacoes_tarefa(id),
    qtd_executada DECIMAL(10,2) NOT NULL,
    area_planejada DECIMAL(10,2),
    flag_excedente BOOLEAN DEFAULT FALSE,
    justificativa TEXT,
    foto_evidencia_url TEXT,
    status_pagamento VARCHAR(20) DEFAULT 'ABERTO' CHECK (status_pagamento IN ('ABERTO', 'LOTE_CRIADO', 'PAGO')),
    id_lote_pagamento UUID,
    valor_calculado DECIMAL(10,2),
    data_medicao DATE NOT NULL,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_medicoes_alocacao ON tb_medicoes(id_alocacao);
CREATE INDEX idx_medicoes_status_pagamento ON tb_medicoes(status_pagamento);
CREATE INDEX idx_medicoes_data ON tb_medicoes(data_medicao);
CREATE INDEX idx_medicoes_excedente ON tb_medicoes(flag_excedente) WHERE flag_excedente = TRUE;

-- ============================================
-- 6. DOMÍNIO: FINANCEIRO
-- ============================================

-- Lotes de Pagamento
CREATE TABLE IF NOT EXISTS tb_lotes_pagamento (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    descricao VARCHAR(100) NOT NULL,
    data_competencia DATE NOT NULL,
    data_pagamento DATE,
    valor_total DECIMAL(12,2) NOT NULL,
    qtd_medicoes INT NOT NULL,
    status VARCHAR(30) DEFAULT 'RASCUNHO' CHECK (status IN ('RASCUNHO', 'AGUARDANDO_APROVACAO', 'APROVADO', 'PROCESSANDO', 'PAGO', 'CANCELADO')),
    tipo_pagamento VARCHAR(20) CHECK (tipo_pagamento IN ('PIX', 'TED', 'DINHEIRO', 'CHEQUE')),
    id_criado_por UUID NOT NULL REFERENCES tb_usuarios(id),
    id_aprovado_por UUID REFERENCES tb_usuarios(id),
    observacoes TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_lotes_status ON tb_lotes_pagamento(status);
CREATE INDEX idx_lotes_data_competencia ON tb_lotes_pagamento(data_competencia);

-- Adicionar FK de lote nas medições
ALTER TABLE tb_medicoes 
ADD CONSTRAINT fk_medicoes_lote 
FOREIGN KEY (id_lote_pagamento) 
REFERENCES tb_lotes_pagamento(id);

-- ============================================
-- 7. DOMÍNIO: NOTIFICAÇÕES
-- ============================================

CREATE TABLE IF NOT EXISTS tb_notificacoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_usuario_destinatario UUID NOT NULL REFERENCES tb_usuarios(id),
    tipo VARCHAR(50) NOT NULL CHECK (tipo IN ('MEDICAO_PENDENTE', 'CICLO_FATURAMENTO', 'LOTE_APROVACAO', 'PRECO_PENDENTE', 'OBRA_ATRASO', 'SISTEMA')),
    titulo VARCHAR(200) NOT NULL,
    mensagem TEXT NOT NULL,
    prioridade VARCHAR(20) DEFAULT 'MEDIA' CHECK (prioridade IN ('BAIXA', 'MEDIA', 'ALTA', 'CRITICA')),
    lida BOOLEAN DEFAULT FALSE,
    lida_em TIMESTAMPTZ,
    dados_extras JSONB,
    id_entidade_relacionada UUID,
    tipo_entidade VARCHAR(100),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notificacoes_usuario ON tb_notificacoes(id_usuario_destinatario);
CREATE INDEX idx_notificacoes_lida ON tb_notificacoes(lida) WHERE lida = FALSE;
CREATE INDEX idx_notificacoes_prioridade ON tb_notificacoes(prioridade);

-- ============================================
-- 8. DOMÍNIO: AUDITORIA
-- ============================================

CREATE TABLE IF NOT EXISTS tb_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    momento TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    id_usuario UUID NOT NULL REFERENCES tb_usuarios(id),
    tabela_afetada VARCHAR(100) NOT NULL,
    id_registro UUID,
    acao VARCHAR(20) NOT NULL CHECK (acao IN ('INSERT', 'UPDATE', 'DELETE', 'APPROVE', 'REJECT', 'LOGIN', 'LOGOUT', 'EXPORT')),
    dados_antes JSONB,
    dados_depois JSONB,
    ip_origem INET,
    user_agent VARCHAR(500),
    justificativa TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Índices para performance em consultas de auditoria
CREATE INDEX idx_audit_logs_usuario ON tb_audit_logs(id_usuario);
CREATE INDEX idx_audit_logs_tabela ON tb_audit_logs(tabela_afetada);
CREATE INDEX idx_audit_logs_momento ON tb_audit_logs(momento);
CREATE INDEX idx_audit_logs_registro ON tb_audit_logs(tabela_afetada, id_registro);
CREATE INDEX idx_audit_logs_acao ON tb_audit_logs(acao);

-- Prevenir DELETE em audit logs (imutável)
CREATE OR REPLACE RULE prevent_audit_delete AS 
ON DELETE TO tb_audit_logs 
DO INSTEAD NOTHING;

-- Prevenir UPDATE em audit logs (imutável)
CREATE OR REPLACE RULE prevent_audit_update AS 
ON UPDATE TO tb_audit_logs 
DO INSTEAD NOTHING;

-- ============================================
-- 9. TRIGGERS E FUNÇÕES
-- ============================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar trigger em todas as tabelas relevantes
DO $$
DECLARE
    t text;
BEGIN
    FOR t IN 
        SELECT table_name 
        FROM information_schema.columns 
        WHERE column_name = 'updated_at' 
        AND table_schema = 'public'
    LOOP
        EXECUTE format('
            DROP TRIGGER IF EXISTS trigger_update_timestamp ON %I;
            CREATE TRIGGER trigger_update_timestamp
            BEFORE UPDATE ON %I
            FOR EACH ROW
            EXECUTE FUNCTION update_updated_at_column();
        ', t, t);
    END LOOP;
END;
$$;

-- ============================================
-- 10. VIEWS ÚTEIS
-- ============================================

-- View: Medições com detalhes completos
CREATE OR REPLACE VIEW vw_medicoes_completas AS
SELECT 
    m.id,
    m.qtd_executada,
    m.flag_excedente,
    m.status_pagamento,
    m.data_medicao,
    m.valor_calculado,
    c.nome_completo AS colaborador_nome,
    c.cpf_nif AS colaborador_cpf,
    a.nome AS ambiente_nome,
    p.nome AS pavimento_nome,
    o.nome AS obra_nome,
    o.id AS obra_id,
    s.nome AS servico_nome,
    tp.preco_custo,
    m.created_at
FROM tb_medicoes m
INNER JOIN tb_alocacoes_tarefa at ON m.id_alocacao = at.id
INNER JOIN tb_colaboradores c ON at.id_colaborador = c.id
INNER JOIN tb_ambientes a ON at.id_ambiente = a.id
INNER JOIN tb_pavimentos p ON a.id_pavimento = p.id
INNER JOIN tb_obras o ON p.id_obra = o.id
LEFT JOIN tb_catalogo_servicos s ON at.id_servico_catalogo = s.id
LEFT JOIN tb_tabela_precos tp ON tp.id_obra = o.id AND tp.id_servico_catalogo = at.id_servico_catalogo
WHERE m.deletado = FALSE;

-- View: Dashboard de obras
CREATE OR REPLACE VIEW vw_dashboard_obras AS
SELECT 
    o.id,
    o.nome,
    o.status,
    o.data_inicio,
    o.data_previsao_fim,
    cl.razao_social AS cliente,
    COUNT(DISTINCT p.id) AS total_pavimentos,
    COUNT(DISTINCT a.id) AS total_ambientes,
    COUNT(DISTINCT m.id) AS total_medicoes,
    COALESCE(SUM(m.qtd_executada), 0) AS total_executado
FROM tb_obras o
INNER JOIN tb_clientes cl ON o.id_cliente = cl.id
LEFT JOIN tb_pavimentos p ON o.id = p.id_obra
LEFT JOIN tb_ambientes a ON p.id = a.id_pavimento
LEFT JOIN tb_alocacoes_tarefa at ON a.id = at.id_ambiente
LEFT JOIN tb_medicoes m ON at.id = m.id_alocacao
WHERE o.deletado = FALSE
GROUP BY o.id, o.nome, o.status, o.data_inicio, o.data_previsao_fim, cl.razao_social;

-- ============================================
-- FIM DA MIGRATION
-- ============================================
