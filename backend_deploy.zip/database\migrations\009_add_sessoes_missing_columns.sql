-- =====================================================================
-- Migration: 009_add_sessoes_missing_columns.sql
-- Objetivo: Adicionar colunas id_obra e status à tabela tb_sessoes_diarias
-- Data: 2026-02-25
-- =====================================================================

-- Adicionar coluna id_obra
ALTER TABLE tb_sessoes_diarias 
ADD COLUMN IF NOT EXISTS id_obra UUID;

-- Adicionar foreign key para obras (somente se não existir)
DO $$ BEGIN
    ALTER TABLE tb_sessoes_diarias 
    ADD CONSTRAINT tb_sessoes_diarias_id_obra_fkey 
    FOREIGN KEY (id_obra) REFERENCES tb_obras(id);
EXCEPTION
    WHEN duplicate_object THEN NULL;
END $$;

-- Criar tipo ENUM para status se não existir
DO $$ BEGIN
    CREATE TYPE enum_sessao_status AS ENUM ('ABERTA', 'ENCERRADA');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- Adicionar coluna status
ALTER TABLE tb_sessoes_diarias 
ADD COLUMN IF NOT EXISTS status enum_sessao_status DEFAULT 'ABERTA';

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_sessoes_obra ON tb_sessoes_diarias(id_obra);
CREATE INDEX IF NOT EXISTS idx_sessoes_status ON tb_sessoes_diarias(status);

-- Atualizar sessões existentes que não têm status definido
UPDATE tb_sessoes_diarias 
SET status = 'ENCERRADA' 
WHERE hora_fim IS NOT NULL AND status IS NULL;

UPDATE tb_sessoes_diarias 
SET status = 'ABERTA' 
WHERE hora_fim IS NULL AND status IS NULL;
