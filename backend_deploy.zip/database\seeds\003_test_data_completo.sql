-- =============================================
-- SEEDS: Dados de Teste Completos - JB Pinturas ERP v4.0
-- Versão: 2.0.0
-- Descrição: Dados para testes end-to-end incluindo:
--   - Usuários com diferentes perfis
--   - Clientes e obras
--   - Colaboradores e alocações
--   - Sessões diárias e medições
-- =============================================

-- =============================================
-- 1. DADOS DE PERFIS (Já criados em init.sql)
-- =============================================

-- Garantir que perfis essenciais existem
INSERT INTO tb_perfis (id, nome, permissoes_json) VALUES
(1, 'ADMINISTRADOR', '{"can_manage_users": true, "can_view_audit": true, "can_force_billing": true}'),
(2, 'GESTOR', '{"can_approve_prices": true, "can_view_margins": true, "can_view_sensitive_data": true}'),
(3, 'FINANCEIRO', '{"can_create_prices": true, "can_manage_payments": true, "can_view_sensitive_data": true}'),
(4, 'ENCARREGADO', '{"can_create_obras": true, "can_allocate_tasks": true, "can_register_production": true}')
ON CONFLICT (id) DO NOTHING;

-- =============================================
-- 2. USUÁRIOS (com senhas em plain - trocar em produção)
-- =============================================
-- Senha: Admin@2026 (hash será gerado na aplicação)

INSERT INTO tb_usuarios (
  id, nome_completo, email, senha_hash, id_perfil, 
  fcm_token, status, created_at
) VALUES
(
  gen_random_uuid(),
  'Administrador Sistema',
  'admin@jbpinturas.com',
  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', -- Admin@2026
  1,
  'fcm_token_admin_12345',
  'ATIVO',
  NOW() - INTERVAL '60 days'
),
(
  gen_random_uuid(),
  'Gestor Obras',
  'gestor@jbpinturas.com',
  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', -- Admin@2026
  2,
  'fcm_token_gestor_12345',
  'ATIVO',
  NOW() - INTERVAL '50 days'
),
(
  gen_random_uuid(),
  'Financeiro JB',
  'financeiro@jbpinturas.com',
  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', -- Admin@2026
  3,
  'fcm_token_finance_12345',
  'ATIVO',
  NOW() - INTERVAL '45 days'
),
(
  gen_random_uuid(),
  'Encarregado João Silva',
  'encarregado@jbpinturas.com',
  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', -- Admin@2026
  4,
  'fcm_token_joao_12345',
  'ATIVO',
  NOW() - INTERVAL '30 days'
),
(
  gen_random_uuid(),
  'Encarregado Maria Santos',
  'encarregado2@jbpinturas.com',
  '$2b$10$N9qo8uLOickgx2ZMRZoE5.L4fA8rZsCvxNfK4K6b5ObJ5p3x9L7eG', -- Admin@2026
  4,
  'fcm_token_maria_12345',
  'ATIVO',
  NOW() - INTERVAL '25 days'
)
ON CONFLICT (email) DO NOTHING;

-- Guardar IDs dos usuários para usar depois
DO $$
DECLARE
  v_admin_id UUID;
  v_encar1_id UUID;
  v_encar2_id UUID;
BEGIN
  SELECT id INTO v_admin_id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com';
  SELECT id INTO v_encar1_id FROM tb_usuarios WHERE email = 'encarregado@jbpinturas.com';
  SELECT id INTO v_encar2_id FROM tb_usuarios WHERE email = 'encarregado2@jbpinturas.com';
  
  -- Salvar na sessão para reusar
  PERFORM set_config('session.admin_id', v_admin_id::text, false);
  PERFORM set_config('session.encar1_id', v_encar1_id::text, false);
  PERFORM set_config('session.encar2_id', v_encar2_id::text, false);
END $$;

-- =============================================
-- 3. CLIENTES
-- =============================================

INSERT INTO tb_clientes (
  id, razao_social, cnpj_nif, email, telefone, 
  endereco, dia_corte, created_at
) VALUES
(
  gen_random_uuid(),
  'Construtora Exemplo LTDA',
  '12.345.678/0001-99',
  'contato@construtora.com.br',
  '(11) 98765-4321',
  'Av. Paulista, 1000 - São Paulo, SP',
  15,
  NOW() - INTERVAL '90 days'
),
(
  gen_random_uuid(),
  'Incorporadora ABC S.A.',
  '98.765.432/0001-11',
  'vendas@incorporadora.com.br',
  '(21) 99876-5432',
  'Av. Presidente Vargas, 500 - Rio de Janeiro, RJ',
  25,
  NOW() - INTERVAL '80 days'
),
(
  gen_random_uuid(),
  'Engenharia & Construção XYZ',
  '11.111.111/0001-22',
  'proyectos@engenharia.com.br',
  '(31) 97777-8888',
  'Rua Getúlio Vargas, 200 - Belo Horizonte, MG',
  10,
  NOW() - INTERVAL '60 days'
)
ON CONFLICT (cnpj_nif) DO NOTHING;

-- =============================================
-- 4. COLABORADORES (Pintores, Encanadores, etc)
-- =============================================

INSERT INTO tb_colaboradores (
  id, nome, cpf, telefone, ativo, created_at
) VALUES
(
  gen_random_uuid(),
  'Carlos Pintor Silva',
  '11111111111',
  '(11) 99111-1111',
  TRUE,
  NOW() - INTERVAL '120 days'
),
(
  gen_random_uuid(),
  'Ana Paula Pintora',
  '22222222222',
  '(11) 99222-2222',
  TRUE,
  NOW() - INTERVAL '110 days'
),
(
  gen_random_uuid(),
  'Pedro Costa Pintor',
  '33333333333',
  '(11) 99333-3333',
  TRUE,
  NOW() - INTERVAL '100 days'
),
(
  gen_random_uuid(),
  'Marcos Souza Pintor',
  '44444444444',
  '(11) 99444-4444',
  TRUE,
  NOW() - INTERVAL '90 days'
),
(
  gen_random_uuid(),
  'Lucia Oliveira Pintora',
  '55555555555',
  '(11) 99555-5555',
  TRUE,
  NOW() - INTERVAL '80 days'
),
(
  gen_random_uuid(),
  'Roberto Santos Pintor',
  '66666666666',
  '(11) 99666-6666',
  TRUE,
  NOW() - INTERVAL '70 days'
)
ON CONFLICT (cpf) DO NOTHING;

-- =============================================
-- 5. OBRAS (Projetos/Construções)
-- =============================================

INSERT INTO tb_obras (
  id, nome, endereco_completo, data_inicio, data_previsao_fim,
  status, id_cliente, id_usuario_criador, 
  margem_minima_percentual, observacoes
) 
SELECT 
  gen_random_uuid(),
  u.nome,
  u.endereco,
  u.data_inicio,
  u.data_previsao_fim,
  u.status,
  (SELECT id FROM tb_clientes WHERE razao_social = 'Construtora Exemplo LTDA' LIMIT 1),
  (SELECT id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com'),
  20.00,
  u.observacoes
FROM (
  VALUES
  ('Edifício Residencial Primavera', 'Av. Paulista, 1000 - São Paulo, SP', '2026-01-15'::DATE, '2026-06-30'::DATE, 'ATIVA', 'Torre A com 4 pavimentos, 32 apartamentos'),
  ('Centro Comercial Downtown', 'Rua Augusta, 2500 - São Paulo, SP', '2026-02-01'::DATE, '2026-08-15'::DATE, 'ATIVA', 'Reforma completa de loja integrada'),
  ('Reforma Hotel Príncipe', 'Av. Atlântica, 3000 - Rio de Janeiro, RJ', '2025-12-01'::DATE, '2026-05-31'::DATE, 'ATIVA', 'Pintura de hóspedes e áreas comuns')
) AS u(nome, endereco, data_inicio, data_previsao_fim, status, observacoes)
WHERE NOT EXISTS (SELECT 1 FROM tb_obras WHERE nome = u.nome);

-- =============================================
-- 6. PAVIMENTOS (Organização vertical das obras)
-- =============================================

DO $$
DECLARE
  v_obra_id UUID;
  v_contador INT;
BEGIN
  -- Primavera: Térreo + 4 pavimentos
  SELECT id INTO v_obra_id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera';
  DELETE FROM tb_pavimentos WHERE id_obra = v_obra_id;
  
  FOR v_contador IN 0..4 LOOP
    INSERT INTO tb_pavimentos (id_obra, nome, ordem) VALUES (
      v_obra_id,
      CASE 
        WHEN v_contador = 0 THEN 'Térreo'
        WHEN v_contador = 1 THEN '1º Pavimento'
        WHEN v_contador = 2 THEN '2º Pavimento'
        WHEN v_contador = 3 THEN '3º Pavimento'
        WHEN v_contador = 4 THEN '4º Pavimento'
      END,
      v_contador
    );
  END LOOP;
END $$;

DO $$
DECLARE
  v_obra_id UUID;
BEGIN
  -- Downtown: Térreo + 3 pavimentos
  SELECT id INTO v_obra_id FROM tb_obras WHERE nome = 'Centro Comercial Downtown';
  DELETE FROM tb_pavimentos WHERE id_obra = v_obra_id;
  
  INSERT INTO tb_pavimentos (id_obra, nome, ordem) VALUES
  (v_obra_id, 'Térreo', 0),
  (v_obra_id, 'Primo Pavimento', 1),
  (v_obra_id, 'Segundo Pavimento', 2),
  (v_obra_id, 'Terceiro Pavimento', 3);
END $$;

DO $$
DECLARE
  v_obra_id UUID;
BEGIN
  -- Hotel: Térreo, Recepção e 2 andares
  SELECT id INTO v_obra_id FROM tb_obras WHERE nome = 'Reforma Hotel Príncipe';
  DELETE FROM tb_pavimentos WHERE id_obra = v_obra_id;
  
  INSERT INTO tb_pavimentos (id_obra, nome, ordem) VALUES
  (v_obra_id, 'Térreo', 0),
  (v_obra_id, 'Recepção', 1),
  (v_obra_id, 'Alas 1º Andar', 2),
  (v_obra_id, 'Alas 2º Andar', 3);
END $$;

-- =============================================
-- 7. AMBIENTES (Cômodos/Salas)
-- =============================================

DO $$
DECLARE
  v_pav_id UUID;
  v_contador INT;
BEGIN
  -- Ambientes do 1º Pavimento da Primavera (Apartamentos)
  SELECT id INTO v_pav_id 
  FROM tb_pavimentos 
  WHERE id_obra = (SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera')
  AND nome = '1º Pavimento';
  
  DELETE FROM tb_ambientes WHERE id_pavimento = v_pav_id;
  
  FOR v_contador IN 101..104 LOOP
    INSERT INTO tb_ambientes (id_pavimento, nome, status_bloqueio) VALUES
    (v_pav_id, 'Apto ' || v_contador || ' - Sala', FALSE),
    (v_pav_id, 'Apto ' || v_contador || ' - Quarto Casal', FALSE),
    (v_pav_id, 'Apto ' || v_contador || ' - Quarto Solteiro', FALSE),
    (v_pav_id, 'Apto ' || v_contador || ' - Cozinha', FALSE),
    (v_pav_id, 'Apto ' || v_contador || ' - Banheiro', FALSE);
  END LOOP;
  
  -- Corredor
  INSERT INTO tb_ambientes (id_pavimento, nome, status_bloqueio) VALUES
  (v_pav_id, 'Corredor Central 1º Pav', FALSE);
END $$;

DO $$
DECLARE
  v_pav_id UUID;
BEGIN
  -- Ambientes do Downtown (Lojas)
  SELECT id INTO v_pav_id 
  FROM tb_pavimentos 
  WHERE id_obra = (SELECT id FROM tb_obras WHERE nome = 'Centro Comercial Downtown')
  AND nome = 'Térreo';
  
  DELETE FROM tb_ambientes WHERE id_pavimento = v_pav_id;
  
  INSERT INTO tb_ambientes (id_pavimento, nome, status_bloqueio) VALUES
  (v_pav_id, 'Loja 01 - Entrada', FALSE),
  (v_pav_id, 'Loja 01 - Balcão', FALSE),
  (v_pav_id, 'Loja 01 - Estoque', FALSE),
  (v_pav_id, 'Loja 02 - Área Comercial', FALSE),
  (v_pav_id, 'Corredor Principal', FALSE),
  (v_pav_id, 'Banheiros Públicos', FALSE);
END $$;

-- =============================================
-- 8. CATÁLOGO DE SERVIÇOS (Verificar se não duplica)
-- =============================================

INSERT INTO tb_servicos_catalogo (
  nome, descricao, unidade_medida, categoria, permite_decimal, valor_base, ativo
) VALUES
('Pintura Látex 2 Demãos', 'Pintura em látex acrílico com 2 demãos', 'M2', 'PINTURA', TRUE, 0.00, TRUE),
('Pintura Látex 3 Demãos', 'Pintura em látex acrílico com 3 demãos (Premium)', 'M2', 'PINTURA', TRUE, 0.00, TRUE),
('Pintura Acrílica Externa', 'Pintura para fachadas externa com acrílico', 'M2', 'PINTURA', TRUE, 0.00, TRUE),
('Pintura Esmalte', 'Pintura em esmalte para ferro/madeira', 'M2', 'PINTURA', TRUE, 0.00, TRUE),
('Massa Corrida + Selador', 'Aplicação de massa corrida PVA + selador acrílico', 'M2', 'PREP', TRUE, 0.00, TRUE),
('Textura Grafiato', 'Aplicação de textura grafiato', 'M2', 'TEXTURAS', TRUE, 0.00, TRUE),
('Pintura Teto (Látex)', 'Pintura de forro/laje com tinta látex branca', 'M2', 'PINTURA', TRUE, 0.00, TRUE),
('Impermeabilização', 'Aplicação de manta asfáltica ou impermeabilizante', 'M2', 'IMPERMEAB', TRUE, 0.00, TRUE),
('Rodapé/Barra (Pintura)', 'Pintura linear de rodapé ou barra decorativa', 'ML', 'LINEARES', TRUE, 0.00, TRUE),
('Porta/Janela (Pintura)', 'Pintura completa de porta ou janela (esquadria)', 'UN', 'UNITARIOS', FALSE, 0.00, TRUE),
('Grade/Portão (Pintura)', 'Pintura de grade ou portão metálico', 'UN', 'UNITARIOS', FALSE, 0.00, TRUE),
('Serviço Avulso', 'Serviço não catalogado - valor fixo negociado', 'VB', 'EVENTUAIS', FALSE, 0.00, TRUE)
ON CONFLICT DO NOTHING;

-- =============================================
-- 9. TABELA DE PREÇOS (Por obra/serviço)
-- =============================================

DO $$
DECLARE
  v_obra_id UUID;
  v_admin_id UUID;
BEGIN
  SELECT id INTO v_obra_id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera';
  SELECT id INTO v_admin_id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com';
  
  DELETE FROM tb_tabela_precos WHERE id_obra = v_obra_id;
  
  INSERT INTO tb_tabela_precos (
    id_obra, id_servico_catalogo, preco_custo, preco_venda,
    status_aprovacao, id_usuario_criador, id_usuario_aprovador,
    data_aprovacao, created_at
  )
  SELECT 
    v_obra_id,
    sc.id,
    CASE 
      WHEN sc.nome LIKE '%Látex 2%' THEN 18.00
      WHEN sc.nome LIKE '%Látex 3%' THEN 25.00
      WHEN sc.nome LIKE '%Acrílica%' THEN 30.00
      WHEN sc.nome LIKE '%Esmalte%' THEN 22.00
      WHEN sc.nome LIKE '%Massa%' THEN 15.00
      WHEN sc.nome LIKE '%Grafiato%' THEN 28.00
      WHEN sc.nome LIKE '%Teto%' THEN 20.00
      WHEN sc.nome LIKE '%Impermeab%' THEN 35.00
      WHEN sc.nome LIKE '%Rodapé%' THEN 5.00
      WHEN sc.nome LIKE '%Porta%' THEN 80.00
      WHEN sc.nome LIKE '%Grade%' THEN 100.00
      ELSE 50.00
    END AS preco_custo,
    CASE 
      WHEN sc.nome LIKE '%Látex 2%' THEN 25.00
      WHEN sc.nome LIKE '%Látex 3%' THEN 35.00
      WHEN sc.nome LIKE '%Acrílica%' THEN 42.00
      WHEN sc.nome LIKE '%Esmalte%' THEN 30.00
      WHEN sc.nome LIKE '%Massa%' THEN 22.00
      WHEN sc.nome LIKE '%Grafiato%' THEN 40.00
      WHEN sc.nome LIKE '%Teto%' THEN 28.00
      WHEN sc.nome LIKE '%Impermeab%' THEN 52.00
      WHEN sc.nome LIKE '%Rodapé%' THEN 8.00
      WHEN sc.nome LIKE '%Porta%' THEN 120.00
      WHEN sc.nome LIKE '%Grade%' THEN 150.00
      ELSE 75.00
    END AS preco_venda,
    'APROVADO',
    v_admin_id,
    v_admin_id,
    NOW() - INTERVAL '20 days',
    NOW() - INTERVAL '20 days'
  FROM tb_servicos_catalogo sc
  WHERE sc.ativo = TRUE;
END $$;

-- =============================================
-- 10. ITENS DE AMBIENTE (Planejamento de escopo)
-- =============================================

DO $$
DECLARE
  v_amb_id UUID;
  v_preco_id UUID;
  v_contador INT := 0;
BEGIN
  -- Ambientes da Primavera 1º Pav
  FOR v_amb_id IN 
    SELECT id FROM tb_ambientes 
    WHERE id_pavimento = (
      SELECT id FROM tb_pavimentos 
      WHERE id_obra = (SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera')
      AND nome = '1º Pavimento'
    )
    LIMIT 10
  LOOP
    -- Atribuir serviços aos ambientes
    SELECT id INTO v_preco_id FROM tb_tabela_precos 
    WHERE id_obra = (SELECT id FROM tb_obras WHERE nome = 'Edifício Residencial Primavera')
    AND id_servico_catalogo = (
      SELECT id FROM tb_servicos_catalogo 
      WHERE nome = 'Pintura Látex 2 Demãos'
    )
    LIMIT 1;
    
    IF v_preco_id IS NOT NULL THEN
      INSERT INTO tb_itens_ambiente (
        id_ambiente, id_tabela_preco, area_planejada
      ) VALUES (v_amb_id, v_preco_id, 20.00 + (v_contador * 2));
      
      v_contador := v_contador + 1;
    END IF;
  END LOOP;
END $$;

-- =============================================
-- 11. SESSÕES DIÁRIAS (RDO - Relatório Diário de Obra)
-- =============================================

DO $$
DECLARE
  v_encar_id UUID;
  v_data DATE;
  v_contador INT;
BEGIN
  SELECT id INTO v_encar_id FROM tb_usuarios WHERE email = 'encarregado@jbpinturas.com';
  
  FOR v_contador IN 0..5 LOOP
    v_data := NOW()::DATE - (v_contador || ' days')::INTERVAL;
    
    INSERT INTO tb_sessoes_diarias (
      id, id_encarregado, data_sessao, hora_inicio, hora_fim,
      geo_lat, geo_long, observacoes, created_at
    ) VALUES (
      gen_random_uuid(),
      v_encar_id,
      v_data,
      (v_data || ' 08:00:00')::TIMESTAMP WITH TIME ZONE,
      (v_data || ' 17:00:00')::TIMESTAMP WITH TIME ZONE,
      -23.5505,
      -46.6333,
      'Sessão de trabalho regular - Dia ' || v_contador,
      NOW() - INTERVAL '5 days'
    );
  END LOOP;
END $$;

-- =============================================
-- 12. ALOCAÇÕES DE TAREFA (Quem faz o quê e quando)
-- =============================================

DO $$
DECLARE
  v_sessao_id UUID;
  v_item_id UUID;
  v_colab_id UUID;
  v_contador INT := 0;
BEGIN
  -- Pegar primeira sessão disponível
  SELECT id INTO v_sessao_id FROM tb_sessoes_diarias LIMIT 1;
  
  -- Pegar primeiro item de ambiente
  SELECT id INTO v_item_id FROM tb_itens_ambiente LIMIT 1;
  
  -- Para cada colaborador, criar uma alocação
  FOR v_colab_id IN SELECT id FROM tb_colaboradores LIMIT 3 LOOP
    IF v_sessao_id IS NOT NULL AND v_item_id IS NOT NULL THEN
      INSERT INTO tb_alocacoes_tarefa (
        id, id_sessao, id_item_ambiente, id_colaborador,
        status, hora_inicio, hora_fim, created_at
      ) VALUES (
        gen_random_uuid(),
        v_sessao_id,
        v_item_id,
        v_colab_id,
        CASE 
          WHEN v_contador = 0 THEN 'CONCLUIDO'
          WHEN v_contador = 1 THEN 'EM_ANDAMENTO'
          ELSE 'PAUSADO'
        END,
        NOW() - INTERVAL '1 day',
        CASE WHEN v_contador = 0 THEN NOW() - INTERVAL '4 hours' ELSE NULL END,
        NOW() - INTERVAL '1 day'
      );
      
      v_contador := v_contador + 1;
    END IF;
  END LOOP;
END $$;

-- =============================================
-- 13. MEDIÇÕES (Resultado do trabalho)
-- =============================================

DO $$
DECLARE
  v_alocacao_id UUID;
  v_obra_id UUID;
  v_contador INT := 0;
BEGIN
  -- Para cada alocação concluída, criar uma medição
  FOR v_alocacao_id, v_obra_id IN 
    SELECT at.id, tp.id_obra 
    FROM tb_alocacoes_tarefa at
    JOIN tb_itens_ambiente ia ON at.id_item_ambiente = ia.id
    JOIN tb_tabela_precos tp ON ia.id_tabela_preco = tp.id
    WHERE at.status IN ('CONCLUIDO', 'EM_ANDAMENTO')
    LIMIT 5
  LOOP
    INSERT INTO tb_medicoes (
      id, id_alocacao, qtd_executada, flag_excedente,
      status_pagamento, id_obra, observacoes, created_at
    ) VALUES (
      gen_random_uuid(),
      v_alocacao_id,
      15.00 + (v_contador * 2.5),
      FALSE,
      'ABERTO',
      v_obra_id,
      'Medição de produção registrada via mobile',
      NOW() - INTERVAL '1 day'
    );
    
    v_contador := v_contador + 1;
  END LOOP;
END $$;

-- =============================================
-- 14. VERIFICAÇÃO FINAL
-- =============================================

SELECT 
  'Dados de teste populados com sucesso!' AS status,
  (SELECT COUNT(*) FROM tb_usuarios) AS total_usuarios,
  (SELECT COUNT(*) FROM tb_colaboradores) AS total_colaboradores,
  (SELECT COUNT(*) FROM tb_obras) AS total_obras,
  (SELECT COUNT(*) FROM tb_ambientes) AS total_ambientes,
  (SELECT COUNT(*) FROM tb_sessoes_diarias) AS total_sessoes,
  (SELECT COUNT(*) FROM tb_alocacoes_tarefa) AS total_alocacoes,
  (SELECT COUNT(*) FROM tb_medicoes) AS total_medicoes;

-- =============================================
-- FIM DOS SEEDS COMPLETOS
-- =============================================
