-- Migration 025: Sessoes de autenticacao por dispositivo
-- Permite revogacao de sessao especifica sem invalidar todas as sessoes do usuario.

CREATE TABLE IF NOT EXISTS tb_auth_sessoes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  id_usuario UUID NOT NULL REFERENCES tb_usuarios(id) ON DELETE CASCADE,
  refresh_token_hash VARCHAR(255) NOT NULL,
  refresh_token_jti VARCHAR(64),
  user_agent VARCHAR(255),
  ip_address VARCHAR(64),
  expira_em TIMESTAMP NOT NULL,
  revogado_em TIMESTAMP,
  deletado BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_auth_sessoes_usuario
  ON tb_auth_sessoes(id_usuario);

CREATE INDEX IF NOT EXISTS idx_auth_sessoes_ativo
  ON tb_auth_sessoes(id_usuario, revogado_em, expira_em)
  WHERE deletado = FALSE;