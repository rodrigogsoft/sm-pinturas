-- Migration 023: Alinhamento ERS 4.1 para elementos de servico em lote
-- Garante que id_tabela_preco seja opcional em tb_itens_ambiente.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_name = 'tb_itens_ambiente'
      AND column_name = 'id_tabela_preco'
      AND is_nullable = 'NO'
  ) THEN
    ALTER TABLE tb_itens_ambiente
      ALTER COLUMN id_tabela_preco DROP NOT NULL;
  END IF;
END $$;
