-- Estrutura base ERS 4.1 para alocacao por item, medicao individual e vale adiantamento

CREATE TABLE IF NOT EXISTS tb_alocacoes_itens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_sessao UUID NOT NULL REFERENCES tb_sessoes_diarias(id),
    id_ambiente UUID NOT NULL REFERENCES tb_ambientes(id),
    id_item_ambiente UUID NOT NULL REFERENCES tb_itens_ambiente(id),
    id_colaborador UUID NOT NULL REFERENCES tb_colaboradores(id),
    id_alocacao_legado UUID REFERENCES tb_alocacoes_tarefa(id),
    status VARCHAR(20) DEFAULT 'EM_ANDAMENTO' CHECK (status IN ('EM_ANDAMENTO', 'CONCLUIDO', 'PAUSADO')),
    hora_inicio TIMESTAMPTZ NOT NULL,
    hora_fim TIMESTAMPTZ,
    observacoes TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS unique_item_colaborador_ativo
ON tb_alocacoes_itens (id_item_ambiente, id_colaborador, status)
WHERE status = 'EM_ANDAMENTO' AND deletado = FALSE;

CREATE INDEX IF NOT EXISTS idx_alocacoes_itens_sessao ON tb_alocacoes_itens(id_sessao);
CREATE INDEX IF NOT EXISTS idx_alocacoes_itens_item ON tb_alocacoes_itens(id_item_ambiente);
CREATE INDEX IF NOT EXISTS idx_alocacoes_itens_colaborador ON tb_alocacoes_itens(id_colaborador);
CREATE INDEX IF NOT EXISTS idx_alocacoes_itens_status ON tb_alocacoes_itens(status) WHERE deletado = FALSE;

CREATE TABLE IF NOT EXISTS tb_medicoes_colaborador (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_alocacao_item UUID NOT NULL REFERENCES tb_alocacoes_itens(id),
    id_colaborador UUID NOT NULL REFERENCES tb_colaboradores(id),
    id_item_ambiente UUID NOT NULL REFERENCES tb_itens_ambiente(id),
    id_medicao_legado UUID REFERENCES tb_medicoes(id),
    qtd_executada DECIMAL(10,2) NOT NULL,
    area_planejada DECIMAL(10,2),
    percentual_conclusao_item DECIMAL(5,2),
    flag_excedente BOOLEAN DEFAULT FALSE,
    justificativa TEXT,
    foto_evidencia_url TEXT,
    status_pagamento VARCHAR(20) DEFAULT 'ABERTO' CHECK (status_pagamento IN ('ABERTO', 'LOTE_CRIADO', 'PAGO')),
    data_medicao DATE NOT NULL,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_medicoes_colaborador_alocacao_item ON tb_medicoes_colaborador(id_alocacao_item);
CREATE INDEX IF NOT EXISTS idx_medicoes_colaborador_item ON tb_medicoes_colaborador(id_item_ambiente);
CREATE INDEX IF NOT EXISTS idx_medicoes_colaborador_colaborador ON tb_medicoes_colaborador(id_colaborador);
CREATE INDEX IF NOT EXISTS idx_medicoes_colaborador_data ON tb_medicoes_colaborador(data_medicao);

CREATE TABLE IF NOT EXISTS tb_vales_adiantamento (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_colaborador UUID NOT NULL REFERENCES tb_colaboradores(id),
    id_obra UUID REFERENCES tb_obras(id),
    data_solicitacao DATE NOT NULL,
    data_aprovacao DATE,
    valor_solicitado DECIMAL(12,2) NOT NULL,
    valor_aprovado DECIMAL(12,2),
    status VARCHAR(30) DEFAULT 'SOLICITADO' CHECK (status IN ('SOLICITADO', 'APROVADO', 'PAGO', 'PARCIALMENTE_COMPENSADO', 'COMPENSADO', 'CANCELADO')),
    motivo TEXT,
    observacoes TEXT,
    id_aprovado_por UUID REFERENCES tb_usuarios(id),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_vales_adiantamento_colaborador ON tb_vales_adiantamento(id_colaborador);
CREATE INDEX IF NOT EXISTS idx_vales_adiantamento_status ON tb_vales_adiantamento(status) WHERE deletado = FALSE;

CREATE TABLE IF NOT EXISTS tb_vales_adiantamento_parcelas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    id_vale_adiantamento UUID NOT NULL REFERENCES tb_vales_adiantamento(id) ON DELETE CASCADE,
    numero_parcela INT NOT NULL,
    valor_parcela DECIMAL(12,2) NOT NULL,
    data_prevista_desconto DATE NOT NULL,
    data_desconto_realizado DATE,
    status VARCHAR(20) DEFAULT 'PENDENTE' CHECK (status IN ('PENDENTE', 'DESCONTADO', 'CANCELADO')),
    id_lote_pagamento UUID REFERENCES tb_lotes_pagamento(id),
    observacoes TEXT,
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_vale_adiantamento_parcela UNIQUE (id_vale_adiantamento, numero_parcela)
);

CREATE INDEX IF NOT EXISTS idx_vales_parcelas_vale ON tb_vales_adiantamento_parcelas(id_vale_adiantamento);
CREATE INDEX IF NOT EXISTS idx_vales_parcelas_lote ON tb_vales_adiantamento_parcelas(id_lote_pagamento);
