-- Adiciona coluna cpf_assinante à tabela tb_sessoes_diarias
ALTER TABLE tb_sessoes_diarias
ADD COLUMN IF NOT EXISTS cpf_assinante VARCHAR(14) NULL;

-- Criar índice se não existir
CREATE INDEX IF NOT EXISTS idx_sessoes_cpf_assinante ON tb_sessoes_diarias(cpf_assinante);
