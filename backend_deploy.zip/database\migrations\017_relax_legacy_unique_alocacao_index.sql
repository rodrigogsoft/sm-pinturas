-- ERS 4.1: manter unicidade 1:1 apenas para alocacao legado sem item
-- Permite multiplos colaboradores no mesmo ambiente quando alocacao por item estiver ativa.

DROP INDEX IF EXISTS idx_alocacoes_unicidade_ambiente;

CREATE UNIQUE INDEX IF NOT EXISTS idx_alocacoes_unicidade_ambiente
ON tb_alocacoes_tarefa (id_ambiente, status)
WHERE status = 'EM_ANDAMENTO'
  AND deletado = FALSE
  AND id_item_ambiente IS NULL;
