-- ============================================
-- MIGRATION: Garantir tabela tb_uploads
-- Versão: 011
-- Data: 2026-03-10
-- Descrição: Cria tb_uploads caso ainda nao exista no banco atual
-- ============================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS tb_uploads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome_original VARCHAR(255) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    mimetype VARCHAR(100) NOT NULL,
    tamanho BIGINT NOT NULL,
    caminho VARCHAR(500) NOT NULL,
    url VARCHAR(500) NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    id_relacionado UUID,
    descricao TEXT,
    id_usuario_upload UUID NOT NULL REFERENCES tb_usuarios(id),
    deletado BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_uploads_tipo ON tb_uploads(tipo) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_uploads_relacionado ON tb_uploads(id_relacionado) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_uploads_usuario ON tb_uploads(id_usuario_upload) WHERE deletado = FALSE;
CREATE INDEX IF NOT EXISTS idx_uploads_created_at ON tb_uploads(created_at);
