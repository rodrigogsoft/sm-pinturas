-- Migration 006: Adicionar categoria e melhorias em serviços
-- Data: 10/02/2026
-- Sprint: 4

-- Adicionar coluna categoria
ALTER TABLE tb_servicos_catalogo 
ADD COLUMN categoria VARCHAR(50) DEFAULT 'OUTROS';

COMMENT ON COLUMN tb_servicos_catalogo.categoria IS 'Categoria do serviço (PINTURA, ELETRICA, etc)';

-- Criar índice para buscas por categoria
CREATE INDEX idx_servicos_categoria ON tb_servicos_catalogo(categoria) WHERE deletado = false;

COMMENT ON INDEX idx_servicos_categoria IS 'Índice para otimizar buscas por categoria de serviço';

-- Criar índice composto para buscas
CREATE INDEX idx_servicos_busca ON tb_servicos_catalogo(nome, categoria, unidade_medida) WHERE deletado = false;

COMMENT ON INDEX idx_servicos_busca IS 'Índice composto para otimizar buscas avançadas';

-- Atualizar serviços existentes com categorias apropriadas (exemplos)
UPDATE tb_servicos_catalogo 
SET categoria = 'PINTURA' 
WHERE LOWER(nome) LIKE '%pintura%' OR LOWER(nome) LIKE '%látex%' OR LOWER(nome) LIKE '%tinta%';

UPDATE tb_servicos_catalogo 
SET categoria = 'ELETRICA' 
WHERE LOWER(nome) LIKE '%elétric%' OR LOWER(nome) LIKE '%fiação%' OR LOWER(nome) LIKE '%tomada%';

UPDATE tb_servicos_catalogo 
SET categoria = 'HIDRAULICA' 
WHERE LOWER(nome) LIKE '%hidráulic%' OR LOWER(nome) LIKE '%encanamento%' OR LOWER(nome) LIKE '%torneira%';

UPDATE tb_servicos_catalogo 
SET categoria = 'ALVENARIA' 
WHERE LOWER(nome) LIKE '%alvenaria%' OR LOWER(nome) LIKE '%reboco%' OR LOWER(nome) LIKE '%massa%';

UPDATE tb_servicos_catalogo 
SET categoria = 'GESSO' 
WHERE LOWER(nome) LIKE '%gesso%' OR LOWER(nome) LIKE '%forro%';
