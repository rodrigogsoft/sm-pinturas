import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import * as crypto from 'crypto';

/**
 * Serviço para upload de arquivos para AWS S3
 * Usa presigned URLs para uploads diretos pelo cliente
 * RN06: Armazenamento de fotos e assinaturas em S3
 */
@Injectable()
export class S3Service {
  private s3Client: S3Client;
  private bucket: string;
  private region: string;

  constructor(private configService: ConfigService) {
    this.region = this.configService.get('AWS_REGION') || 'us-east-1';
    this.bucket = this.configService.get('AWS_S3_BUCKET') || 'jb-pinturas-assets';

    const accessKeyId = this.configService.get('AWS_ACCESS_KEY_ID');
    const secretAccessKey = this.configService.get('AWS_SECRET_ACCESS_KEY');

    if (!accessKeyId || !secretAccessKey) {
      console.warn(
        'AWS S3 não está configurado: AWS_ACCESS_KEY_ID ou AWS_SECRET_ACCESS_KEY ausentes',
      );
    }

    this.s3Client = new S3Client({
      region: this.region,
      ...(accessKeyId && secretAccessKey && {
        credentials: {
          accessKeyId,
          secretAccessKey,
        },
      }),
    });
  }

  /**
   * Gera uma URL presigned para upload de arquivo
   * O cliente pode fazer POST diretamente nesta URL sem credenciais
   * 
   * @param key - Caminho do arquivo no bucket (ex: "uploads/medicoes/abc123.jpg")
   * @param contentType - Tipo MIME do arquivo (ex: "image/jpeg")
   * @param expiresIn - Tempo de expiração em segundos (padrão: 1 hora)
   * @returns URL presigned para POST
   */
  async generatePresignedUploadUrl(
    key: string,
    contentType: string,
    expiresIn: number = 3600,
  ): Promise<string> {
    try {
      const command = new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        ContentType: contentType,
      });

      const presignedUrl = await getSignedUrl(this.s3Client, command, {
        expiresIn,
      });

      return presignedUrl;
    } catch (error) {
      console.error('Erro ao gerar presigned URL:', error);
      throw new Error(`Falha ao gerar URL para upload: ${error.message}`);
    }
  }

  /**
   * Gera uma URL presigned para download (GET) de arquivo
   * 
   * @param key - Caminho do arquivo no bucket
   * @param expiresIn - Tempo de expiração em segundos (padrão: 7 dias)
   * @returns URL presigned para GET
   */
  async generatePresignedDownloadUrl(
    key: string,
    expiresIn: number = 604800, // 7 dias
  ): Promise<string> {
    try {
      const command = new GetObjectCommand({
        Bucket: this.bucket,
        Key: key,
      });

      const presignedUrl = await getSignedUrl(this.s3Client, command, {
        expiresIn,
      });

      return presignedUrl;
    } catch (error) {
      console.error('Erro ao gerar presigned download URL:', error);
      throw new Error(`Falha ao gerar URL para download: ${error.message}`);
    }
  }

  /**
   * Deleta um arquivo do S3
   * 
   * @param key - Caminho do arquivo no bucket
   */
  async deleteFile(key: string): Promise<void> {
    try {
      const command = new DeleteObjectCommand({
        Bucket: this.bucket,
        Key: key,
      });

      await this.s3Client.send(command);
    } catch (error) {
      console.error('Erro ao deletar arquivo do S3:', error);
      throw new Error(`Falha ao deletar arquivo: ${error.message}`);
    }
  }

  /**
   * Gera um key único para armazenar o arquivo
   * Formato: tipo/ano-mes/uuid-nome-arquivo
   * 
   * @param tipo - Tipo de arquivo (medicoes, assinaturas, fotos)
   * @param nomeOriginal - Nome original do arquivo
   * @returns Key para S3
   */
  generateFileKey(tipo: string, nomeOriginal: string): string {
    const agora = new Date();
    const ano = agora.getFullYear();
    const mes = String(agora.getMonth() + 1).padStart(2, '0');
    const uuid = crypto.randomBytes(8).toString('hex');

    // Remove caracteres especiais do nome
    const nomeSeguro = nomeOriginal
      .replace(/[^a-zA-Z0-9.-]/g, '_')
      .toLowerCase();

    return `uploads/${tipo}/${ano}-${mes}/${uuid}-${nomeSeguro}`;
  }

  /**
   * Obtém a URL pública do arquivo (sem autenticação)
   * Útil para prefixes que são públicos
   * 
   * @param key - Caminho do arquivo no bucket
   * @returns URL pública do S3
   */
  getPublicUrl(key: string): string {
    const s3Url = this.configService.get('AWS_S3_URL') || 
      `https://${this.bucket}.s3.${this.region}.amazonaws.com`;
    return `${s3Url}/${key}`;
  }
}
