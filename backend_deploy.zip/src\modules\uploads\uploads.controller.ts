import {
  Controller,
  Get,
  Post,
  Delete,
  Param,
  Query,
  UseGuards,
  UseInterceptors,
  UploadedFile,
  BadRequestException,
  Request,
  Res,
  ParseUUIDPipe,
  Body,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiConsumes,
  ApiBody,
  ApiQuery,
  ApiParam,
} from '@nestjs/swagger';
import { Response } from 'express';
import { UploadsService } from './uploads.service';
import { UploadFileDto } from './dto/upload-file.dto';
import { S3Service } from './services/s3.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { PerfilEnum } from '../../common/enums';
import * as fs from 'fs';

@ApiTags('Uploads')
@Controller('uploads')
export class UploadsController {
  constructor(
    private readonly uploadsService: UploadsService,
    private readonly s3Service: S3Service,
  ) {}

  // POST - Upload de Base64 (JSON) ou Multipart (FormData)
  @Post()
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @UseInterceptors(
    FileInterceptor('file', {
      limits: {
        fileSize: 5 * 1024 * 1024,
      },
    }),
  )
  @ApiOperation({
    summary: 'Upload de arquivo via base64 JSON ou multipart FormData',
    description: 'Aceita base64 JSON ou arquivo multipart. Usado para assinaturas digitais e evidências.',
  })
  @ApiBody({
    schema: {
      oneOf: [
        {
          type: 'object',
          description: 'Upload JSON com base64',
          properties: {
            file_base64: {
              type: 'string',
              format: 'byte',
            },
            tipo: { type: 'string' },
            descricao: { type: 'string' },
          },
        },
        {
          type: 'object',
          description: 'Upload FormData multipart',
          properties: {
            file: { type: 'string', format: 'binary' },
            tipo: { type: 'string' },
            descricao: { type: 'string' },
          },
        },
      ],
    },
  })
  @ApiResponse({ status: 201, description: 'Upload realizado com sucesso' })
  async create(
    @UploadedFile() file: Express.Multer.File,
    @Body() body: any,
    @Request() req: any,
  ) {
    // Se tiver arquivo multipart, usar o arquivo
    if (file) {
      const tipo = req.body?.tipo || req.query?.tipo || 'outro';
      const id_relacionado = req.body?.id_relacionado || req.query?.id_relacionado;
      const descricao = req.body?.descricao || req.query?.descricao;

      const uploadDto: UploadFileDto = {
        tipo,
        id_relacionado,
        descricao,
      };

      const userId = req.user.id;
      const upload = await this.uploadsService.saveFileInfo(file, uploadDto, userId);

      return {
        id: upload.id,
        url: upload.url,
        nome_original: upload.nome_original,
        mimetype: upload.mimetype,
        tamanho: upload.tamanho,
        created_at: upload.created_at,
      };
    }

    // Senão, tentar base64 do body
    if (body.file_base64) {
      const userId = req.user.id;

      const upload = await this.uploadsService.saveBase64(
        body.file_base64,
        body.nome_arquivo || 'arquivo.png',
        body.tipo || 'outro',
        body.id_relacionado,
        body.descricao,
        userId,
      );

      return {
        id: upload.id,
        url: upload.url,
        nome_original: upload.nome_original,
        mimetype: upload.mimetype,
        tamanho: upload.tamanho,
        created_at: upload.created_at,
      };
    }

    throw new BadRequestException(
      'Forneça "file" (multipart) ou "file_base64" (JSON)'
    );
  }

  // GET - Listar por tipo (requer autenticação)
  @Get()
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    PerfilEnum.ENCARREGADO,
    PerfilEnum.GESTOR,
    PerfilEnum.FINANCEIRO,
    PerfilEnum.ADMIN,
  )
  @ApiOperation({ summary: 'Listar uploads por tipo ou ID relacionado' })
  @ApiQuery({ name: 'tipo', required: false, description: 'Filtrar por tipo' })
  @ApiQuery({ name: 'id_relacionado', required: false, description: 'Filtrar por ID relacionado' })
  async findAll(
    @Query('tipo') tipo?: string,
    @Query('id_relacionado') idRelacionado?: string,
  ) {
    if (tipo) {
      return await this.uploadsService.findByTipo(tipo);
    }

    if (idRelacionado) {
      return await this.uploadsService.findByRelacionado(idRelacionado);
    }

    throw new BadRequestException('Forneça "tipo" ou "id_relacionado" para filtrar');
  }

  // GET :id - Buscar por ID (requer autenticação)
  @Get(':id')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    PerfilEnum.ENCARREGADO,
    PerfilEnum.GESTOR,
    PerfilEnum.FINANCEIRO,
    PerfilEnum.ADMIN,
  )
  @ApiOperation({ summary: 'Buscar upload por ID' })
  @ApiParam({ name: 'id', type: 'string', description: 'ID do upload' })
  @ApiResponse({ status: 200, description: 'Dados do upload' })
  @ApiResponse({ status: 404, description: 'Upload não encontrado' })
  async findOne(@Param('id', ParseUUIDPipe) id: string) {
    return await this.uploadsService.findOne(id);
  }

  // DELETE :id - Deletar (requer autenticação e role Gestor ou Admin)
  @Delete(':id')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(PerfilEnum.GESTOR, PerfilEnum.ADMIN)
  @ApiOperation({ summary: 'Deletar upload' })
  @ApiParam({ name: 'id', type: 'string', description: 'ID do upload' })
  @ApiResponse({ status: 200, description: 'Upload deletado com sucesso' })
  @ApiResponse({ status: 404, description: 'Upload não encontrado' })
  async remove(@Param('id', ParseUUIDPipe) id: string) {
    return await this.uploadsService.remove(id);
  }

  // GET file/:filename - Servir arquivo estático (sem autenticação)
  @Get('file/:filename')
  @ApiOperation({
    summary: 'Servir arquivo estático',
    description: 'Retorna o arquivo de imagem para exibição',
  })
  @ApiParam({ name: 'filename', type: 'string', description: 'Nome do arquivo' })
  async serveFile(@Param('filename') filename: string, @Res() res: Response) {
    const filePath = this.uploadsService.getFilePath(filename);

    if (!fs.existsSync(filePath)) {
      throw new BadRequestException('Arquivo não encontrado');
    }

    res.sendFile(filePath);
  }

  // POST s3/presigned-upload - Gerar URL presigned para upload direto ao S3
  @Post('s3/presigned-upload')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    PerfilEnum.ENCARREGADO,
    PerfilEnum.GESTOR,
    PerfilEnum.FINANCEIRO,
    PerfilEnum.ADMIN,
  )
  @ApiOperation({
    summary: 'Gerar URL presigned para upload ao S3',
    description:
      'Gera uma URL assinada que permite upload direto do cliente para S3 sem credenciais. RN06: Upload de fotos e assinaturas',
  })
  @ApiBody({
    schema: {
      type: 'object',
      required: ['fileName', 'contentType', 'tipo'],
      properties: {
        fileName: {
          type: 'string',
          description: 'Nome original do arquivo',
          example: 'medicao_01.jpg',
        },
        contentType: {
          type: 'string',
          description: 'Tipo MIME do arquivo',
          example: 'image/jpeg',
        },
        tipo: {
          type: 'string',
          enum: ['medicao', 'assinatura', 'obra', 'cliente'],
          description: 'Tipo de upload',
          example: 'medicao',
        },
        expiresIn: {
          type: 'number',
          description: 'Tempo de expiração em segundos (padrão: 3600)',
          example: 3600,
        },
      },
    },
  })
  @ApiResponse({
    status: 200,
    description: 'URL presigned gerada com sucesso',
    schema: {
      example: {
        uploadUrl: 'https://jb-pinturas-assets.s3.amazonaws.com/...',
        downloadUrl: 'https://jb-pinturas-assets.s3.amazonaws.com/...',
        key: 'uploads/medicao/2026-02/abc123def-medicao_01.jpg',
      },
    },
  })
  async generatePresignedUploadUrl(
    @Body()
    body: {
      fileName: string;
      contentType: string;
      tipo: string;
      expiresIn?: number;
    },
    @Request() req: any,
  ) {
    const { fileName, contentType, tipo, expiresIn = 3600 } = body;

    if (!fileName || fileName.trim().length === 0) {
      throw new BadRequestException('Nome do arquivo é obrigatório');
    }

    if (fileName.length > 255) {
      throw new BadRequestException('Nome do arquivo excede o limite de 255 caracteres');
    }

    if (!Number.isFinite(expiresIn) || expiresIn < 60 || expiresIn > 3600) {
      throw new BadRequestException('expiresIn deve estar entre 60 e 3600 segundos');
    }

    // Validar tipo de arquivo
    const allowedMimes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
    ];
    if (!allowedMimes.includes(contentType)) {
      throw new BadRequestException(
        `Tipo de arquivo não permitido: ${contentType}`,
      );
    }

    try {
      // Gerar key seguro para o arquivo
      const fileKey = this.s3Service.generateFileKey(tipo, fileName);

      // URL para upload (PUT)
      const uploadUrl = await this.s3Service.generatePresignedUploadUrl(
        fileKey,
        contentType,
        expiresIn,
      );

      // URL para download (GET) - válida por 7 dias
      const downloadUrl = await this.s3Service.generatePresignedDownloadUrl(
        fileKey,
        604800,
      );

      return {
        uploadUrl,
        downloadUrl,
        key: fileKey,
        expiresIn,
      };
    } catch (error) {
      throw new BadRequestException(
        `Erro ao gerar URL presigned: ${error.message}`,
      );
    }
  }

  // GET s3/download/:key - Redirecionar para download do S3
  @Get('s3/download/:key')
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(
    PerfilEnum.ENCARREGADO,
    PerfilEnum.GESTOR,
    PerfilEnum.FINANCEIRO,
    PerfilEnum.ADMIN,
  )
  @ApiOperation({
    summary: 'Obter URL de download do S3',
    description: 'Retorna URL presigned para download seguro do arquivo',
  })
  @ApiParam({
    name: 'key',
    type: 'string',
    description: 'Chave do arquivo no S3 (base64 encoded)',
  })
  async getPrespignedDownloadUrl(@Param('key') key: string) {
    try {
      const decodedKey = Buffer.from(key, 'base64').toString('utf-8');
      const downloadUrl =
        await this.s3Service.generatePresignedDownloadUrl(decodedKey);

      return { downloadUrl };
    } catch (error) {
      throw new BadRequestException(
        `Erro ao gerar URL de download: ${error.message}`,
      );
    }
  }
}
