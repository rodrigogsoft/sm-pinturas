-- Migration 020: Sincroniza colunas faltantes entre entidades TypeORM e schema do banco
-- Corrige 500 em /obras e /relatorios/dashboard-financeiro

-- tb_obras: faltam progresso e id_usuario_criador
ALTER TABLE tb_obras
  ADD COLUMN IF NOT EXISTS progresso DECIMAL(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS id_usuario_criador UUID REFERENCES tb_usuarios(id);

-- tb_pavimentos: faltam progresso, status_progresso, nivel e is_cobertura
ALTER TABLE tb_pavimentos
  ADD COLUMN IF NOT EXISTS progresso DECIMAL(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status_progresso VARCHAR(20) NOT NULL DEFAULT 'ABERTO',
  ADD COLUMN IF NOT EXISTS nivel INT,
  ADD COLUMN IF NOT EXISTS is_cobertura BOOLEAN NOT NULL DEFAULT FALSE;

-- tb_ambientes: faltam progresso e status_progresso
ALTER TABLE tb_ambientes
  ADD COLUMN IF NOT EXISTS progresso DECIMAL(5,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS status_progresso VARCHAR(20) NOT NULL DEFAULT 'ABERTO';
