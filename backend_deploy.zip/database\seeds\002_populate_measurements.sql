-- ============================================
-- POPULATE: Dados de Teste para Dashboard
-- ============================================

-- ============================================
-- 1. Verificar dados existentes
-- ============================================
-- SELECT 'Obras:', COUNT(*) FROM tb_obras;
-- SELECT 'Colaboradores:', COUNT(*) FROM tb_colaboradores;
-- SELECT 'Ambientes:', COUNT(*) FROM tb_ambientes;
-- SELECT 'Serviços:', COUNT(*) FROM tb_servicos_catalogo;

-- ============================================
-- 2. Criar Sessão Diária (se não existir)
-- ============================================
INSERT INTO tb_sessoes_diarias (id_encarregado, id_obra, data_sessao, status, hora_inicio)
SELECT 
    (SELECT id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com.br' LIMIT 1),
    o.id,
    CURRENT_DATE,
    'ENCERRADA'::tb_sessoes_diarias_status_enum,
    CURRENT_TIMESTAMP - INTERVAL '8 hours'
FROM tb_obras o
WHERE NOT EXISTS (
    SELECT 1 FROM tb_sessoes_diarias sd 
    WHERE sd.id_obra = o.id AND sd.data_sessao = CURRENT_DATE
)
LIMIT 1;

-- ============================================
-- 3. Criar Alocações de Tarefas
-- ============================================
INSERT INTO tb_alocacoes_tarefa (
    id_sessao,
    id_ambiente,
    id_colaborador,
    status,
    hora_inicio,
    hora_fim,
    observacoes
)
SELECT
    sd.id,
    am.id,
    (SELECT id FROM tb_colaboradores LIMIT 1),
    'CONCLUIDO'::tb_alocacoes_tarefa_status_enum,
    CURRENT_TIMESTAMP - INTERVAL '8 hours',
    CURRENT_TIMESTAMP - INTERVAL '4 hours',
    'Medição de teste'
FROM tb_sessoes_diarias sd
CROSS JOIN tb_ambientes am
WHERE sd.data_sessao = CURRENT_DATE
AND NOT EXISTS (
    SELECT 1 FROM tb_alocacoes_tarefa ta 
    WHERE ta.id_sessao = sd.id AND ta.id_ambiente = am.id
)
LIMIT 7;

-- ============================================
-- 4. Criar Medições
-- ============================================
INSERT INTO tb_medicoes (
    id_alocacao,
    qtd_executada,
    area_planejada,
    flag_excedente,
    status_pagamento,
    data_medicao,
    valor_calculado
)
SELECT
    ta.id,
    CASE ROW_NUMBER() OVER () 
        WHEN 1 THEN 25.50::numeric(10,2)
        WHEN 2 THEN 12.00::numeric(10,2)
        WHEN 3 THEN 10.50::numeric(10,2)
        WHEN 4 THEN 8.00::numeric(10,2)
        WHEN 5 THEN 25.50::numeric(10,2)
        WHEN 6 THEN 12.00::numeric(10,2)
        ELSE 15.00::numeric(10,2)
    END,
    CASE ROW_NUMBER() OVER () 
        WHEN 1 THEN 25.00::numeric(10,2)
        WHEN 2 THEN 12.00::numeric(10,2)
        WHEN 3 THEN 10.50::numeric(10,2)
        WHEN 4 THEN 8.00::numeric(10,2)
        WHEN 5 THEN 25.00::numeric(10,2)
        WHEN 6 THEN 12.00::numeric(10,2)
        ELSE 15.00::numeric(10,2)
    END,
    false,
    'ABERTO'::tb_medicoes_status_pagamento_enum,
    CURRENT_DATE - (ROW_NUMBER() OVER ())::int,
    CASE ROW_NUMBER() OVER () 
        WHEN 1 THEN (25.50 * 25.00)::numeric(10,2)
        WHEN 2 THEN (12.00 * 35.00)::numeric(10,2)
        WHEN 3 THEN (10.50 * 42.00)::numeric(10,2)
        WHEN 4 THEN (8.00 * 22.00)::numeric(10,2)
        WHEN 5 THEN (25.50 * 25.00)::numeric(10,2)
        WHEN 6 THEN (12.00 * 35.00)::numeric(10,2)
        ELSE (15.00 * 28.00)::numeric(10,2)
    END
FROM tb_alocacoes_tarefa ta
WHERE ta.status = 'CONCLUIDO'::tb_alocacoes_tarefa_status_enum
AND NOT EXISTS (
    SELECT 1 FROM tb_medicoes tm 
    WHERE tm.id_alocacao = ta.id
);

-- ============================================
-- 5. Criar Preços da Tabela
-- ============================================
INSERT INTO tb_tabela_precos (
    id_obra,
    id_servico_catalogo,
    preco_custo,
    preco_venda,
    status_aprovacao,
    id_usuario_aprovador,
    data_aprovacao,
    deletado
)
SELECT
    o.id,
    sc.id,
    CASE ROW_NUMBER() OVER (ORDER BY sc.id)
        WHEN 1 THEN 18.00::numeric(10,2)
        WHEN 2 THEN 25.00::numeric(10,2)
        WHEN 3 THEN 30.00::numeric(10,2)
        WHEN 4 THEN 15.00::numeric(10,2)
        WHEN 5 THEN 20.00::numeric(10,2)
        WHEN 6 THEN 5.00::numeric(10,2)
        ELSE 80.00::numeric(10,2)
    END,
    CASE ROW_NUMBER() OVER (ORDER BY sc.id)
        WHEN 1 THEN 25.00::numeric(10,2)
        WHEN 2 THEN 35.00::numeric(10,2)
        WHEN 3 THEN 42.00::numeric(10,2)
        WHEN 4 THEN 22.00::numeric(10,2)
        WHEN 5 THEN 28.00::numeric(10,2)
        WHEN 6 THEN 8.00::numeric(10,2)
        ELSE 120.00::numeric(10,2)
    END,
    'APROVADO'::tb_tabela_precos_status_aprovacao_enum,
    (SELECT id FROM tb_usuarios WHERE email = 'admin@jbpinturas.com.br' LIMIT 1),
    CURRENT_TIMESTAMP,
    false
FROM tb_obras o
CROSS JOIN tb_servicos_catalogo sc
WHERE NOT EXISTS (
    SELECT 1 FROM tb_tabela_precos tp 
    WHERE tp.id_obra = o.id AND tp.id_servico_catalogo = sc.id
)
LIMIT 7;

-- ============================================
-- VALIDAÇÃO
-- ============================================
SELECT '✅ Sessões criadas:' as status, COUNT(*) FROM tb_sessoes_diarias WHERE data_sessao = CURRENT_DATE
UNION ALL
SELECT '✅ Alocações criadas:', COUNT(*) FROM tb_alocacoes_tarefa WHERE status = 'CONCLUIDO'::tb_alocacoes_tarefa_status_enum
UNION ALL
SELECT '✅ Medições criadas:', COUNT(*) FROM tb_medicoes WHERE data_medicao >= CURRENT_DATE - 7
UNION ALL
SELECT '✅ Preços criados:', COUNT(*) FROM tb_tabela_precos WHERE data_aprovacao >= CURRENT_DATE - 1;
