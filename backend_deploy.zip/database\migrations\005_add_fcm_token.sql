-- Migration 005: Adicionar campo fcm_token para Push Notifications

-- Adicionar campo fcm_token à tabela tb_usuarios
ALTER TABLE tb_usuarios
ADD COLUMN fcm_token VARCHAR(255) NULL;

-- Comentário descrevendo o campo
COMMENT ON COLUMN tb_usuarios.fcm_token IS 'Token FCM (Firebase Cloud Messaging) para envio de push notifications ao dispositivo móvel do usuário';

-- Índice para melhorar performance de queries por token (opcional)
CREATE INDEX idx_usuarios_fcm_token ON tb_usuarios(fcm_token) WHERE fcm_token IS NOT NULL;

COMMENT ON INDEX idx_usuarios_fcm_token IS 'Índice para otimizar queries de envio de push notifications';
