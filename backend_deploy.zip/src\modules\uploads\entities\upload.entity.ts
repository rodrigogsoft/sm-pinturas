import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity('tb_uploads')
export class Upload {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 255 })
  nome_original: string;

  @Column({ type: 'varchar', length: 255 })
  nome_arquivo: string;

  @Column({ type: 'varchar', length: 100 })
  mimetype: string;

  @Column({ type: 'bigint' })
  tamanho: number;

  @Column({ type: 'varchar', length: 500 })
  caminho: string;

  @Column({ type: 'varchar', length: 500 })
  url: string;

  @Column({ type: 'varchar', length: 50 })
  tipo: string;

  @Column({ type: 'uuid', nullable: true })
  id_relacionado: string | null;

  @Column({ type: 'text', nullable: true })
  descricao: string | null;

  @Column({ type: 'uuid' })
  id_usuario_upload: string;

  @Column({ default: false })
  deletado: boolean;

  @CreateDateColumn()
  created_at: Date;
}
