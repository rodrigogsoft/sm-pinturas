-- Migration 003: Add campos de faturamento to tb_medicoes
-- RF10: Alertas de Faturamento
-- Data: 2026-02-10

-- Adiciona campos de controle de faturamento
ALTER TABLE tb_medicoes 
ADD COLUMN IF NOT EXISTS data_prevista_faturamento DATE,
ADD COLUMN IF NOT EXISTS data_faturamento_realizado DATE,
ADD COLUMN IF NOT EXISTS id_obra UUID;

-- Índice para consultas de alertas de faturamento
CREATE INDEX IF NOT EXISTS idx_medicoes_data_prevista_faturamento 
ON tb_medicoes(data_prevista_faturamento) 
WHERE data_faturamento_realizado IS NULL;

-- Popular id_obra para registros existentes através da cadeia de relacionamentos
UPDATE tb_medicoes m
SET id_obra = (
    SELECT p.id_obra
    FROM tb_alocacoes_tarefa at
    INNER JOIN tb_itens_ambiente ia ON at.id_item_ambiente = ia.id
    INNER JOIN tb_ambientes amb ON ia.id_ambiente = amb.id
    INNER JOIN tb_pavimentos p ON amb.id_pavimento = p.id
    WHERE at.id = m.id_alocacao
    LIMIT 1
)
WHERE m.id_obra IS NULL;

-- Adiciona foreign key para garantir integridade
ALTER TABLE tb_medicoes
ADD CONSTRAINT fk_medicoes_obra 
FOREIGN KEY (id_obra) REFERENCES tb_obras(id) ON DELETE CASCADE;

-- Comentários
COMMENT ON COLUMN tb_medicoes.data_prevista_faturamento IS 'Data prevista para faturamento da medição';
COMMENT ON COLUMN tb_medicoes.data_faturamento_realizado IS 'Data em que o faturamento foi efetivamente realizado';
COMMENT ON COLUMN tb_medicoes.id_obra IS 'ID da obra (denormalizado para performance de consultas)';
