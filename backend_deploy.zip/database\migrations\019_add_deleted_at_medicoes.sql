-- Migration 019: Adiciona deleted_at à tb_medicoes
-- A entidade Medicao possui o campo deleted_at mas ele nunca foi criado no banco
-- causando erro 500 no endpoint dashboard-financeiro

ALTER TABLE tb_medicoes
  ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ;
